"""
Meme generation system for the Discord bot.
Allows users to create memes using popular templates.
"""
import discord
from discord.ext import commands
import logging
import json
import os
import aiohttp
import io
import random
from typing import Dict, List, Optional, Union

logger = logging.getLogger(__name__)

class Meme(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
        # Popular meme templates
        self.meme_templates = {
            "drake": {
                "id": "181913649",
                "name": "Drake Hotline Bling",
                "box_count": 2
            },
            "distracted": {
                "id": "112126428",
                "name": "Distracted Boyfriend",
                "box_count": 3
            },
            "twobuttons": {
                "id": "87743020",
                "name": "Two Buttons",
                "box_count": 2
            },
            "changemind": {
                "id": "129242436",
                "name": "Change My Mind",
                "box_count": 1
            },
            "boyfriend": {
                "id": "112126428",
                "name": "Distracted Boyfriend",
                "box_count": 3
            },
            "buttons": {
                "id": "87743020",
                "name": "Two Buttons",
                "box_count": 2
            },
            "doge": {
                "id": "8072285",
                "name": "Doge",
                "box_count": 3
            },
            "car": {
                "id": "124822590",
                "name": "Left Exit 12 Off Ramp",
                "box_count": 3
            },
            "expand": {
                "id": "93895088",
                "name": "Expanding Brain",
                "box_count": 4
            },
            "woman": {
                "id": "217743513",
                "name": "UNO Draw 25 Cards",
                "box_count": 2
            },
            "scroll": {
                "id": "123999232",
                "name": "The Scroll Of Truth",
                "box_count": 1
            },
            "button": {
                "id": "119139145",
                "name": "Blank Nut Button",
                "box_count": 2
            },
            "buff": {
                "id": "247375501",
                "name": "Buff Doge vs. Cheems",
                "box_count": 4
            },
            "disappointed": {
                "id": "50421420",
                "name": "Disappointed Black Guy",
                "box_count": 2
            },
            "bernie": {
                "id": "222403160",
                "name": "Bernie I Am Once Again Asking For Your Support",
                "box_count": 1
            },
            "stranger": {
                "id": "135678846",
                "name": "Who Would Win?",
                "box_count": 2
            },
            "guy": {
                "id": "80707627",
                "name": "Sad Pablo Escobar",
                "box_count": 3
            },
            "always": {
                "id": "252600902",
                "name": "Always Has Been",
                "box_count": 2
            },
            "think": {
                "id": "89370399",
                "name": "Roll Safe Think About It",
                "box_count": 2
            }
        }
        
        # URL for the ImgFlip API
        self.imgflip_api_url = "https://api.imgflip.com/caption_image"
    
    @commands.group(aliases=["memes"], invoke_without_command=True)
    async def meme(self, ctx):
        """
        Sistema de criação de memes
        Usage: !meme
        """
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="🎭 Sistema de Memes",
                description="Crie memes divertidos com templates populares!",
                color=discord.Color.gold()
            )
            
            prefix = ctx.prefix
            
            embed.add_field(
                name="Comandos Disponíveis",
                value=(
                    f"**`{prefix}meme create <template> <texto1> | [texto2] | [texto3] | [texto4]`** - Criar um meme\n"
                    f"**`{prefix}meme templates`** - Listar templates disponíveis\n"
                    f"**`{prefix}meme random <texto1> | [texto2]`** - Criar um meme com template aleatório"
                ),
                inline=False
            )
            
            embed.add_field(
                name="Exemplo",
                value=f"`{prefix}meme create drake Não usar bots | Usar o Kimiko`",
                inline=False
            )
            
            await ctx.send(embed=embed)
    
    @meme.command(name="templates", aliases=["list", "lista"])
    async def meme_templates(self, ctx):
        """
        Listar templates de memes disponíveis
        Usage: !meme templates
        """
        embed = discord.Embed(
            title="📋 Templates de Memes Disponíveis",
            description="Use o código do template para criar memes!",
            color=discord.Color.blue()
        )
        
        # Add all templates to embed
        template_list = []
        for code, template in self.meme_templates.items():
            line = f"**{code}** - {template['name']} ({template['box_count']} caixas de texto)"
            template_list.append(line)
        
        # Split templates into multiple fields if needed
        templates_per_field = 5
        for i in range(0, len(template_list), templates_per_field):
            chunk = template_list[i:i + templates_per_field]
            embed.add_field(
                name=f"Templates {i+1}-{i+len(chunk)}",
                value="\n".join(chunk),
                inline=False
            )
        
        embed.set_footer(text=f"Use !meme create <template> <texto1> | [texto2] | ...")
        
        await ctx.send(embed=embed)
    
    @meme.command(name="create", aliases=["criar"])
    async def create_meme(self, ctx, template_code: str = None, *, text_content: str = None):
        """
        Criar um meme com um template específico
        Usage: !meme create <template> <texto1> | [texto2] | [texto3] | [texto4]
        """
        if template_code is None:
            return await ctx.send("❌ Por favor, especifique um template de meme! Use `!meme templates` para ver os disponíveis.")
        
        template_code = template_code.lower()
        
        if template_code not in self.meme_templates:
            return await ctx.send(f"❌ Template '{template_code}' não encontrado! Use `!meme templates` para ver os disponíveis.")
        
        if text_content is None:
            return await ctx.send("❌ Por favor, forneça o texto para o meme! Separe múltiplos textos com `|`.")
        
        template = self.meme_templates[template_code]
        template_id = template["id"]
        box_count = template["box_count"]
        
        # Split text by | character
        text_boxes = [text.strip() for text in text_content.split("|")]
        
        # Check if enough text boxes were provided
        if len(text_boxes) < 1:
            return await ctx.send(f"❌ Por favor, forneça pelo menos um texto para o meme!")
        
        # Pad with empty strings if not enough text boxes
        while len(text_boxes) < box_count:
            text_boxes.append("")
        
        # Truncate if too many text boxes
        if len(text_boxes) > box_count:
            text_boxes = text_boxes[:box_count]
        
        # Create meme
        await self.generate_meme(ctx, template_id, template["name"], text_boxes)
    
    @meme.command(name="random", aliases=["aleatorio", "r"])
    async def random_meme(self, ctx, *, text_content: str = None):
        """
        Criar um meme com um template aleatório
        Usage: !meme random <texto1> | [texto2]
        """
        if text_content is None:
            return await ctx.send("❌ Por favor, forneça o texto para o meme! Separe múltiplos textos com `|`.")
        
        # Choose a random template
        template_code = random.choice(list(self.meme_templates.keys()))
        template = self.meme_templates[template_code]
        template_id = template["id"]
        box_count = template["box_count"]
        
        # Split text by | character
        text_boxes = [text.strip() for text in text_content.split("|")]
        
        # Check if enough text boxes were provided
        if len(text_boxes) < 1:
            return await ctx.send(f"❌ Por favor, forneça pelo menos um texto para o meme!")
        
        # Pad with empty strings if not enough text boxes
        while len(text_boxes) < box_count:
            text_boxes.append("")
        
        # Truncate if too many text boxes
        if len(text_boxes) > box_count:
            text_boxes = text_boxes[:box_count]
        
        # Create meme
        await self.generate_meme(ctx, template_id, template["name"], text_boxes)
    
    async def generate_meme(self, ctx, template_id: str, template_name: str, text_boxes: List[str]):
        """Generate a meme using the ImgFlip API"""
        loading_message = await ctx.send("🎭 Gerando seu meme...")
        
        try:
            # Prepare data for ImgFlip API
            params = {
                "template_id": template_id,
                "username": "imgflip_hubot",
                "password": "imgflip_hubot"
            }
            
            # Add text boxes
            for i, text in enumerate(text_boxes):
                params[f"boxes[{i}][text]"] = text
            
            # Send request to ImgFlip API
            async with aiohttp.ClientSession() as session:
                async with session.post(self.imgflip_api_url, data=params) as response:
                    if response.status != 200:
                        await loading_message.delete()
                        return await ctx.send(f"❌ Não foi possível acessar a API do ImgFlip. Status: {response.status}")
                    
                    result = await response.json()
                    
                    if not result.get("success"):
                        await loading_message.delete()
                        return await ctx.send(f"❌ Erro ao gerar meme: {result.get('error_message', 'Erro desconhecido')}")
                    
                    meme_url = result["data"]["url"]
                    
                    # Create embed
                    embed = discord.Embed(
                        title=f"🎭 Meme: {template_name}",
                        color=discord.Color.random()
                    )
                    
                    embed.set_image(url=meme_url)
                    embed.set_footer(text=f"Solicitado por {ctx.author.name}")
                    
                    await loading_message.delete()
                    await ctx.send(embed=embed)
        
        except Exception as e:
            logger.error(f"Error generating meme: {e}")
            await loading_message.delete()
            await ctx.send(f"❌ Ocorreu um erro ao gerar o meme: {str(e)}")

async def setup(bot):
    await bot.add_cog(Meme(bot))