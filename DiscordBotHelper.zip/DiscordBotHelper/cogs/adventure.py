"""
Adventure/RPG system for the Discord bot.
Allows users to embark on adventures, battle monsters, and collect loot.
"""
import random
import asyncio
import discord
from discord.ext import commands
import logging
import json
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union, Tuple

logger = logging.getLogger(__name__)

class Adventure(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.adventure_data_file = "adventure_data.json"
        self.adventure_data = self.load_adventure_data()
        
        # Cooldowns (in seconds)
        self.cooldowns = {
            "adventure": 1800,  # 30 minutes
            "dungeon": 3600,    # 1 hour
            "boss": 7200,       # 2 hours
        }
        
        # Monsters for adventures
        self.monsters = {
            "easy": [
                {"name": "Slime", "hp": 50, "damage": (5, 10), "xp": 10, "gold": (10, 30)},
                {"name": "Goblin", "hp": 60, "damage": (8, 12), "xp": 15, "gold": (15, 35)},
                {"name": "Kobold", "hp": 45, "damage": (6, 10), "xp": 12, "gold": (12, 25)},
                {"name": "Skeleton", "hp": 55, "damage": (7, 14), "xp": 14, "gold": (15, 30)},
                {"name": "Giant Rat", "hp": 40, "damage": (4, 8), "xp": 8, "gold": (8, 20)}
            ],
            "medium": [
                {"name": "Orc", "hp": 100, "damage": (12, 18), "xp": 25, "gold": (25, 50)},
                {"name": "Werewolf", "hp": 90, "damage": (10, 22), "xp": 30, "gold": (30, 60)},
                {"name": "Ghoul", "hp": 85, "damage": (12, 20), "xp": 27, "gold": (25, 55)},
                {"name": "Dark Elf", "hp": 80, "damage": (15, 25), "xp": 32, "gold": (35, 65)},
                {"name": "Zombie Horde", "hp": 110, "damage": (10, 15), "xp": 28, "gold": (30, 55)}
            ],
            "hard": [
                {"name": "Minotaur", "hp": 200, "damage": (20, 35), "xp": 50, "gold": (50, 100)},
                {"name": "Griffin", "hp": 180, "damage": (25, 40), "xp": 55, "gold": (60, 120)},
                {"name": "Wyvern", "hp": 220, "damage": (30, 45), "xp": 60, "gold": (70, 130)},
                {"name": "Wraith", "hp": 160, "damage": (35, 50), "xp": 65, "gold": (80, 150)},
                {"name": "Giant Troll", "hp": 250, "damage": (25, 35), "xp": 58, "gold": (60, 110)}
            ],
            "boss": [
                {"name": "Dragon", "hp": 500, "damage": (50, 80), "xp": 200, "gold": (200, 400)},
                {"name": "Behemoth", "hp": 600, "damage": (40, 70), "xp": 220, "gold": (230, 450)},
                {"name": "Lich King", "hp": 450, "damage": (60, 90), "xp": 240, "gold": (250, 500)},
                {"name": "Kraken", "hp": 550, "damage": (55, 85), "xp": 230, "gold": (240, 480)},
                {"name": "Ancient Golem", "hp": 650, "damage": (45, 65), "xp": 210, "gold": (220, 420)}
            ]
        }
        
        # Items for adventures (weapons, armor, potions)
        self.items = {
            "weapons": [
                {"name": "Rusty Sword", "type": "weapon", "rarity": "common", "attack": 5, "value": 50},
                {"name": "Iron Dagger", "type": "weapon", "rarity": "common", "attack": 7, "value": 80},
                {"name": "Steel Sword", "type": "weapon", "rarity": "uncommon", "attack": 12, "value": 150},
                {"name": "Battle Axe", "type": "weapon", "rarity": "uncommon", "attack": 15, "value": 200},
                {"name": "Enchanted Bow", "type": "weapon", "rarity": "rare", "attack": 20, "value": 350},
                {"name": "Mithril Hammer", "type": "weapon", "rarity": "rare", "attack": 25, "value": 500},
                {"name": "Dragonslayer", "type": "weapon", "rarity": "epic", "attack": 40, "value": 1000},
                {"name": "Excalibur", "type": "weapon", "rarity": "legendary", "attack": 60, "value": 2000}
            ],
            "armor": [
                {"name": "Leather Tunic", "type": "armor", "rarity": "common", "defense": 5, "value": 50},
                {"name": "Chainmail", "type": "armor", "rarity": "common", "defense": 8, "value": 100},
                {"name": "Iron Plate", "type": "armor", "rarity": "uncommon", "defense": 12, "value": 180},
                {"name": "Steel Armor", "type": "armor", "rarity": "uncommon", "defense": 15, "value": 250},
                {"name": "Mithril Armor", "type": "armor", "rarity": "rare", "defense": 20, "value": 400},
                {"name": "Dragonscale Armor", "type": "armor", "rarity": "epic", "defense": 30, "value": 800},
                {"name": "Holy Paladin Armor", "type": "armor", "rarity": "legendary", "defense": 45, "value": 1500}
            ],
            "potions": [
                {"name": "Minor Healing Potion", "type": "potion", "rarity": "common", "effect": "heal", "value": 20, "power": 30},
                {"name": "Healing Potion", "type": "potion", "rarity": "uncommon", "effect": "heal", "value": 50, "power": 80},
                {"name": "Major Healing Potion", "type": "potion", "rarity": "rare", "effect": "heal", "value": 100, "power": 150},
                {"name": "Potion of Strength", "type": "potion", "rarity": "uncommon", "effect": "strength", "value": 80, "power": 10},
                {"name": "Potion of Defense", "type": "potion", "rarity": "uncommon", "effect": "defense", "value": 80, "power": 10},
                {"name": "Elixir of Life", "type": "potion", "rarity": "epic", "effect": "heal", "value": 300, "power": 300},
                {"name": "Elixir of Power", "type": "potion", "rarity": "epic", "effect": "strength", "value": 300, "power": 25}
            ]
        }
        
        # Item drops based on difficulty
        self.drop_chances = {
            "easy": {"weapon": 0.05, "armor": 0.05, "potion": 0.15},
            "medium": {"weapon": 0.10, "armor": 0.10, "potion": 0.25},
            "hard": {"weapon": 0.20, "armor": 0.20, "potion": 0.40},
            "boss": {"weapon": 0.50, "armor": 0.50, "potion": 0.75}
        }
        
        # Rarities and their chances
        self.rarity_chances = {
            "common": 0.50,
            "uncommon": 0.30,
            "rare": 0.15,
            "epic": 0.04,
            "legendary": 0.01
        }
        
        # XP needed per level (increases with each level)
        self.level_xp_requirements = {}
        for level in range(1, 101):
            self.level_xp_requirements[level] = int(100 * (level ** 1.5))
    
    def load_adventure_data(self):
        """Load adventure data from JSON file"""
        if os.path.exists(self.adventure_data_file):
            try:
                with open(self.adventure_data_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading adventure data: {e}")
                return {}
        return {}
    
    def save_adventure_data(self):
        """Save adventure data to JSON file"""
        try:
            with open(self.adventure_data_file, "w", encoding="utf-8") as f:
                json.dump(self.adventure_data, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving adventure data: {e}")
    
    def get_player_data(self, user_id: int):
        """Get or create player data"""
        str_user_id = str(user_id)
        if str_user_id not in self.adventure_data:
            self.adventure_data[str_user_id] = {
                "level": 1,
                "xp": 0,
                "gold": 100,
                "hp": 100,
                "max_hp": 100,
                "attack": 10,
                "defense": 5,
                "inventory": {
                    "weapons": [],
                    "armor": [],
                    "potions": []
                },
                "equipped": {
                    "weapon": None,
                    "armor": None
                },
                "cooldowns": {
                    "adventure": None,
                    "dungeon": None,
                    "boss": None
                },
                "stats": {
                    "adventures_completed": 0,
                    "dungeons_completed": 0,
                    "bosses_defeated": 0,
                    "monsters_killed": 0,
                    "items_found": 0,
                    "deaths": 0
                }
            }
            self.save_adventure_data()
        
        return self.adventure_data[str_user_id]
    
    def add_xp(self, user_id: int, amount: int):
        """Add XP to player and handle level-ups"""
        player_data = self.get_player_data(user_id)
        player_data["xp"] += amount
        
        current_level = player_data["level"]
        next_level = current_level + 1
        
        if next_level in self.level_xp_requirements and player_data["xp"] >= self.level_xp_requirements[next_level]:
            player_data["level"] = next_level
            
            # Update stats for a level up
            max_hp_increase = random.randint(10, 20)
            attack_increase = random.randint(1, 3)
            defense_increase = random.randint(1, 2)
            
            player_data["max_hp"] += max_hp_increase
            player_data["hp"] = player_data["max_hp"]  # Heal to full on level up
            player_data["attack"] += attack_increase
            player_data["defense"] += defense_increase
            
            self.save_adventure_data()
            
            return next_level, max_hp_increase, attack_increase, defense_increase
        
        self.save_adventure_data()
        return None, 0, 0, 0
    
    def check_cooldown(self, user_id: int, cooldown_type: str):
        """Check if a cooldown has passed"""
        player_data = self.get_player_data(user_id)
        cooldown_time = player_data["cooldowns"].get(cooldown_type)
        
        if cooldown_time is None:
            return True
        
        # If cooldown time has passed
        if time.time() > cooldown_time:
            return True
        
        return False
    
    def get_cooldown_remaining(self, user_id: int, cooldown_type: str):
        """Get remaining cooldown time in seconds"""
        player_data = self.get_player_data(user_id)
        cooldown_time = player_data["cooldowns"].get(cooldown_type)
        
        if cooldown_time is None:
            return 0
        
        remaining = cooldown_time - time.time()
        return max(0, remaining)
    
    def set_cooldown(self, user_id: int, cooldown_type: str):
        """Set a cooldown for a user"""
        player_data = self.get_player_data(user_id)
        cooldown_duration = self.cooldowns.get(cooldown_type, 0)
        player_data["cooldowns"][cooldown_type] = time.time() + cooldown_duration
        self.save_adventure_data()
    
    def format_time(self, seconds: float):
        """Format seconds into a readable time string"""
        minutes, seconds = divmod(int(seconds), 60)
        hours, minutes = divmod(minutes, 60)
        
        time_parts = []
        if hours > 0:
            time_parts.append(f"{hours}h")
        if minutes > 0:
            time_parts.append(f"{minutes}m")
        if seconds > 0 or not time_parts:
            time_parts.append(f"{seconds}s")
            
        return " ".join(time_parts)
    
    def get_item_emoji(self, item_type, rarity):
        """Get emoji for an item based on type and rarity"""
        type_emojis = {
            "weapon": "⚔️",
            "armor": "🛡️",
            "potion": "🧪"
        }
        
        rarity_colors = {
            "common": "⚪",
            "uncommon": "🟢",
            "rare": "🔵",
            "epic": "🟣",
            "legendary": "🟠"
        }
        
        return f"{type_emojis.get(item_type, '📦')} {rarity_colors.get(rarity, '⚪')}"
    
    def roll_item_drop(self, difficulty: str):
        """Roll for an item drop based on difficulty"""
        # Check if any item drops
        drop_types = ["weapon", "armor", "potion"]
        drop_type = None
        
        for item_type in drop_types:
            if random.random() < self.drop_chances[difficulty][item_type]:
                drop_type = item_type
                break
        
        if drop_type is None:
            return None
        
        # Determine rarity
        rarities = list(self.rarity_chances.keys())
        cum_chances = []
        cum_sum = 0
        
        for rarity in rarities:
            cum_sum += self.rarity_chances[rarity]
            cum_chances.append((rarity, cum_sum))
        
        # Adjust rarity chances based on difficulty
        rarity_boost = {"easy": 0, "medium": 0.1, "hard": 0.2, "boss": 0.3}
        roll = random.random() * (1 - rarity_boost[difficulty])
        
        selected_rarity = "common"  # Default
        for rarity, threshold in cum_chances:
            if roll < threshold:
                selected_rarity = rarity
                break
        
        # Select item from appropriate list
        possible_items = [item for item in self.items[drop_type + "s"] if item["rarity"] == selected_rarity]
        
        if not possible_items:
            return None
        
        return random.choice(possible_items)
    
    def add_item_to_inventory(self, user_id: int, item: Dict):
        """Add an item to player's inventory"""
        player_data = self.get_player_data(user_id)
        item_type = item["type"]
        
        if item_type == "weapon":
            player_data["inventory"]["weapons"].append(item)
        elif item_type == "armor":
            player_data["inventory"]["armor"].append(item)
        elif item_type == "potion":
            player_data["inventory"]["potions"].append(item)
        
        player_data["stats"]["items_found"] += 1
        self.save_adventure_data()
    
    def use_potion(self, user_id: int, potion_index: int):
        """Use a potion from inventory"""
        player_data = self.get_player_data(user_id)
        
        if potion_index < 0 or potion_index >= len(player_data["inventory"]["potions"]):
            return False, "Poção não encontrada no inventário!"
        
        potion = player_data["inventory"]["potions"][potion_index]
        effect = potion["effect"]
        power = potion["power"]
        
        if effect == "heal":
            old_hp = player_data["hp"]
            player_data["hp"] = min(player_data["max_hp"], player_data["hp"] + power)
            hp_restored = player_data["hp"] - old_hp
            
            # Remove potion from inventory
            player_data["inventory"]["potions"].pop(potion_index)
            self.save_adventure_data()
            
            return True, f"Você usou {potion['name']} e recuperou {hp_restored} de HP!"
        
        elif effect == "strength":
            player_data["attack"] += power
            
            # Remove potion from inventory
            player_data["inventory"]["potions"].pop(potion_index)
            self.save_adventure_data()
            
            return True, f"Você usou {potion['name']} e ganhou +{power} de ataque!"
        
        elif effect == "defense":
            player_data["defense"] += power
            
            # Remove potion from inventory
            player_data["inventory"]["potions"].pop(potion_index)
            self.save_adventure_data()
            
            return True, f"Você usou {potion['name']} e ganhou +{power} de defesa!"
        
        return False, "Tipo de poção desconhecido!"
    
    def equip_item(self, user_id: int, item_type: str, item_index: int):
        """Equip an item from inventory"""
        player_data = self.get_player_data(user_id)
        
        if item_type not in ["weapon", "armor"]:
            return False, "Tipo de item inválido! Use 'weapon' ou 'armor'."
        
        inventory_key = item_type + "s"
        
        if item_index < 0 or item_index >= len(player_data["inventory"][inventory_key]):
            return False, f"{item_type.capitalize()} não encontrado no inventário!"
        
        # Unequip current item if exists
        if player_data["equipped"][item_type] is not None:
            old_item = player_data["equipped"][item_type]
            player_data["inventory"][inventory_key].append(old_item)
        
        # Equip new item
        new_item = player_data["inventory"][inventory_key].pop(item_index)
        player_data["equipped"][item_type] = new_item
        
        self.save_adventure_data()
        
        return True, f"Você equipou {new_item['name']}!"
    
    def sell_item(self, user_id: int, item_type: str, item_index: int):
        """Sell an item from inventory"""
        player_data = self.get_player_data(user_id)
        
        if item_type not in ["weapon", "armor", "potion"]:
            return False, "Tipo de item inválido! Use 'weapon', 'armor' ou 'potion'."
        
        inventory_key = item_type + "s"
        
        if item_index < 0 or item_index >= len(player_data["inventory"][inventory_key]):
            return False, f"{item_type.capitalize()} não encontrado no inventário!"
        
        item = player_data["inventory"][inventory_key][item_index]
        sell_value = item["value"]
        
        # Remove item and add gold
        player_data["inventory"][inventory_key].pop(item_index)
        player_data["gold"] += sell_value
        
        self.save_adventure_data()
        
        return True, f"Você vendeu {item['name']} por {sell_value} de ouro!"
    
    @commands.group(aliases=["adv", "rpg"], invoke_without_command=True)
    async def adventure(self, ctx):
        """
        Sistema de aventuras RPG
        Usage: !adventure
        """
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="⚔️ Sistema de Aventuras RPG",
                description="Embarque em aventuras, lute contra monstros e colete tesouros!",
                color=discord.Color.dark_gold()
            )
            
            prefix = ctx.prefix
            
            embed.add_field(
                name="Comandos de Aventura",
                value=(
                    f"**`{prefix}adventure start`** - Iniciar uma aventura\n"
                    f"**`{prefix}adventure dungeon`** - Explorar uma masmorra (mais difícil)\n"
                    f"**`{prefix}adventure boss`** - Enfrentar um chefe (muito difícil)"
                ),
                inline=False
            )
            
            embed.add_field(
                name="Comandos de Personagem",
                value=(
                    f"**`{prefix}adventure profile`** - Ver seu perfil de aventureiro\n"
                    f"**`{prefix}adventure inventory`** - Ver seu inventário\n"
                    f"**`{prefix}adventure equip <weapon/armor> <índice>`** - Equipar um item\n"
                    f"**`{prefix}adventure use <índice>`** - Usar uma poção\n"
                    f"**`{prefix}adventure sell <weapon/armor/potion> <índice>`** - Vender um item"
                ),
                inline=False
            )
            
            embed.set_footer(text="Use !adventure profile para começar sua jornada!")
            
            await ctx.send(embed=embed)
    
    @adventure.command(name="profile", aliases=["perfil", "p"])
    async def adventure_profile(self, ctx, member: discord.Member = None):
        """
        Ver seu perfil de aventureiro
        Usage: !adventure profile [membro]
        """
        target = member or ctx.author
        player_data = self.get_player_data(target.id)
        
        # Calculate XP progress
        current_level = player_data["level"]
        current_xp = player_data["xp"]
        
        if current_level < 100:
            next_level_xp = self.level_xp_requirements[current_level + 1]
            xp_progress = f"{current_xp}/{next_level_xp}"
            xp_percentage = min(100, int((current_xp / next_level_xp) * 100))
        else:
            xp_progress = f"{current_xp} (Nível máximo)"
            xp_percentage = 100
        
        # Create progress bar
        progress_bar_length = 20
        filled_length = int(progress_bar_length * xp_percentage / 100)
        progress_bar = "█" * filled_length + "░" * (progress_bar_length - filled_length)
        
        # Create embed
        embed = discord.Embed(
            title=f"⚔️ Perfil de Aventureiro: {target.display_name}",
            color=discord.Color.dark_gold()
        )
        
        # Add character info
        embed.add_field(name="Nível", value=player_data["level"], inline=True)
        embed.add_field(name="Ouro", value=f"{player_data['gold']} 💰", inline=True)
        embed.add_field(name="HP", value=f"{player_data['hp']}/{player_data['max_hp']} ❤️", inline=True)
        
        # Add stats
        embed.add_field(name="Ataque", value=f"{player_data['attack']} ⚔️", inline=True)
        embed.add_field(name="Defesa", value=f"{player_data['defense']} 🛡️", inline=True)
        embed.add_field(name="Experiência", value=f"{xp_progress} 📊", inline=True)
        
        # Add progress bar
        embed.add_field(
            name="Progresso para o próximo nível",
            value=f"`{progress_bar}` {xp_percentage}%",
            inline=False
        )
        
        # Add equipped items
        weapon = player_data["equipped"]["weapon"]
        armor = player_data["equipped"]["armor"]
        
        weapon_text = f"{weapon['name']} (+{weapon['attack']} ataque)" if weapon else "Nenhuma arma equipada"
        armor_text = f"{armor['name']} (+{armor['defense']} defesa)" if armor else "Nenhuma armadura equipada"
        
        embed.add_field(name="🗡️ Arma Equipada", value=weapon_text, inline=True)
        embed.add_field(name="🛡️ Armadura Equipada", value=armor_text, inline=True)
        
        # Add adventure stats
        stats = player_data["stats"]
        embed.add_field(
            name="📊 Estatísticas",
            value=(
                f"🏞️ Aventuras: {stats['adventures_completed']}\n"
                f"🏰 Masmorras: {stats['dungeons_completed']}\n"
                f"👑 Chefes: {stats['bosses_defeated']}\n"
                f"👹 Monstros: {stats['monsters_killed']}\n"
                f"📦 Itens: {stats['items_found']}\n"
                f"💀 Mortes: {stats['deaths']}"
            ),
            inline=False
        )
        
        # Set thumbnail to user's avatar
        embed.set_thumbnail(url=target.avatar.url if target.avatar else target.default_avatar.url)
        
        await ctx.send(embed=embed)
    
    @adventure.command(name="inventory", aliases=["inv", "i"])
    async def adventure_inventory(self, ctx):
        """
        Ver seu inventário de aventureiro
        Usage: !adventure inventory
        """
        player_data = self.get_player_data(ctx.author.id)
        inventory = player_data["inventory"]
        
        embed = discord.Embed(
            title=f"🎒 Inventário de {ctx.author.display_name}",
            description=f"Ouro: {player_data['gold']} 💰",
            color=discord.Color.dark_green()
        )
        
        # Add weapons
        weapons = inventory["weapons"]
        if weapons:
            weapons_text = ""
            for i, weapon in enumerate(weapons):
                emoji = self.get_item_emoji("weapon", weapon["rarity"])
                weapons_text += f"`{i}` {emoji} **{weapon['name']}** (+{weapon['attack']} ataque) - {weapon['value']} ouro\n"
            
            embed.add_field(name="⚔️ Armas", value=weapons_text, inline=False)
        else:
            embed.add_field(name="⚔️ Armas", value="Nenhuma arma no inventário", inline=False)
        
        # Add armor
        armors = inventory["armor"]
        if armors:
            armors_text = ""
            for i, armor in enumerate(armors):
                emoji = self.get_item_emoji("armor", armor["rarity"])
                armors_text += f"`{i}` {emoji} **{armor['name']}** (+{armor['defense']} defesa) - {armor['value']} ouro\n"
            
            embed.add_field(name="🛡️ Armaduras", value=armors_text, inline=False)
        else:
            embed.add_field(name="🛡️ Armaduras", value="Nenhuma armadura no inventário", inline=False)
        
        # Add potions
        potions = inventory["potions"]
        if potions:
            potions_text = ""
            for i, potion in enumerate(potions):
                emoji = self.get_item_emoji("potion", potion["rarity"])
                effect_text = ""
                if potion["effect"] == "heal":
                    effect_text = f"Cura {potion['power']} HP"
                elif potion["effect"] == "strength":
                    effect_text = f"+{potion['power']} ataque"
                elif potion["effect"] == "defense":
                    effect_text = f"+{potion['power']} defesa"
                
                potions_text += f"`{i}` {emoji} **{potion['name']}** ({effect_text}) - {potion['value']} ouro\n"
            
            embed.add_field(name="🧪 Poções", value=potions_text, inline=False)
        else:
            embed.add_field(name="🧪 Poções", value="Nenhuma poção no inventário", inline=False)
        
        # Add equipped items
        weapon = player_data["equipped"]["weapon"]
        armor = player_data["equipped"]["armor"]
        
        equipped_text = ""
        if weapon:
            weapon_emoji = self.get_item_emoji("weapon", weapon["rarity"])
            equipped_text += f"{weapon_emoji} **Arma:** {weapon['name']} (+{weapon['attack']} ataque)\n"
        else:
            equipped_text += "**Arma:** Nenhuma arma equipada\n"
        
        if armor:
            armor_emoji = self.get_item_emoji("armor", armor["rarity"])
            equipped_text += f"{armor_emoji} **Armadura:** {armor['name']} (+{armor['defense']} defesa)"
        else:
            equipped_text += "**Armadura:** Nenhuma armadura equipada"
        
        embed.add_field(name="🧰 Equipamento Atual", value=equipped_text, inline=False)
        
        embed.set_footer(text="Use !adventure equip <weapon/armor> <índice> para equipar um item")
        
        await ctx.send(embed=embed)
    
    @adventure.command(name="equip", aliases=["equipar"])
    async def adventure_equip(self, ctx, item_type: str = None, item_index: int = None):
        """
        Equipar um item do inventário
        Usage: !adventure equip <weapon/armor> <índice>
        """
        if item_type is None or item_index is None:
            return await ctx.send("❌ Por favor, especifique o tipo de item (weapon/armor) e o índice!")
        
        item_type = item_type.lower()
        
        if item_type not in ["weapon", "armor"]:
            return await ctx.send("❌ Tipo de item inválido! Use 'weapon' ou 'armor'.")
        
        success, message = self.equip_item(ctx.author.id, item_type, item_index)
        
        if success:
            await ctx.send(f"✅ {message}")
        else:
            await ctx.send(f"❌ {message}")
    
    @adventure.command(name="use", aliases=["usar"])
    async def adventure_use(self, ctx, potion_index: int = None):
        """
        Usar uma poção do inventário
        Usage: !adventure use <índice>
        """
        if potion_index is None:
            return await ctx.send("❌ Por favor, especifique o índice da poção!")
        
        success, message = self.use_potion(ctx.author.id, potion_index)
        
        if success:
            await ctx.send(f"✅ {message}")
        else:
            await ctx.send(f"❌ {message}")
    
    @adventure.command(name="sell", aliases=["vender"])
    async def adventure_sell(self, ctx, item_type: str = None, item_index: int = None):
        """
        Vender um item do inventário
        Usage: !adventure sell <weapon/armor/potion> <índice>
        """
        if item_type is None or item_index is None:
            return await ctx.send("❌ Por favor, especifique o tipo de item (weapon/armor/potion) e o índice!")
        
        item_type = item_type.lower()
        
        if item_type not in ["weapon", "armor", "potion"]:
            return await ctx.send("❌ Tipo de item inválido! Use 'weapon', 'armor' ou 'potion'.")
        
        success, message = self.sell_item(ctx.author.id, item_type, item_index)
        
        if success:
            await ctx.send(f"✅ {message}")
        else:
            await ctx.send(f"❌ {message}")
    
    @adventure.command(name="start", aliases=["iniciar", "s"])
    async def adventure_start(self, ctx):
        """
        Iniciar uma aventura
        Usage: !adventure start
        """
        # Check cooldown
        if not self.check_cooldown(ctx.author.id, "adventure"):
            remaining = self.get_cooldown_remaining(ctx.author.id, "adventure")
            return await ctx.send(f"⏳ Você precisa descansar antes de iniciar outra aventura! Tempo restante: **{self.format_time(remaining)}**")
        
        player_data = self.get_player_data(ctx.author.id)
        
        # Check if player has HP
        if player_data["hp"] <= 0:
            return await ctx.send("❌ Você está sem HP! Use uma poção de cura para recuperar.")
        
        # Set cooldown
        self.set_cooldown(ctx.author.id, "adventure")
        
        # Start adventure
        embed = discord.Embed(
            title="🏞️ Aventura Iniciada!",
            description=f"{ctx.author.mention} embarcou em uma aventura!",
            color=discord.Color.blue()
        )
        
        adventure_message = await ctx.send(embed=embed)
        
        # Adventure progress
        for i in range(1, 4):
            await asyncio.sleep(2)
            
            progress_embed = discord.Embed(
                title="🏞️ Aventura em Progresso...",
                description=f"{ctx.author.mention} está explorando...\n{'🔍' * i}",
                color=discord.Color.blue()
            )
            
            await adventure_message.edit(embed=progress_embed)
        
        # Encounter a monster (easy difficulty)
        monster = random.choice(self.monsters["easy"])
        monster_hp = monster["hp"]
        
        encounter_embed = discord.Embed(
            title="👹 Encontro!",
            description=f"{ctx.author.mention} encontrou um(a) **{monster['name']}**!",
            color=discord.Color.red()
        )
        
        encounter_embed.add_field(name="Monstro", value=f"{monster['name']} (HP: {monster_hp})", inline=True)
        encounter_embed.add_field(name="Jogador", value=f"{ctx.author.display_name} (HP: {player_data['hp']}/{player_data['max_hp']})", inline=True)
        
        await adventure_message.edit(embed=encounter_embed)
        await asyncio.sleep(2)
        
        # Battle system
        turn = 1
        player_hp = player_data["hp"]
        weapon = player_data["equipped"]["weapon"]
        armor = player_data["equipped"]["armor"]
        
        player_attack = player_data["attack"]
        if weapon:
            player_attack += weapon["attack"]
        
        player_defense = player_data["defense"]
        if armor:
            player_defense += armor["defense"]
        
        battle_log = []
        
        while monster_hp > 0 and player_hp > 0:
            # Player's turn
            player_damage = max(1, random.randint(player_attack // 2, player_attack))
            monster_hp -= player_damage
            battle_log.append(f"⚔️ Você atacou {monster['name']} e causou **{player_damage}** de dano!")
            
            if monster_hp <= 0:
                break
            
            # Monster's turn
            monster_damage = max(1, random.randint(monster["damage"][0], monster["damage"][1]) - (player_defense // 2))
            player_hp -= monster_damage
            battle_log.append(f"🗡️ {monster['name']} atacou você e causou **{monster_damage}** de dano!")
            
            # Update battle embed every turn
            battle_embed = discord.Embed(
                title=f"⚔️ Batalha! (Turno {turn})",
                description="\n".join(battle_log[-3:]),  # Show last 3 actions
                color=discord.Color.red()
            )
            
            battle_embed.add_field(name="Monstro", value=f"{monster['name']} (HP: {max(0, monster_hp)})", inline=True)
            battle_embed.add_field(name="Jogador", value=f"{ctx.author.display_name} (HP: {max(0, player_hp)}/{player_data['max_hp']})", inline=True)
            
            await adventure_message.edit(embed=battle_embed)
            await asyncio.sleep(2)
            
            turn += 1
        
        # Battle result
        player_data["hp"] = max(0, player_hp)
        
        if monster_hp <= 0:
            # Player won
            player_data["stats"]["monsters_killed"] += 1
            player_data["stats"]["adventures_completed"] += 1
            
            # Calculate rewards
            xp_reward = monster["xp"]
            gold_reward = random.randint(monster["gold"][0], monster["gold"][1])
            
            player_data["gold"] += gold_reward
            
            # Check for level up
            level_up, hp_up, atk_up, def_up = self.add_xp(ctx.author.id, xp_reward)
            
            # Roll for item drop
            item_drop = self.roll_item_drop("easy")
            if item_drop:
                self.add_item_to_inventory(ctx.author.id, item_drop)
                item_text = f"Você encontrou: {self.get_item_emoji(item_drop['type'], item_drop['rarity'])} **{item_drop['name']}**!"
            else:
                item_text = "Você não encontrou nenhum item desta vez."
            
            result_embed = discord.Embed(
                title="🎉 Vitória!",
                description=f"{ctx.author.mention} derrotou o(a) **{monster['name']}**!",
                color=discord.Color.green()
            )
            
            result_embed.add_field(name="Recompensas", value=f"XP: +{xp_reward} 📊\nOuro: +{gold_reward} 💰", inline=False)
            result_embed.add_field(name="Item", value=item_text, inline=False)
            
            if level_up:
                result_embed.add_field(
                    name="🆙 Level Up!",
                    value=f"Você avançou para o nível **{level_up}**!\n+{hp_up} HP Máximo\n+{atk_up} Ataque\n+{def_up} Defesa",
                    inline=False
                )
            
            await adventure_message.edit(embed=result_embed)
        
        else:
            # Player lost
            player_data["stats"]["deaths"] += 1
            
            result_embed = discord.Embed(
                title="💀 Derrota!",
                description=f"{ctx.author.mention} foi derrotado(a) pelo(a) **{monster['name']}**!",
                color=discord.Color.dark_red()
            )
            
            result_embed.add_field(
                name="Estado",
                value="Você está sem HP! Use uma poção para se curar.",
                inline=False
            )
            
            await adventure_message.edit(embed=result_embed)
        
        self.save_adventure_data()
    
    @adventure.command(name="dungeon", aliases=["masmorra", "d"])
    async def adventure_dungeon(self, ctx):
        """
        Explorar uma masmorra (mais difícil que aventura normal)
        Usage: !adventure dungeon
        """
        # Check cooldown
        if not self.check_cooldown(ctx.author.id, "dungeon"):
            remaining = self.get_cooldown_remaining(ctx.author.id, "dungeon")
            return await ctx.send(f"⏳ Você precisa descansar antes de explorar outra masmorra! Tempo restante: **{self.format_time(remaining)}**")
        
        player_data = self.get_player_data(ctx.author.id)
        
        # Check if player has HP
        if player_data["hp"] <= 0:
            return await ctx.send("❌ Você está sem HP! Use uma poção de cura para recuperar.")
        
        # Check player level (dungeons are for higher levels)
        if player_data["level"] < 5:
            return await ctx.send("❌ Você precisa ser pelo menos nível 5 para explorar masmorras!")
        
        # Set cooldown
        self.set_cooldown(ctx.author.id, "dungeon")
        
        # Start dungeon
        embed = discord.Embed(
            title="🏰 Exploração de Masmorra Iniciada!",
            description=f"{ctx.author.mention} começou a explorar uma masmorra perigosa!",
            color=discord.Color.dark_purple()
        )
        
        dungeon_message = await ctx.send(embed=embed)
        
        # Dungeon progress
        for i in range(1, 4):
            await asyncio.sleep(2)
            
            progress_embed = discord.Embed(
                title="🏰 Explorando a Masmorra...",
                description=f"{ctx.author.mention} está explorando as profundezas...\n{'🔦' * i}",
                color=discord.Color.dark_purple()
            )
            
            await dungeon_message.edit(embed=progress_embed)
        
        # Encounter a monster (medium difficulty)
        monster = random.choice(self.monsters["medium"])
        monster_hp = monster["hp"]
        
        encounter_embed = discord.Embed(
            title="👹 Encontro nas Sombras!",
            description=f"{ctx.author.mention} encontrou um(a) **{monster['name']}** nas profundezas da masmorra!",
            color=discord.Color.red()
        )
        
        encounter_embed.add_field(name="Monstro", value=f"{monster['name']} (HP: {monster_hp})", inline=True)
        encounter_embed.add_field(name="Jogador", value=f"{ctx.author.display_name} (HP: {player_data['hp']}/{player_data['max_hp']})", inline=True)
        
        await dungeon_message.edit(embed=encounter_embed)
        await asyncio.sleep(2)
        
        # Battle system (similar to adventure but with harder monsters)
        turn = 1
        player_hp = player_data["hp"]
        weapon = player_data["equipped"]["weapon"]
        armor = player_data["equipped"]["armor"]
        
        player_attack = player_data["attack"]
        if weapon:
            player_attack += weapon["attack"]
        
        player_defense = player_data["defense"]
        if armor:
            player_defense += armor["defense"]
        
        battle_log = []
        
        while monster_hp > 0 and player_hp > 0:
            # Player's turn
            player_damage = max(1, random.randint(player_attack // 2, player_attack))
            monster_hp -= player_damage
            battle_log.append(f"⚔️ Você atacou {monster['name']} e causou **{player_damage}** de dano!")
            
            if monster_hp <= 0:
                break
            
            # Monster's turn
            monster_damage = max(1, random.randint(monster["damage"][0], monster["damage"][1]) - (player_defense // 2))
            player_hp -= monster_damage
            battle_log.append(f"🗡️ {monster['name']} atacou você e causou **{monster_damage}** de dano!")
            
            # Update battle embed every turn
            battle_embed = discord.Embed(
                title=f"⚔️ Batalha nas Sombras! (Turno {turn})",
                description="\n".join(battle_log[-3:]),  # Show last 3 actions
                color=discord.Color.red()
            )
            
            battle_embed.add_field(name="Monstro", value=f"{monster['name']} (HP: {max(0, monster_hp)})", inline=True)
            battle_embed.add_field(name="Jogador", value=f"{ctx.author.display_name} (HP: {max(0, player_hp)}/{player_data['max_hp']})", inline=True)
            
            await dungeon_message.edit(embed=battle_embed)
            await asyncio.sleep(2)
            
            turn += 1
        
        # Battle result
        player_data["hp"] = max(0, player_hp)
        
        if monster_hp <= 0:
            # Player won
            player_data["stats"]["monsters_killed"] += 1
            player_data["stats"]["dungeons_completed"] += 1
            
            # Calculate rewards (better than normal adventure)
            xp_reward = monster["xp"]
            gold_reward = random.randint(monster["gold"][0], monster["gold"][1])
            
            player_data["gold"] += gold_reward
            
            # Check for level up
            level_up, hp_up, atk_up, def_up = self.add_xp(ctx.author.id, xp_reward)
            
            # Roll for item drop (better chances in dungeon)
            item_drop = self.roll_item_drop("medium")
            if item_drop:
                self.add_item_to_inventory(ctx.author.id, item_drop)
                item_text = f"Você encontrou: {self.get_item_emoji(item_drop['type'], item_drop['rarity'])} **{item_drop['name']}**!"
            else:
                item_text = "Você não encontrou nenhum item desta vez."
            
            result_embed = discord.Embed(
                title="🎉 Vitória nas Sombras!",
                description=f"{ctx.author.mention} derrotou o(a) **{monster['name']}** na masmorra!",
                color=discord.Color.green()
            )
            
            result_embed.add_field(name="Recompensas", value=f"XP: +{xp_reward} 📊\nOuro: +{gold_reward} 💰", inline=False)
            result_embed.add_field(name="Item", value=item_text, inline=False)
            
            if level_up:
                result_embed.add_field(
                    name="🆙 Level Up!",
                    value=f"Você avançou para o nível **{level_up}**!\n+{hp_up} HP Máximo\n+{atk_up} Ataque\n+{def_up} Defesa",
                    inline=False
                )
            
            await dungeon_message.edit(embed=result_embed)
        
        else:
            # Player lost
            player_data["stats"]["deaths"] += 1
            
            result_embed = discord.Embed(
                title="💀 Derrota nas Sombras!",
                description=f"{ctx.author.mention} foi derrotado(a) pelo(a) **{monster['name']}** na masmorra!",
                color=discord.Color.dark_red()
            )
            
            result_embed.add_field(
                name="Estado",
                value="Você está sem HP! Use uma poção para se curar.",
                inline=False
            )
            
            await dungeon_message.edit(embed=result_embed)
        
        self.save_adventure_data()
    
    @adventure.command(name="boss", aliases=["chefe", "b"])
    async def adventure_boss(self, ctx):
        """
        Enfrentar um chefe (muito difícil)
        Usage: !adventure boss
        """
        # Check cooldown
        if not self.check_cooldown(ctx.author.id, "boss"):
            remaining = self.get_cooldown_remaining(ctx.author.id, "boss")
            return await ctx.send(f"⏳ Você precisa descansar antes de enfrentar outro chefe! Tempo restante: **{self.format_time(remaining)}**")
        
        player_data = self.get_player_data(ctx.author.id)
        
        # Check if player has HP
        if player_data["hp"] <= 0:
            return await ctx.send("❌ Você está sem HP! Use uma poção de cura para recuperar.")
        
        # Check player level (boss fights are for high levels)
        if player_data["level"] < 10:
            return await ctx.send("❌ Você precisa ser pelo menos nível 10 para enfrentar um chefe!")
        
        # Set cooldown
        self.set_cooldown(ctx.author.id, "boss")
        
        # Start boss fight
        embed = discord.Embed(
            title="👑 Confronto com Chefe Iniciado!",
            description=f"{ctx.author.mention} se prepara para enfrentar um poderoso chefe!",
            color=discord.Color.dark_red()
        )
        
        boss_message = await ctx.send(embed=embed)
        
        # Boss encounter progress
        for i in range(1, 4):
            await asyncio.sleep(2)
            
            progress_embed = discord.Embed(
                title="👑 Aproximando-se do Chefe...",
                description=f"{ctx.author.mention} sente uma presença maligna se aproximando...\n{'⚠️' * i}",
                color=discord.Color.dark_red()
            )
            
            await boss_message.edit(embed=progress_embed)
        
        # Encounter a boss monster
        boss = random.choice(self.monsters["boss"])
        boss_hp = boss["hp"]
        
        encounter_embed = discord.Embed(
            title="👑 Confronto com Chefe!",
            description=f"{ctx.author.mention} está frente a frente com **{boss['name']}**!",
            color=discord.Color.red()
        )
        
        encounter_embed.add_field(name="Chefe", value=f"{boss['name']} (HP: {boss_hp})", inline=True)
        encounter_embed.add_field(name="Jogador", value=f"{ctx.author.display_name} (HP: {player_data['hp']}/{player_data['max_hp']})", inline=True)
        
        await boss_message.edit(embed=encounter_embed)
        await asyncio.sleep(2)
        
        # Battle system (for boss fights, longer and harder)
        turn = 1
        player_hp = player_data["hp"]
        weapon = player_data["equipped"]["weapon"]
        armor = player_data["equipped"]["armor"]
        
        player_attack = player_data["attack"]
        if weapon:
            player_attack += weapon["attack"]
        
        player_defense = player_data["defense"]
        if armor:
            player_defense += armor["defense"]
        
        battle_log = []
        
        # Boss fights last longer and are more strategic
        while boss_hp > 0 and player_hp > 0:
            # Player's turn
            player_damage = max(1, random.randint(player_attack // 2, player_attack))
            boss_hp -= player_damage
            battle_log.append(f"⚔️ Você atacou {boss['name']} e causou **{player_damage}** de dano!")
            
            if boss_hp <= 0:
                break
            
            # Boss's turn
            boss_damage = max(1, random.randint(boss["damage"][0], boss["damage"][1]) - (player_defense // 2))
            player_hp -= boss_damage
            battle_log.append(f"🗡️ {boss['name']} atacou você e causou **{boss_damage}** de dano!")
            
            # Every 3 turns, the boss performs a special attack
            if turn % 3 == 0:
                special_damage = boss_damage * 1.5
                player_hp -= special_damage
                battle_log.append(f"⚡ {boss['name']} usou um ataque especial e causou **{int(special_damage)}** de dano extra!")
            
            # Update battle embed every turn
            battle_embed = discord.Embed(
                title=f"👑 Confronto com Chefe! (Turno {turn})",
                description="\n".join(battle_log[-3:]),  # Show last 3 actions
                color=discord.Color.red()
            )
            
            battle_embed.add_field(name="Chefe", value=f"{boss['name']} (HP: {max(0, boss_hp)})", inline=True)
            battle_embed.add_field(name="Jogador", value=f"{ctx.author.display_name} (HP: {max(0, player_hp)}/{player_data['max_hp']})", inline=True)
            
            await boss_message.edit(embed=battle_embed)
            await asyncio.sleep(2)
            
            turn += 1
        
        # Battle result
        player_data["hp"] = max(0, player_hp)
        
        if boss_hp <= 0:
            # Player won
            player_data["stats"]["monsters_killed"] += 1
            player_data["stats"]["bosses_defeated"] += 1
            
            # Calculate rewards (much better than normal adventure)
            xp_reward = boss["xp"]
            gold_reward = random.randint(boss["gold"][0], boss["gold"][1])
            
            player_data["gold"] += gold_reward
            
            # Check for level up
            level_up, hp_up, atk_up, def_up = self.add_xp(ctx.author.id, xp_reward)
            
            # Roll for item drop (excellent chances with boss)
            item_drop = self.roll_item_drop("boss")
            if item_drop:
                self.add_item_to_inventory(ctx.author.id, item_drop)
                item_text = f"Você encontrou: {self.get_item_emoji(item_drop['type'], item_drop['rarity'])} **{item_drop['name']}**!"
            else:
                item_text = "Você não encontrou nenhum item desta vez."
            
            result_embed = discord.Embed(
                title="🎉 O Chefe Foi Derrotado!",
                description=f"{ctx.author.mention} derrotou o(a) poderoso(a) **{boss['name']}**!",
                color=discord.Color.gold()
            )
            
            result_embed.add_field(name="Recompensas", value=f"XP: +{xp_reward} 📊\nOuro: +{gold_reward} 💰", inline=False)
            result_embed.add_field(name="Item", value=item_text, inline=False)
            
            if level_up:
                result_embed.add_field(
                    name="🆙 Level Up!",
                    value=f"Você avançou para o nível **{level_up}**!\n+{hp_up} HP Máximo\n+{atk_up} Ataque\n+{def_up} Defesa",
                    inline=False
                )
            
            await boss_message.edit(embed=result_embed)
        
        else:
            # Player lost
            player_data["stats"]["deaths"] += 1
            
            result_embed = discord.Embed(
                title="💀 Derrota contra o Chefe!",
                description=f"{ctx.author.mention} foi derrotado(a) pelo(a) poderoso(a) **{boss['name']}**!",
                color=discord.Color.dark_red()
            )
            
            result_embed.add_field(
                name="Estado",
                value="Você está sem HP! Use uma poção para se curar.",
                inline=False
            )
            
            await boss_message.edit(embed=result_embed)
        
        self.save_adventure_data()

async def setup(bot):
    await bot.add_cog(Adventure(bot))