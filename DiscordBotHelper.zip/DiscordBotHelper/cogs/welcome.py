"""
Welcome system for the Discord bot.
Manages welcome messages for new members and server join notifications.
"""
import json
import os
import random
import logging
from datetime import datetime

import discord
from discord.ext import commands

# Configure logging
logger = logging.getLogger(__name__)

class Welcome(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config_path = "welcome_config.json"
        self.config = self.load_config()
        
    def load_config(self):
        """Load welcome configuration from JSON file"""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading welcome config: {e}")
                return self.get_default_config()
        else:
            # Create default config
            default_config = self.get_default_config()
            self.save_config(default_config)
            return default_config

    def get_default_config(self):
        """Return default welcome configuration"""
        return {
            "enabled": True,
            "welcome_channel": {},  # guild_id: channel_id mapping
            "dm_welcome": True,
            "welcome_messages": [
                "Bem-vindo(a) {user} ao {server}! Esperamos que você se divirta aqui!",
                "Olá {user}! Seja bem-vindo(a) ao {server}!",
                "Um novo membro chegou! Deem as boas-vindas para {user}!",
                "Mais um para a nossa família! {user} agora faz parte do {server}!",
                "{user} acabou de entrar! Vocês cheiraram isso? Cheiro de membro novo no {server}!",
                "Bem-vindo(a) {user}! Prepare-se para uma experiência incrível no {server}!"
            ],
            "welcome_messages_en": [
                "Welcome {user} to {server}! We hope you enjoy your stay!",
                "Hello {user}! Welcome to {server}!",
                "A new member has arrived! Everyone welcome {user}!",
                "One more to our family! {user} is now part of {server}!",
                "{user} just joined! Did you smell that? Smells like a new member in {server}!",
                "Welcome {user}! Get ready for an amazing experience in {server}!"
            ],
            "goodbye_messages": [
                "Adeus {user}! Sentiremos sua falta...",
                "{user} saiu do servidor. Até a próxima!",
                "Foi bom enquanto durou! Adeus, {user}.",
                "{user} nos deixou. O {server} não será o mesmo sem você!"
            ],
            "goodbye_messages_en": [
                "Goodbye {user}! We will miss you...",
                "{user} left the server. Until next time!",
                "It was good while it lasted! Goodbye, {user}.",
                "{user} has left us. {server} won't be the same without you!"
            ]
        }

    def save_config(self, config=None):
        """Save welcome configuration to JSON file"""
        if config is None:
            config = self.config
            
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=4)
            self.config = config
            return True
        except Exception as e:
            logger.error(f"Error saving welcome config: {e}")
            return False

    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Event triggered when a member joins the server"""
        if not self.config["enabled"]:
            return
            
        guild = member.guild
        guild_id = str(guild.id)
        
        # Create a beautiful embed for the welcome message
        embed = discord.Embed(
            title=f"Bem-vindo(a) ao {guild.name}!",
            description=self.get_welcome_message(member),
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        # Add member info
        embed.add_field(
            name="👤 Usuário",
            value=f"{member.mention} ({member.name})",
            inline=True
        )
        
        # Add member count
        embed.add_field(
            name="👥 Total de Membros",
            value=f"{guild.member_count}",
            inline=True
        )
        
        # Add creation date (when the account was created)
        embed.add_field(
            name="📅 Conta criada em",
            value=f"<t:{int(member.created_at.timestamp())}:F>",
            inline=False
        )
        
        # Set thumbnail (user avatar)
        if member.avatar:
            embed.set_thumbnail(url=member.avatar.url)
            
        # Set footer with bot name and icon
        embed.set_footer(
            text=f"Bot por Chwrmoon",
            icon_url=self.bot.user.avatar.url if self.bot.user.avatar else None
        )
        
        # Send welcome message to designated channel if configured
        if guild_id in self.config["welcome_channel"]:
            try:
                channel_id = int(self.config["welcome_channel"][guild_id])
                channel = guild.get_channel(channel_id)
                if channel:
                    await channel.send(embed=embed)
                    logger.info(f"Welcome message sent to {channel.name} for {member}")
            except Exception as e:
                logger.error(f"Error sending welcome message to channel: {e}")
        
        # Send DM welcome message if enabled
        if self.config["dm_welcome"]:
            try:
                dm_embed = discord.Embed(
                    title=f"Bem-vindo(a) ao {guild.name}!",
                    description=(
                        f"Olá {member.mention}!\n\n"
                        f"Obrigado por se juntar ao **{guild.name}**. "
                        f"Esperamos que você tenha uma ótima experiência aqui!\n\n"
                        f"Não hesite em pedir ajuda se precisar."
                    ),
                    color=discord.Color.blue(),
                    timestamp=datetime.now()
                )
                
                if guild.icon:
                    dm_embed.set_thumbnail(url=guild.icon.url)
                    
                dm_embed.set_footer(
                    text=f"Mensagem automática de {self.bot.user.name}",
                    icon_url=self.bot.user.avatar.url if self.bot.user.avatar else None
                )
                
                await member.send(embed=dm_embed)
                logger.info(f"Welcome DM sent to {member}")
            except Exception as e:
                logger.error(f"Error sending welcome DM to {member}: {e}")
    
    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """Event triggered when a member leaves the server"""
        if not self.config["enabled"]:
            return
            
        guild = member.guild
        guild_id = str(guild.id)
        
        # Only send messages to designated channel if configured
        if guild_id in self.config["welcome_channel"]:
            try:
                # Get goodbye message
                language = "goodbye_messages_en"  # Default to English
                if guild.preferred_locale and "pt" in guild.preferred_locale:
                    language = "goodbye_messages"
                
                messages = self.config[language]
                goodbye_message = random.choice(messages).format(
                    user=member.mention,
                    server=guild.name
                )
                
                # Create embed for goodbye message
                embed = discord.Embed(
                    title="Membro saiu",
                    description=goodbye_message,
                    color=discord.Color.red(),
                    timestamp=datetime.now()
                )
                
                # Add member info
                embed.add_field(
                    name="👤 Usuário",
                    value=f"{member.mention} ({member.name})",
                    inline=True
                )
                
                # Add new member count
                embed.add_field(
                    name="👥 Total de Membros",
                    value=f"{guild.member_count}",
                    inline=True
                )
                
                # Set thumbnail (user avatar)
                if member.avatar:
                    embed.set_thumbnail(url=member.avatar.url)
                
                # Send to the welcome channel
                channel_id = int(self.config["welcome_channel"][guild_id])
                channel = guild.get_channel(channel_id)
                if channel:
                    await channel.send(embed=embed)
                    logger.info(f"Goodbye message sent for {member}")
            except Exception as e:
                logger.error(f"Error sending goodbye message: {e}")

    def get_welcome_message(self, member):
        """Get a random welcome message formatted for the member"""
        guild = member.guild
        
        # Determine language (attempt to detect server language)
        language = "welcome_messages_en"  # Default to English
        if guild.preferred_locale and "pt" in guild.preferred_locale:
            language = "welcome_messages"
        
        messages = self.config[language]
        return random.choice(messages).format(
            user=member.mention,
            server=guild.name
        )
    
    @commands.group(name="welcome", invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def welcome(self, ctx):
        """
        Welcome message configuration commands
        Usage: !welcome
        """
        # Show current welcome configuration
        guild_id = str(ctx.guild.id)
        
        embed = discord.Embed(
            title="Sistema de Boas-vindas",
            description="Configuração atual do sistema de boas-vindas",
            color=discord.Color.blue()
        )
        
        # Status
        status = "✅ Ativado" if self.config["enabled"] else "❌ Desativado"
        embed.add_field(name="Status", value=status, inline=False)
        
        # Welcome Channel
        if guild_id in self.config["welcome_channel"]:
            channel_id = int(self.config["welcome_channel"][guild_id])
            channel = ctx.guild.get_channel(channel_id)
            channel_text = f"{channel.mention}" if channel else "Canal não encontrado"
        else:
            channel_text = "Não configurado"
        
        embed.add_field(name="Canal de Boas-vindas", value=channel_text, inline=False)
        
        # DM Welcome
        dm_status = "✅ Ativado" if self.config["dm_welcome"] else "❌ Desativado"
        embed.add_field(name="Mensagem Privada", value=dm_status, inline=False)
        
        # Commands
        commands_text = (
            "`!welcome channel #canal` - Define o canal de boas-vindas\n"
            "`!welcome toggle` - Ativa/desativa o sistema\n"
            "`!welcome dm` - Ativa/desativa mensagens privadas\n"
            "`!welcome test` - Testa a mensagem de boas-vindas"
        )
        embed.add_field(name="Comandos", value=commands_text, inline=False)
        
        await ctx.send(embed=embed)
    
    @welcome.command(name="channel")
    @commands.has_permissions(administrator=True)
    async def set_welcome_channel(self, ctx, channel: discord.TextChannel = None):
        """
        Set the welcome message channel
        Usage: !welcome channel #channel
        """
        if channel is None:
            await ctx.send("❌ Por favor, mencione um canal. Exemplo: `!welcome channel #boas-vindas`")
            return
            
        guild_id = str(ctx.guild.id)
        self.config["welcome_channel"][guild_id] = channel.id
        
        if self.save_config():
            await ctx.send(f"✅ Canal de boas-vindas definido como {channel.mention}")
        else:
            await ctx.send("❌ Erro ao salvar a configuração")
    
    @welcome.command(name="toggle")
    @commands.has_permissions(administrator=True)
    async def toggle_welcome(self, ctx):
        """
        Toggle welcome message system on/off
        Usage: !welcome toggle
        """
        self.config["enabled"] = not self.config["enabled"]
        
        if self.save_config():
            status = "ativado" if self.config["enabled"] else "desativado"
            await ctx.send(f"✅ Sistema de boas-vindas {status}")
        else:
            await ctx.send("❌ Erro ao salvar a configuração")
    
    @welcome.command(name="dm")
    @commands.has_permissions(administrator=True)
    async def toggle_dm_welcome(self, ctx):
        """
        Toggle DM welcome messages on/off
        Usage: !welcome dm
        """
        self.config["dm_welcome"] = not self.config["dm_welcome"]
        
        if self.save_config():
            status = "ativadas" if self.config["dm_welcome"] else "desativadas"
            await ctx.send(f"✅ Mensagens privadas de boas-vindas {status}")
        else:
            await ctx.send("❌ Erro ao salvar a configuração")
    
    @welcome.command(name="test")
    @commands.has_permissions(administrator=True)
    async def test_welcome(self, ctx):
        """
        Test the welcome message
        Usage: !welcome test
        """
        member = ctx.author
        guild = ctx.guild
        guild_id = str(guild.id)
        
        # Create test embed
        embed = discord.Embed(
            title=f"Teste: Bem-vindo(a) ao {guild.name}!",
            description=self.get_welcome_message(member),
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        embed.add_field(
            name="👤 Usuário",
            value=f"{member.mention} ({member.name})",
            inline=True
        )
        
        embed.add_field(
            name="👥 Total de Membros",
            value=f"{guild.member_count}",
            inline=True
        )
        
        embed.add_field(
            name="📅 Conta criada em",
            value=f"<t:{int(member.created_at.timestamp())}:F>",
            inline=False
        )
        
        if member.avatar:
            embed.set_thumbnail(url=member.avatar.url)
            
        embed.set_footer(
            text=f"TESTE - {self.bot.user.name}",
            icon_url=self.bot.user.avatar.url if self.bot.user.avatar else None
        )
        
        # Check if welcome channel is configured
        if guild_id in self.config["welcome_channel"]:
            channel_id = int(self.config["welcome_channel"][guild_id])
            channel = guild.get_channel(channel_id)
            if channel:
                await channel.send(embed=embed)
                await ctx.send(f"✅ Mensagem de teste enviada para {channel.mention}")
            else:
                await ctx.send(embed=embed)
                await ctx.send("❌ Canal de boas-vindas não encontrado. Exibindo mensagem aqui.")
        else:
            await ctx.send(embed=embed)
            await ctx.send("❓ Canal de boas-vindas não configurado. Exibindo mensagem aqui.")

async def setup(bot):
    await bot.add_cog(Welcome(bot))