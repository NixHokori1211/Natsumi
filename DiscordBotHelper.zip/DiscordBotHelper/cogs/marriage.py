"""
Marriage system for the Discord bot.
Allows users to engage in virtual relationships.
"""
import discord
from discord.ext import commands
import logging
import json
import os
import random
from datetime import datetime
import asyncio
from typing import Dict, List, Optional, Union, Tuple

logger = logging.getLogger(__name__)

class Marriage(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.marriage_data_file = "marriage_data.json"
        self.marriage_data = self.load_marriage_data()
        
        self.proposal_timeouts = {}  # Store active marriage proposals
        self.divorce_confirmations = {}  # Store divorce confirmations
        
        # Cute messages
        self.love_messages = [
            "💖 O amor está no ar! 💖",
            "💕 Um novo casal surgiu! 💕",
            "💘 Que o amor de vocês seja eterno! 💘",
            "💗 Juntos para sempre! 💗",
            "💝 Um amor verdadeiro nasceu hoje! 💝"
        ]
        
        self.divorce_messages = [
            "💔 Às vezes o amor acaba... 💔",
            "💔 Nem todo amor dura para sempre... 💔",
            "💔 Os caminhos se separaram... 💔",
            "💔 Um capítulo se fecha para que outro possa começar... 💔",
            "💔 Às vezes a melhor decisão é seguir em frente separados... 💔"
        ]
    
    def load_marriage_data(self):
        """Load marriage data from JSON file"""
        if os.path.exists(self.marriage_data_file):
            try:
                with open(self.marriage_data_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading marriage data: {e}")
                return {}
        return {}
    
    def save_marriage_data(self):
        """Save marriage data to JSON file"""
        try:
            with open(self.marriage_data_file, "w", encoding="utf-8") as f:
                json.dump(self.marriage_data, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving marriage data: {e}")
    
    def get_partner_id(self, user_id: int) -> Optional[int]:
        """Get a user's partner ID if they are married"""
        str_user_id = str(user_id)
        if str_user_id in self.marriage_data and self.marriage_data[str_user_id]["married"]:
            return int(self.marriage_data[str_user_id]["partner_id"])
        return None
    
    def is_married(self, user_id: int) -> bool:
        """Check if a user is married"""
        str_user_id = str(user_id)
        return (str_user_id in self.marriage_data and 
                self.marriage_data[str_user_id]["married"])
    
    def get_marriage_date(self, user_id: int) -> Optional[datetime]:
        """Get a user's marriage date if they are married"""
        str_user_id = str(user_id)
        if str_user_id in self.marriage_data and self.marriage_data[str_user_id]["married"]:
            try:
                return datetime.fromisoformat(self.marriage_data[str_user_id]["marriage_date"])
            except (ValueError, KeyError):
                return None
        return None
    
    def marry_users(self, user1_id: int, user2_id: int):
        """Marry two users"""
        str_user1_id = str(user1_id)
        str_user2_id = str(user2_id)
        
        marriage_date = datetime.now().isoformat()
        
        self.marriage_data[str_user1_id] = {
            "married": True,
            "partner_id": str_user2_id,
            "marriage_date": marriage_date,
            "affection": 0
        }
        
        self.marriage_data[str_user2_id] = {
            "married": True,
            "partner_id": str_user1_id,
            "marriage_date": marriage_date,
            "affection": 0
        }
        
        self.save_marriage_data()
    
    def divorce_users(self, user1_id: int, user2_id: int):
        """Divorce two users"""
        str_user1_id = str(user1_id)
        str_user2_id = str(user2_id)
        
        if str_user1_id in self.marriage_data:
            self.marriage_data[str_user1_id] = {
                "married": False,
                "partner_id": None,
                "marriage_date": None,
                "affection": 0
            }
        
        if str_user2_id in self.marriage_data:
            self.marriage_data[str_user2_id] = {
                "married": False,
                "partner_id": None,
                "marriage_date": None,
                "affection": 0
            }
        
        self.save_marriage_data()
    
    def increase_affection(self, user_id: int, amount: int = 1):
        """Increase affection between partners"""
        str_user_id = str(user_id)
        
        if str_user_id in self.marriage_data and self.marriage_data[str_user_id]["married"]:
            self.marriage_data[str_user_id]["affection"] += amount
            
            # Also increase partner's affection
            str_partner_id = self.marriage_data[str_user_id]["partner_id"]
            if str_partner_id in self.marriage_data:
                self.marriage_data[str_partner_id]["affection"] += amount
            
            self.save_marriage_data()
    
    def get_affection(self, user_id: int) -> int:
        """Get a user's affection level with their partner"""
        str_user_id = str(user_id)
        if str_user_id in self.marriage_data and "affection" in self.marriage_data[str_user_id]:
            return self.marriage_data[str_user_id]["affection"]
        return 0
    
    def get_affection_level_name(self, affection: int) -> str:
        """Get the name of a relationship based on affection level"""
        if affection >= 100:
            return "Soulmates 💞"
        elif affection >= 75:
            return "Deeply in Love 💗"
        elif affection >= 50:
            return "Loving Partners 💕"
        elif affection >= 25:
            return "Happily Married 💑"
        elif affection >= 10:
            return "Newlyweds 💍"
        else:
            return "Just Married 💒"
    
    @commands.group(invoke_without_command=True)
    async def marriage(self, ctx):
        """
        Sistema de casamento
        Usage: !marriage
        """
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="💍 Sistema de Casamento",
                description="Use estes comandos para gerenciar seu relacionamento virtual!",
                color=discord.Color.light_gray()
            )
            
            prefix = ctx.prefix
            
            embed.add_field(
                name="Comandos Disponíveis",
                value=(
                    f"**`{prefix}propose <@membro>`** - Propor casamento a alguém\n"
                    f"**`{prefix}marriage status [@membro]`** - Ver status de relacionamento\n"
                    f"**`{prefix}marriage divorce`** - Divorciar-se\n"
                    f"**`{prefix}marriage kiss`** - Beijar seu parceiro\n"
                    f"**`{prefix}marriage hug`** - Abraçar seu parceiro\n"
                    f"**`{prefix}marriage gift`** - Dar um presente ao seu parceiro"
                ),
                inline=False
            )
            
            await ctx.send(embed=embed)
    
    @commands.command(name="propose", aliases=["marry"])
    async def propose_marriage(self, ctx, member: discord.Member = None):
        """
        Propor casamento a alguém
        Usage: !propose <@membro> ou !marry <@membro>
        """
        if member is None:
            return await ctx.send("❌ Por favor, mencione a pessoa que você quer pedir em casamento!")
        
        if member.id == ctx.author.id:
            return await ctx.send("❌ Você não pode se casar consigo mesmo!")
        
        if member.bot:
            return await ctx.send("❌ Você não pode se casar com um bot!")
        
        # Check if either user is already married
        if self.is_married(ctx.author.id):
            partner_id = self.get_partner_id(ctx.author.id)
            partner = self.bot.get_user(partner_id)
            partner_name = partner.name if partner else "alguém"
            return await ctx.send(f"❌ Você já está casado(a) com **{partner_name}**!")
        
        if self.is_married(member.id):
            partner_id = self.get_partner_id(member.id)
            partner = self.bot.get_user(partner_id)
            partner_name = partner.name if partner else "alguém"
            return await ctx.send(f"❌ **{member.name}** já está casado(a) com **{partner_name}**!")
        
        # Check if there's already an active proposal from this user
        if ctx.author.id in self.proposal_timeouts:
            return await ctx.send("❌ Você já tem um pedido de casamento pendente!")
        
        # Create a proposal embed
        embed = discord.Embed(
            title="💍 Pedido de Casamento",
            description=f"**{ctx.author.name}** pediu **{member.name}** em casamento!",
            color=discord.Color.pink()
        )
        
        embed.add_field(
            name="O que fazer?",
            value=f"{member.mention}, você aceita este pedido de casamento? Responda com **sim** ou **não**.",
            inline=False
        )
        
        embed.set_thumbnail(url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
        embed.set_footer(text="Este pedido expira em 60 segundos.")
        
        proposal_msg = await ctx.send(embed=embed)
        
        # Store the proposal in active proposals
        self.proposal_timeouts[ctx.author.id] = {
            "target_id": member.id,
            "expiry": datetime.now().timestamp() + 60
        }
        
        def check(message):
            if message.author.id != member.id or message.channel.id != ctx.channel.id:
                return False
            
            content = message.content.lower()
            return content in ["sim", "s", "yes", "y", "não", "nao", "n", "no"]
        
        try:
            message = await self.bot.wait_for("message", check=check, timeout=60.0)
            
            response = message.content.lower()
            if response in ["sim", "s", "yes", "y"]:
                # Marry the users
                self.marry_users(ctx.author.id, member.id)
                
                # Create response embed
                love_message = random.choice(self.love_messages)
                
                embed = discord.Embed(
                    title="💍 Casamento Realizado!",
                    description=f"**{ctx.author.name}** e **{member.name}** agora estão casados! {love_message}",
                    color=discord.Color.magenta()
                )
                
                embed.set_thumbnail(url="https://i.imgur.com/TQjM9Iv.png")  # Wedding rings image
                embed.set_footer(text=f"Casados em {datetime.now().strftime('%d/%m/%Y')}")
                
                await ctx.send(embed=embed)
            else:
                await ctx.send(f"💔 **{member.name}** recusou o pedido de casamento de **{ctx.author.name}**...")
        
        except asyncio.TimeoutError:
            await ctx.send(f"⏰ O pedido de casamento de **{ctx.author.name}** expirou...")
        
        finally:
            # Remove the active proposal
            if ctx.author.id in self.proposal_timeouts:
                del self.proposal_timeouts[ctx.author.id]
    
    @marriage.command(name="status")
    async def marriage_status(self, ctx, member: discord.Member = None):
        """
        Ver status de relacionamento
        Usage: !marriage status [@membro]
        """
        target = member or ctx.author
        
        if not self.is_married(target.id):
            if target.id == ctx.author.id:
                return await ctx.send("❌ Você não está casado(a) com ninguém!")
            else:
                return await ctx.send(f"❌ **{target.name}** não está casado(a) com ninguém!")
        
        partner_id = self.get_partner_id(target.id)
        partner = self.bot.get_user(partner_id)
        
        if not partner:
            try:
                partner = await self.bot.fetch_user(partner_id)
            except discord.errors.NotFound:
                partner_name = "Usuário Desconhecido"
        else:
            partner_name = partner.name
        
        marriage_date = self.get_marriage_date(target.id)
        marriage_date_str = marriage_date.strftime("%d/%m/%Y") if marriage_date else "Data desconhecida"
        
        affection = self.get_affection(target.id)
        affection_level = self.get_affection_level_name(affection)
        
        # Calculate days married
        if marriage_date:
            days_married = (datetime.now() - marriage_date).days
            days_text = f"{days_married} dias"
        else:
            days_text = "Tempo desconhecido"
        
        embed = discord.Embed(
            title=f"💑 Status de Relacionamento",
            description=f"Informações sobre o casamento de **{target.name}**",
            color=discord.Color.magenta()
        )
        
        embed.add_field(name="Casado(a) com", value=partner_name, inline=True)
        embed.add_field(name="Data do Casamento", value=marriage_date_str, inline=True)
        embed.add_field(name="Tempo de Casamento", value=days_text, inline=True)
        embed.add_field(name="Nível de Afeição", value=f"{affection} pontos", inline=True)
        embed.add_field(name="Status", value=affection_level, inline=True)
        
        if partner and partner.avatar:
            embed.set_thumbnail(url=partner.avatar.url)
        
        await ctx.send(embed=embed)
    
    @marriage.command(name="divorce")
    async def divorce(self, ctx):
        """
        Divorciar-se
        Usage: !marriage divorce
        """
        if not self.is_married(ctx.author.id):
            return await ctx.send("❌ Você não está casado(a) com ninguém!")
        
        partner_id = self.get_partner_id(ctx.author.id)
        partner = self.bot.get_user(partner_id)
        partner_name = partner.name if partner else "seu parceiro(a)"
        
        # Check if there's already a divorce confirmation
        if ctx.author.id in self.divorce_confirmations:
            # Process the divorce
            self.divorce_users(ctx.author.id, partner_id)
            
            divorce_message = random.choice(self.divorce_messages)
            
            embed = discord.Embed(
                title="💔 Divórcio Finalizado",
                description=f"**{ctx.author.name}** se divorciou de **{partner_name}**.\n\n{divorce_message}",
                color=discord.Color.dark_red()
            )
            
            # Remove divorce confirmation
            del self.divorce_confirmations[ctx.author.id]
            
            await ctx.send(embed=embed)
            
            # Notify the partner if they're in a mutual server
            if partner:
                try:
                    await partner.send(f"💔 **{ctx.author.name}** se divorciou de você...")
                except discord.errors.Forbidden:
                    # Can't DM the user, just continue
                    pass
        else:
            # Ask for confirmation
            embed = discord.Embed(
                title="💔 Confirmação de Divórcio",
                description=f"Você tem certeza que deseja se divorciar de **{partner_name}**?",
                color=discord.Color.red()
            )
            
            embed.add_field(
                name="Confirmação",
                value="Digite `!marriage divorce` novamente para confirmar o divórcio.",
                inline=False
            )
            
            embed.set_footer(text="Esta confirmação expira em 30 segundos.")
            
            await ctx.send(embed=embed)
            
            # Store confirmation and set expiry
            self.divorce_confirmations[ctx.author.id] = datetime.now().timestamp() + 30
            
            # Remove the confirmation after 30 seconds
            await asyncio.sleep(30)
            if ctx.author.id in self.divorce_confirmations:
                del self.divorce_confirmations[ctx.author.id]
    
    @marriage.command(name="kiss")
    async def kiss_partner(self, ctx):
        """
        Beijar seu parceiro(a)
        Usage: !marriage kiss
        """
        if not self.is_married(ctx.author.id):
            return await ctx.send("❌ Você não está casado(a) com ninguém!")
        
        partner_id = self.get_partner_id(ctx.author.id)
        partner = self.bot.get_user(partner_id)
        partner_name = partner.name if partner else "seu parceiro(a)"
        
        # Check if partner is in the same channel
        if partner and ctx.guild and partner in ctx.guild.members:
            # Increase affection
            self.increase_affection(ctx.author.id, 2)
            
            # Get random kiss GIF
            kiss_gifs = [
                "https://i.imgur.com/0Ri9sfq.gif",
                "https://i.imgur.com/EMdpmXW.gif",
                "https://i.imgur.com/Y9iLoiv.gif",
                "https://i.imgur.com/ZlqZy8S.gif",
                "https://i.imgur.com/O7d63Mh.gif"
            ]
            
            gif_url = random.choice(kiss_gifs)
            
            embed = discord.Embed(
                title="💋 Beijo Romântico",
                description=f"**{ctx.author.name}** deu um beijo em **{partner_name}**! Que fofo!",
                color=discord.Color.red()
            )
            
            embed.set_image(url=gif_url)
            embed.set_footer(text="Afeição +2")
            
            await ctx.send(embed=embed)
        else:
            await ctx.send(f"❤️ Você mandou um beijo virtual para **{partner_name}**!")
    
    @marriage.command(name="hug")
    async def hug_partner(self, ctx):
        """
        Abraçar seu parceiro(a)
        Usage: !marriage hug
        """
        if not self.is_married(ctx.author.id):
            return await ctx.send("❌ Você não está casado(a) com ninguém!")
        
        partner_id = self.get_partner_id(ctx.author.id)
        partner = self.bot.get_user(partner_id)
        partner_name = partner.name if partner else "seu parceiro(a)"
        
        # Check if partner is in the same channel
        if partner and ctx.guild and partner in ctx.guild.members:
            # Increase affection
            self.increase_affection(ctx.author.id, 1)
            
            # Get random hug GIF
            hug_gifs = [
                "https://i.imgur.com/aBdIEEu.gif",
                "https://i.imgur.com/03grRGj.gif",
                "https://i.imgur.com/EuIBiLi.gif",
                "https://i.imgur.com/XV7V6dD.gif",
                "https://i.imgur.com/FuQH9pJ.gif"
            ]
            
            gif_url = random.choice(hug_gifs)
            
            embed = discord.Embed(
                title="🤗 Abraço Caloroso",
                description=f"**{ctx.author.name}** deu um abraço em **{partner_name}**!",
                color=discord.Color.gold()
            )
            
            embed.set_image(url=gif_url)
            embed.set_footer(text="Afeição +1")
            
            await ctx.send(embed=embed)
        else:
            await ctx.send(f"💌 Você mandou um abraço virtual para **{partner_name}**!")
    
    @marriage.command(name="gift")
    async def gift_partner(self, ctx):
        """
        Dar um presente ao seu parceiro(a)
        Usage: !marriage gift
        """
        if not self.is_married(ctx.author.id):
            return await ctx.send("❌ Você não está casado(a) com ninguém!")
        
        partner_id = self.get_partner_id(ctx.author.id)
        partner = self.bot.get_user(partner_id)
        partner_name = partner.name if partner else "seu parceiro(a)"
        
        # Gifts and their affection values
        gifts = [
            ("🌹 Rosa", 3),
            ("🍫 Chocolate", 4),
            ("💝 Caixa de Presentes", 5),
            ("💍 Anel Brilhante", 7),
            ("🧸 Ursinho de Pelúcia", 4),
            ("📱 Smartphone Novo", 6),
            ("🎮 Videogame", 5),
            ("👗 Roupa Nova", 4),
            ("🎵 Playlist Especial", 3),
            ("✉️ Carta de Amor", 6)
        ]
        
        gift, affection = random.choice(gifts)
        
        # Increase affection
        self.increase_affection(ctx.author.id, affection)
        
        embed = discord.Embed(
            title="🎁 Presente Especial",
            description=f"**{ctx.author.name}** deu um presente para **{partner_name}**!\n\nO presente foi: **{gift}**",
            color=discord.Color.purple()
        )
        
        embed.set_footer(text=f"Afeição +{affection}")
        
        await ctx.send(embed=embed)
        
        # Notify the partner if they're in a mutual server
        if partner:
            try:
                await partner.send(f"🎁 **{ctx.author.name}** te enviou um presente: **{gift}**!")
            except discord.errors.Forbidden:
                # Can't DM the user, just continue
                pass

async def setup(bot):
    await bot.add_cog(Marriage(bot))