"""
Action commands for the Discord bot.
Allows users to interact with each other using fun anime-style GIFs.
"""
import random
import discord
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class Actions(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.action_images = {
            "hug": [
                "https://i.imgur.com/aBdIEEu.gif",
                "https://i.imgur.com/03grRGj.gif",
                "https://i.imgur.com/EuIBiLi.gif",
                "https://i.imgur.com/XV7V6dD.gif",
                "https://i.imgur.com/FuQH9pJ.gif"
            ],
            "pat": [
                "https://i.imgur.com/LUypjw3.gif",
                "https://i.imgur.com/Jgz0dhh.gif",
                "https://i.imgur.com/UWbKpx8.gif",
                "https://i.imgur.com/2lacG7l.gif",
                "https://i.imgur.com/UYbuodt.gif"
            ],
            "slap": [
                "https://i.imgur.com/fm49srQ.gif",
                "https://i.imgur.com/4MQkDKm.gif",
                "https://i.imgur.com/o2SJYUS.gif",
                "https://i.imgur.com/oOCq3Bt.gif",
                "https://i.imgur.com/Agwwaj6.gif"
            ],
            "kiss": [
                "https://i.imgur.com/0Ri9sfq.gif",
                "https://i.imgur.com/EMdpmXW.gif",
                "https://i.imgur.com/Y9iLoiv.gif",
                "https://i.imgur.com/ZlqZy8S.gif",
                "https://i.imgur.com/O7d63Mh.gif"
            ],
            "poke": [
                "https://i.imgur.com/WG8EKwM.gif",
                "https://i.imgur.com/8VbuGsb.gif",
                "https://i.imgur.com/mJJMBOv.gif",
                "https://i.imgur.com/q52ARdv.gif",
                "https://i.imgur.com/GZ5fOTJ.gif"
            ],
            "blush": [
                "https://i.imgur.com/5PtbLfz.gif",
                "https://i.imgur.com/O9eXpRK.gif",
                "https://i.imgur.com/1RQFb6u.gif",
                "https://i.imgur.com/5Hs93Qd.gif",
                "https://i.imgur.com/GcGQXbn.gif"
            ],
            "cuddle": [
                "https://i.imgur.com/Fn5B5ol.gif",
                "https://i.imgur.com/y1cLMKS.gif",
                "https://i.imgur.com/q3xfKPb.gif",
                "https://i.imgur.com/0ZeYsrQ.gif",
                "https://i.imgur.com/eKcWCgS.gif"
            ],
            "cry": [
                "https://i.imgur.com/Wl7nbQL.gif",
                "https://i.imgur.com/I7xQ7US.gif",
                "https://i.imgur.com/o8JQtVk.gif",
                "https://i.imgur.com/FWKvG8P.gif",
                "https://i.imgur.com/InXA2yS.gif"
            ]
        }
    
    async def send_action_embed(self, ctx, action, target, gif_url):
        """Send an embed with the action GIF and appropriate message"""
        action_messages = {
            "hug": f"**{ctx.author.name}** deu um abraço em **{target.name}**! 🤗",
            "pat": f"**{ctx.author.name}** deu tapinhas em **{target.name}**! 👋",
            "slap": f"**{ctx.author.name}** deu um tapa em **{target.name}**! 👋",
            "kiss": f"**{ctx.author.name}** deu um beijo em **{target.name}**! 💋",
            "poke": f"**{ctx.author.name}** cutucou **{target.name}**! 👉",
            "blush": f"**{ctx.author.name}** ficou envergonhado(a)! 😳",
            "cuddle": f"**{ctx.author.name}** aconchegou **{target.name}**! 🤗",
            "cry": f"**{ctx.author.name}** está chorando! 😭"
        }
        
        embed = discord.Embed(
            title=action.capitalize(),
            description=action_messages.get(action, f"{ctx.author.name} fez algo com {target.name}"),
            color=discord.Color.purple()
        )
        embed.set_image(url=gif_url)
        embed.set_footer(text=f"Solicitado por {ctx.author.name}")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def hug(self, ctx, member: discord.Member = None):
        """
        Dê um abraço em alguém
        Usage: !hug [@membro]
        """
        if member is None:
            return await ctx.send(f"Por favor, mencione alguém para abraçar! `{ctx.prefix}hug @usuário`")
        
        if member.id == ctx.author.id:
            return await ctx.send("Você não pode abraçar a si mesmo! 😅")
        
        gif_url = random.choice(self.action_images["hug"])
        await self.send_action_embed(ctx, "hug", member, gif_url)
    
    @commands.command()
    async def pat(self, ctx, member: discord.Member = None):
        """
        Dê tapinhas na cabeça de alguém
        Usage: !pat [@membro]
        """
        if member is None:
            return await ctx.send(f"Por favor, mencione alguém para dar tapinhas! `{ctx.prefix}pat @usuário`")
        
        if member.id == ctx.author.id:
            return await ctx.send("Você não pode dar tapinhas em si mesmo! 😅")
        
        gif_url = random.choice(self.action_images["pat"])
        await self.send_action_embed(ctx, "pat", member, gif_url)
    
    @commands.command()
    async def slap(self, ctx, member: discord.Member = None):
        """
        Dê um tapa em alguém
        Usage: !slap [@membro]
        """
        if member is None:
            return await ctx.send(f"Por favor, mencione alguém para dar um tapa! `{ctx.prefix}slap @usuário`")
        
        if member.id == ctx.author.id:
            return await ctx.send("Você não pode dar um tapa em si mesmo! 😅")
        
        gif_url = random.choice(self.action_images["slap"])
        await self.send_action_embed(ctx, "slap", member, gif_url)
    
    @commands.command()
    async def kiss(self, ctx, member: discord.Member = None):
        """
        Dê um beijo em alguém
        Usage: !kiss [@membro]
        """
        if member is None:
            return await ctx.send(f"Por favor, mencione alguém para beijar! `{ctx.prefix}kiss @usuário`")
        
        if member.id == ctx.author.id:
            return await ctx.send("Você não pode beijar a si mesmo! 😅")
        
        gif_url = random.choice(self.action_images["kiss"])
        await self.send_action_embed(ctx, "kiss", member, gif_url)
    
    @commands.command()
    async def poke(self, ctx, member: discord.Member = None):
        """
        Cutuque alguém
        Usage: !poke [@membro]
        """
        if member is None:
            return await ctx.send(f"Por favor, mencione alguém para cutucar! `{ctx.prefix}poke @usuário`")
        
        if member.id == ctx.author.id:
            return await ctx.send("Você não pode cutucar a si mesmo! 😅")
        
        gif_url = random.choice(self.action_images["poke"])
        await self.send_action_embed(ctx, "poke", member, gif_url)
    
    @commands.command()
    async def blush(self, ctx):
        """
        Fique envergonhado(a)
        Usage: !blush
        """
        gif_url = random.choice(self.action_images["blush"])
        # For blush, target is the author since it's a self-action
        await self.send_action_embed(ctx, "blush", ctx.author, gif_url)
    
    @commands.command()
    async def cuddle(self, ctx, member: discord.Member = None):
        """
        Aconchegue-se com alguém
        Usage: !cuddle [@membro]
        """
        if member is None:
            return await ctx.send(f"Por favor, mencione alguém para aconchegar! `{ctx.prefix}cuddle @usuário`")
        
        if member.id == ctx.author.id:
            return await ctx.send("Você não pode aconchegar a si mesmo! 😅")
        
        gif_url = random.choice(self.action_images["cuddle"])
        await self.send_action_embed(ctx, "cuddle", member, gif_url)
    
    @commands.command()
    async def cry(self, ctx):
        """
        Chore
        Usage: !cry
        """
        gif_url = random.choice(self.action_images["cry"])
        # For cry, target is the author since it's a self-action
        await self.send_action_embed(ctx, "cry", ctx.author, gif_url)

async def setup(bot):
    await bot.add_cog(Actions(bot))