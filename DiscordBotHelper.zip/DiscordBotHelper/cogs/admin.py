"""
Administrator commands for the Discord bot.
These commands should only be usable by the bot owner or administrators.
"""
import discord
from discord.ext import commands
import logging
import sys
import os
import platform
import time
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.start_time = datetime.now()
    
    @commands.command(name="status")
    @commands.is_owner()
    async def status(self, ctx):
        """
        Display bot status information
        Usage: !status
        """
        # Calculate uptime
        uptime = datetime.now() - self.start_time
        hours, remainder = divmod(int(uptime.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days, hours = divmod(hours, 24)
        
        # Get system information
        py_version = platform.python_version()
        discord_version = discord.__version__
        os_info = f"{platform.system()} {platform.release()}"
        
        # Get bot information
        guild_count = len(self.bot.guilds)
        member_count = sum(g.member_count for g in self.bot.guilds)
        command_count = len(self.bot.commands)
        
        embed = discord.Embed(
            title="Bot Status",
            description="Detailed bot status and statistics",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        # Add bot fields
        embed.add_field(name="Bot User", value=f"{self.bot.user} (ID: {self.bot.user.id})", inline=False)
        embed.add_field(name="Uptime", value=f"{days}d {hours}h {minutes}m {seconds}s", inline=True)
        embed.add_field(name="Ping", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        
        # Add server stats
        embed.add_field(name="Guilds", value=str(guild_count), inline=True)
        embed.add_field(name="Members", value=str(member_count), inline=True)
        embed.add_field(name="Commands", value=str(command_count), inline=True)
        
        # Add system fields
        embed.add_field(name="Python Version", value=py_version, inline=True)
        embed.add_field(name="Discord.py Version", value=discord_version, inline=True)
        embed.add_field(name="Operating System", value=os_info, inline=True)
        
        embed.set_footer(text=f"Requested by {ctx.author.name}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await ctx.send(embed=embed)
        logger.info(f"Status command used by {ctx.author}")
    
    @commands.command(name="reload")
    @commands.is_owner()
    async def reload_cog(self, ctx, cog_name=None):
        """
        Reload a specific cog or all cogs
        Usage: !reload [cog_name]
        """
        if cog_name:
            # Format the cog name correctly
            if not cog_name.startswith("cogs."):
                cog_name = f"cogs.{cog_name}"
                
            try:
                await self.bot.reload_extension(cog_name)
                await ctx.send(f"✅ Cog `{cog_name}` has been reloaded successfully.")
                logger.info(f"Cog {cog_name} reloaded by {ctx.author}")
            except Exception as e:
                await ctx.send(f"❌ Failed to reload cog `{cog_name}`: {str(e)}")
                logger.error(f"Failed to reload cog {cog_name}: {str(e)}")
        else:
            # Reload all cogs
            reloaded = []
            failed = []
            
            for extension in list(self.bot.extensions):
                try:
                    await self.bot.reload_extension(extension)
                    reloaded.append(extension)
                except Exception as e:
                    failed.append(f"{extension}: {str(e)}")
            
            status_message = "**Cog Reload Status**\n"
            
            if reloaded:
                status_message += "✅ **Reloaded:**\n- " + "\n- ".join(reloaded) + "\n"
            
            if failed:
                status_message += "❌ **Failed:**\n- " + "\n- ".join(failed)
            
            await ctx.send(status_message)
            logger.info(f"All cogs reloaded by {ctx.author}")
    
    @commands.command(name="shutdown")
    @commands.is_owner()
    async def shutdown(self, ctx):
        """
        Shut down the bot
        Usage: !shutdown
        """
        await ctx.send("⚠️ Shutting down the bot... Goodbye!")
        logger.warning(f"Bot shutdown initiated by {ctx.author}")
        await self.bot.close()
    
    @commands.command(name="guilds")
    @commands.is_owner()
    async def list_guilds(self, ctx):
        """
        List all guilds the bot is in
        Usage: !guilds
        """
        guilds_list = sorted(self.bot.guilds, key=lambda g: g.member_count, reverse=True)
        
        embed = discord.Embed(
            title="Guilds List",
            description=f"Bot is in {len(guilds_list)} guilds",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        total_members = 0
        for guild in guilds_list[:25]:  # Discord embeds have a limit on fields
            total_members += guild.member_count
            embed.add_field(
                name=guild.name, 
                value=f"ID: {guild.id}\nMembers: {guild.member_count}\nOwner: {guild.owner}", 
                inline=False
            )
        
        embed.set_footer(text=f"Total members: {total_members}")
        
        await ctx.send(embed=embed)
        
        # If there are more than 25 guilds, let the user know
        if len(guilds_list) > 25:
            await ctx.send(f"Note: Only showing 25/{len(guilds_list)} guilds due to embed field limits.")
        
        logger.info(f"Guilds command used by {ctx.author}")

async def setup(bot):
    await bot.add_cog(Admin(bot))