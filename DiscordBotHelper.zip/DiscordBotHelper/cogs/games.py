"""
Mini-games for the Discord bot.
Includes various interactive games for users to play.
"""
import random
import asyncio
import discord
from discord.ext import commands
import logging
import json
import os
import re
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

class Games(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.trivia_data_file = "trivia_data.json"
        self.pokemon_data_file = "pokemon_data.json"
        self.anime_char_data_file = "anime_characters.json"
        
        # Load data files or create defaults
        self.trivia_data = self.load_data(self.trivia_data_file) or self.default_trivia()
        self.pokemon_data = self.load_data(self.pokemon_data_file) or self.default_pokemon()
        self.anime_char_data = self.load_data(self.anime_char_data_file) or self.default_anime_chars()
        
        # Active games trackers
        self.active_games = {}
    
    def load_data(self, filename):
        """Load data from a JSON file"""
        if os.path.exists(filename):
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading {filename}: {e}")
                return None
        return None
    
    def save_data(self, data, filename):
        """Save data to a JSON file"""
        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving {filename}: {e}")
    
    def default_trivia(self):
        """Create default trivia questions if no file exists"""
        return {
            "general": [
                {
                    "question": "Qual é a capital do Brasil?",
                    "options": ["Rio de Janeiro", "São Paulo", "Brasília", "Salvador"],
                    "answer": 2
                },
                {
                    "question": "Quem pintou a Mona Lisa?",
                    "options": ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Michelangelo"],
                    "answer": 1
                },
                {
                    "question": "Qual é o maior planeta do Sistema Solar?",
                    "options": ["Terra", "Saturno", "Júpiter", "Netuno"],
                    "answer": 2
                }
            ],
            "science": [
                {
                    "question": "Qual é o símbolo químico para o ouro?",
                    "options": ["Au", "Ag", "Fe", "Pb"],
                    "answer": 0
                },
                {
                    "question": "Qual é a menor partícula de um elemento químico?",
                    "options": ["Molécula", "Átomo", "Elétron", "Próton"],
                    "answer": 1
                }
            ],
            "gaming": [
                {
                    "question": "Em que ano foi lançado o primeiro jogo da série Minecraft?",
                    "options": ["2009", "2010", "2011", "2012"],
                    "answer": 0
                },
                {
                    "question": "Qual dessas NÃO é uma franquia da Nintendo?",
                    "options": ["Mario", "The Legend of Zelda", "Sonic the Hedgehog", "Pokemon"],
                    "answer": 2
                }
            ],
            "anime": [
                {
                    "question": "Qual é o nome do protagonista de Naruto?",
                    "options": ["Sasuke Uchiha", "Naruto Uzumaki", "Kakashi Hatake", "Sakura Haruno"],
                    "answer": 1
                },
                {
                    "question": "Qual é o nome da protagonista de Sailor Moon?",
                    "options": ["Rei Hino", "Ami Mizuno", "Usagi Tsukino", "Minako Aino"],
                    "answer": 2
                }
            ]
        }
    
    def default_pokemon(self):
        """Create default Pokemon data if no file exists"""
        return [
            {"name": "Pikachu", "image_url": "https://assets.pokemon.com/assets/cms2/img/pokedex/full/025.png"},
            {"name": "Charizard", "image_url": "https://assets.pokemon.com/assets/cms2/img/pokedex/full/006.png"},
            {"name": "Bulbasaur", "image_url": "https://assets.pokemon.com/assets/cms2/img/pokedex/full/001.png"},
            {"name": "Squirtle", "image_url": "https://assets.pokemon.com/assets/cms2/img/pokedex/full/007.png"},
            {"name": "Jigglypuff", "image_url": "https://assets.pokemon.com/assets/cms2/img/pokedex/full/039.png"},
            {"name": "Eevee", "image_url": "https://assets.pokemon.com/assets/cms2/img/pokedex/full/133.png"},
            {"name": "Mewtwo", "image_url": "https://assets.pokemon.com/assets/cms2/img/pokedex/full/150.png"},
            {"name": "Snorlax", "image_url": "https://assets.pokemon.com/assets/cms2/img/pokedex/full/143.png"},
            {"name": "Gengar", "image_url": "https://assets.pokemon.com/assets/cms2/img/pokedex/full/094.png"},
            {"name": "Dragonite", "image_url": "https://assets.pokemon.com/assets/cms2/img/pokedex/full/149.png"}
        ]
    
    def default_anime_chars(self):
        """Create default anime character data if no file exists"""
        return [
            {"name": "Naruto Uzumaki", "anime": "Naruto", "image_url": "https://i.imgur.com/DF0qm0r.png"},
            {"name": "Monkey D. Luffy", "anime": "One Piece", "image_url": "https://i.imgur.com/Wg6wiH6.png"},
            {"name": "Goku", "anime": "Dragon Ball", "image_url": "https://i.imgur.com/nAzgBLA.png"},
            {"name": "Eren Yeager", "anime": "Attack on Titan", "image_url": "https://i.imgur.com/jOZeRFE.png"},
            {"name": "Ichigo Kurosaki", "anime": "Bleach", "image_url": "https://i.imgur.com/xUuNKZ4.png"},
            {"name": "Sailor Moon", "anime": "Sailor Moon", "image_url": "https://i.imgur.com/1xJPbMp.png"},
            {"name": "Light Yagami", "anime": "Death Note", "image_url": "https://i.imgur.com/6hfBmrN.png"},
            {"name": "Spike Spiegel", "anime": "Cowboy Bebop", "image_url": "https://i.imgur.com/UzJpwrY.png"},
            {"name": "Guts", "anime": "Berserk", "image_url": "https://i.imgur.com/8jxSMsU.png"},
            {"name": "Vegeta", "anime": "Dragon Ball", "image_url": "https://i.imgur.com/wqZYzPI.png"}
        ]
    
    @commands.group(aliases=["game"])
    async def games(self, ctx):
        """
        Jogar mini-games
        Usage: !game <mini-game>
        """
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="🎮 Mini-Games",
                description="Escolha um jogo para jogar!",
                color=discord.Color.purple()
            )
            
            embed.add_field(
                name="Comandos disponíveis", 
                value=(
                    "**`!game pokemon`** - Adivinhe o Pokémon\n"
                    "**`!game character`** - Adivinhe o personagem de anime\n"
                    "**`!game number`** - Adivinhe o número\n"
                    "**`!trivia`** - Jogo de perguntas e respostas"
                ),
                inline=False
            )
            
            await ctx.send(embed=embed)
    
    @games.command(name="pokemon")
    async def guess_pokemon(self, ctx):
        """
        Adivinhe o Pokémon
        Usage: !game pokemon
        """
        # Check if user is already in a game
        if ctx.author.id in self.active_games:
            return await ctx.send("❌ Você já está em um jogo! Termine-o primeiro.")
        
        self.active_games[ctx.author.id] = "pokemon"
        
        # Select random Pokemon
        pokemon = random.choice(self.pokemon_data)
        pokemon_name = pokemon["name"].lower()
        pokemon_image = pokemon["image_url"]
        
        embed = discord.Embed(
            title="Quem é esse Pokémon?",
            description="Você tem 30 segundos para adivinhar o nome deste Pokémon!",
            color=discord.Color.blue()
        )
        
        embed.set_image(url=pokemon_image)
        embed.set_footer(text="Digite o nome do Pokémon para responder!")
        
        await ctx.send(embed=embed)
        
        def check(message):
            return message.author == ctx.author and message.channel == ctx.channel
        
        try:
            message = await self.bot.wait_for('message', check=check, timeout=30.0)
            guess = message.content.lower()
            
            if guess == pokemon_name:
                await ctx.send(f"✅ **Correto!** Este Pokémon é **{pokemon['name']}**!")
            else:
                await ctx.send(f"❌ **Incorreto!** Este Pokémon é **{pokemon['name']}**.")
        
        except asyncio.TimeoutError:
            await ctx.send(f"⏰ **Tempo esgotado!** Este Pokémon é **{pokemon['name']}**.")
        
        finally:
            if ctx.author.id in self.active_games:
                del self.active_games[ctx.author.id]
    
    @games.command(name="character")
    async def guess_character(self, ctx):
        """
        Adivinhe o personagem de anime
        Usage: !game character
        """
        # Check if user is already in a game
        if ctx.author.id in self.active_games:
            return await ctx.send("❌ Você já está em um jogo! Termine-o primeiro.")
        
        self.active_games[ctx.author.id] = "character"
        
        # Select random character
        character = random.choice(self.anime_char_data)
        character_name = character["name"].lower()
        character_image = character["image_url"]
        
        embed = discord.Embed(
            title="Quem é esse personagem de anime?",
            description="Você tem 30 segundos para adivinhar o nome deste personagem!",
            color=discord.Color.red()
        )
        
        embed.set_image(url=character_image)
        embed.set_footer(text="Digite o nome do personagem para responder!")
        
        await ctx.send(embed=embed)
        
        def check(message):
            return message.author == ctx.author and message.channel == ctx.channel
        
        try:
            message = await self.bot.wait_for('message', check=check, timeout=30.0)
            guess = message.content.lower()
            
            # Check if the guess is close enough (character names can be complex)
            if guess == character_name.lower() or character_name.lower().startswith(guess) or guess in character_name.lower():
                await ctx.send(f"✅ **Correto!** Este personagem é **{character['name']}** de **{character['anime']}**!")
            else:
                await ctx.send(f"❌ **Incorreto!** Este personagem é **{character['name']}** de **{character['anime']}**.")
        
        except asyncio.TimeoutError:
            await ctx.send(f"⏰ **Tempo esgotado!** Este personagem é **{character['name']}** de **{character['anime']}**.")
        
        finally:
            if ctx.author.id in self.active_games:
                del self.active_games[ctx.author.id]
    
    @games.command(name="number")
    async def guess_number(self, ctx):
        """
        Adivinhe o número
        Usage: !game number
        """
        # Check if user is already in a game
        if ctx.author.id in self.active_games:
            return await ctx.send("❌ Você já está em um jogo! Termine-o primeiro.")
        
        self.active_games[ctx.author.id] = "number"
        
        # Generate random number between 1 and 100
        number = random.randint(1, 100)
        guesses = 0
        max_guesses = 10
        
        embed = discord.Embed(
            title="🔢 Adivinhe o Número",
            description="Estou pensando em um número entre 1 e 100. Você tem 10 tentativas para adivinhar!",
            color=discord.Color.gold()
        )
        
        embed.set_footer(text=f"Digite um número para tentar adivinhar! | Tentativas: {guesses}/{max_guesses}")
        
        await ctx.send(embed=embed)
        
        def check(message):
            return (
                message.author == ctx.author and 
                message.channel == ctx.channel and 
                message.content.isdigit() and 
                1 <= int(message.content) <= 100
            )
        
        while guesses < max_guesses:
            try:
                message = await self.bot.wait_for('message', check=check, timeout=30.0)
                guess = int(message.content)
                guesses += 1
                
                if guess == number:
                    await ctx.send(f"🎉 **Parabéns!** Você acertou o número **{number}** em **{guesses}** tentativas!")
                    break
                elif guess < number:
                    await ctx.send(f"⬆️ O número é **maior** que {guess}! | Tentativas: {guesses}/{max_guesses}")
                else:
                    await ctx.send(f"⬇️ O número é **menor** que {guess}! | Tentativas: {guesses}/{max_guesses}")
            
            except asyncio.TimeoutError:
                await ctx.send(f"⏰ **Tempo esgotado!** O número correto era **{number}**.")
                break
        
        if guesses >= max_guesses and not guess == number:
            await ctx.send(f"❌ **Você esgotou suas tentativas!** O número correto era **{number}**.")
        
        if ctx.author.id in self.active_games:
            del self.active_games[ctx.author.id]
    
    @commands.command()
    async def trivia(self, ctx, category: str = None):
        """
        Jogo de perguntas e respostas
        Usage: !trivia [categoria]
        Categorias: general, science, gaming, anime
        """
        # Check if user is already in a game
        if ctx.author.id in self.active_games:
            return await ctx.send("❌ Você já está em um jogo! Termine-o primeiro.")
        
        self.active_games[ctx.author.id] = "trivia"
        
        # List available categories if not specified or invalid
        available_categories = list(self.trivia_data.keys())
        
        if category is None:
            category = random.choice(available_categories)
        elif category.lower() not in available_categories:
            category_list = ", ".join(available_categories)
            await ctx.send(f"❌ Categoria inválida! Categorias disponíveis: **{category_list}**")
            
            if ctx.author.id in self.active_games:
                del self.active_games[ctx.author.id]
            return
        
        # Select random question from chosen category
        category_questions = self.trivia_data[category.lower()]
        question_data = random.choice(category_questions)
        
        options = question_data["options"]
        correct_index = question_data["answer"]
        correct_answer = options[correct_index]
        
        # Create embed for question
        embed = discord.Embed(
            title=f"🧠 Trivia: {category.capitalize()}",
            description=question_data["question"],
            color=discord.Color.teal()
        )
        
        # Add options
        for i, option in enumerate(options):
            embed.add_field(
                name=f"Opção {i+1}",
                value=option,
                inline=True
            )
        
        embed.set_footer(text="Responda com o número da opção (1, 2, 3, 4)! Você tem 30 segundos.")
        
        await ctx.send(embed=embed)
        
        def check(message):
            return (
                message.author == ctx.author and 
                message.channel == ctx.channel and 
                (message.content.isdigit() and 1 <= int(message.content) <= len(options))
            )
        
        try:
            message = await self.bot.wait_for('message', check=check, timeout=30.0)
            answer_index = int(message.content) - 1
            
            if answer_index == correct_index:
                await ctx.send(f"✅ **Correto!** A resposta é: **{correct_answer}**")
            else:
                await ctx.send(f"❌ **Incorreto!** A resposta correta é: **{correct_answer}**")
        
        except asyncio.TimeoutError:
            await ctx.send(f"⏰ **Tempo esgotado!** A resposta correta é: **{correct_answer}**")
        
        finally:
            if ctx.author.id in self.active_games:
                del self.active_games[ctx.author.id]

async def setup(bot):
    await bot.add_cog(Games(bot))