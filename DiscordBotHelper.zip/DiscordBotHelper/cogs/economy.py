"""
Economy system for the Discord bot.
Allows users to earn and spend virtual currency in various ways.
"""
import random
import json
import os
import asyncio
import discord
from discord.ext import commands
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.economy_data_file = "economy_data.json"
        self.economy_data = self.load_economy_data()
        # Default cooldowns in seconds
        self.cooldowns = {
            "daily": 86400,  # 24 hours
            "work": 3600,    # 1 hour
            "mine": 1800,    # 30 minutes
            "fish": 1200,    # 20 minutes
            "crime": 7200,   # 2 hours
            "rob": 10800,    # 3 hours
            "gamble": 300,   # 5 minutes
            "search": 900    # 15 minutes
        }
        
        # Rewards for different activities
        self.work_rewards = {
            "programador": (100, 250, "Você programou um app e ganhou **{amount}** moedas!"),
            "designer": (80, 200, "Você criou um design incrível e ganhou **{amount}** moedas!"),
            "youtuber": (90, 220, "Seu vídeo viralizou e você ganhou **{amount}** moedas!"),
            "chef": (70, 180, "Você cozinhou uma refeição deliciosa e ganhou **{amount}** moedas!"),
            "professor": (75, 190, "Você deu uma aula inspiradora e ganhou **{amount}** moedas!"),
            "médico": (110, 260, "Você salvou uma vida e ganhou **{amount}** moedas!"),
            "motorista": (65, 170, "Você concluiu várias corridas e ganhou **{amount}** moedas!"),
            "artista": (85, 210, "Sua obra foi vendida por **{amount}** moedas!"),
            "escritor": (80, 200, "Seu livro foi um sucesso e você ganhou **{amount}** moedas!")
        }
        
        self.fish_items = {
            "bota velha": {"chance": 0.15, "value": 5, "emoji": "👢"},
            "peixe comum": {"chance": 0.40, "value": 20, "emoji": "🐟"},
            "peixe raro": {"chance": 0.25, "value": 40, "emoji": "🐠"},
            "tubarão": {"chance": 0.12, "value": 100, "emoji": "🦈"},
            "tesouro": {"chance": 0.08, "value": 200, "emoji": "💰"}
        }
        
        self.mine_items = {
            "pedra": {"chance": 0.30, "value": 10, "emoji": "🪨"},
            "carvão": {"chance": 0.25, "value": 20, "emoji": "⬛"},
            "ferro": {"chance": 0.20, "value": 40, "emoji": "⚙️"},
            "ouro": {"chance": 0.15, "value": 80, "emoji": "🟡"},
            "diamante": {"chance": 0.10, "value": 150, "emoji": "💎"}
        }
        
        # Crime activities (high risk, high reward)
        self.crime_activities = [
            {"name": "assalto a banco", "success_rate": 0.3, "min_reward": 200, "max_reward": 500, "penalty": 150},
            {"name": "falsificação", "success_rate": 0.4, "min_reward": 150, "max_reward": 350, "penalty": 100},
            {"name": "hacker", "success_rate": 0.5, "min_reward": 100, "max_reward": 300, "penalty": 80},
            {"name": "roubo de carros", "success_rate": 0.35, "min_reward": 180, "max_reward": 400, "penalty": 120},
            {"name": "golpe online", "success_rate": 0.45, "min_reward": 120, "max_reward": 320, "penalty": 90}
        ]
        
        # Search locations
        self.search_locations = {
            "casa": {"success_rate": 0.9, "min_reward": 10, "max_reward": 50},
            "parque": {"success_rate": 0.8, "min_reward": 15, "max_reward": 60},
            "praia": {"success_rate": 0.7, "min_reward": 20, "max_reward": 80},
            "rua": {"success_rate": 0.6, "min_reward": 25, "max_reward": 100},
            "lixeira": {"success_rate": 0.95, "min_reward": 5, "max_reward": 30},
            "escola": {"success_rate": 0.75, "min_reward": 15, "max_reward": 60},
            "hospital": {"success_rate": 0.65, "min_reward": 20, "max_reward": 70},
            "shopping": {"success_rate": 0.6, "min_reward": 25, "max_reward": 90},
            "banco": {"success_rate": 0.5, "min_reward": 30, "max_reward": 120},
            "cassino": {"success_rate": 0.4, "min_reward": 40, "max_reward": 200}
        }
        
        # Shop items
        self.shop_items = {
            "role_vip": {
                "name": "Cargo VIP", 
                "price": 5000, 
                "description": "Um cargo especial no servidor", 
                "type": "role", 
                "emoji": "⭐"
            },
            "background": {
                "name": "Background Personalizado", 
                "price": 3000, 
                "description": "Um fundo personalizado para seu perfil", 
                "type": "cosmetic", 
                "emoji": "🖼️"
            },
            "lottery_ticket": {
                "name": "Bilhete de Loteria", 
                "price": 500, 
                "description": "Um bilhete para o sorteio semanal (prêmio: 10.000 moedas)", 
                "type": "consumable", 
                "emoji": "🎟️"
            },
            "xp_boost": {
                "name": "Boost de XP", 
                "price": 2000, 
                "description": "Aumente seu ganho de XP em 50% por 24 horas", 
                "type": "consumable", 
                "emoji": "📈"
            },
            "xp_boost_plus": {
                "name": "Boost de XP Premium", 
                "price": 5000, 
                "description": "Aumente seu ganho de XP em 100% por 3 dias", 
                "type": "consumable", 
                "emoji": "⚡"
            },
            "fishing_rod": {
                "name": "Vara de Pesca Especial", 
                "price": 1500, 
                "description": "Melhora suas chances na pesca por 7 dias", 
                "type": "tool", 
                "emoji": "🎣"
            },
            "mining_pickaxe": {
                "name": "Picareta Reforçada", 
                "price": 1500, 
                "description": "Melhora suas chances na mineração por 7 dias", 
                "type": "tool", 
                "emoji": "⛏️"
            }
        }
    
    def load_economy_data(self):
        """Load economy data from JSON file"""
        if os.path.exists(self.economy_data_file):
            try:
                with open(self.economy_data_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading economy data: {e}")
                return {}
        return {}
    
    def save_economy_data(self):
        """Save economy data to JSON file"""
        try:
            with open(self.economy_data_file, "w", encoding="utf-8") as f:
                json.dump(self.economy_data, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving economy data: {e}")
    
    def get_user_data(self, user_id):
        """Get or create user data"""
        str_user_id = str(user_id)
        if str_user_id not in self.economy_data:
            self.economy_data[str_user_id] = {
                "balance": 0,
                "bank": 0,
                "last_daily": None,
                "last_work": None,
                "last_mine": None,
                "last_fish": None,
                "last_crime": None,
                "last_search": None,
                "last_rob": None,
                "last_gamble": None,
                "inventory": {},
                "owned_items": [],
                "active_buffs": {}
            }
            self.save_economy_data()
        
        # Add new fields if missing in existing data
        if "owned_items" not in self.economy_data[str_user_id]:
            self.economy_data[str_user_id]["owned_items"] = []
        
        if "active_buffs" not in self.economy_data[str_user_id]:
            self.economy_data[str_user_id]["active_buffs"] = {}
        
        return self.economy_data[str_user_id]
    
    def add_item_to_inventory(self, user_id, item_name, quantity=1):
        """Add an item to user's inventory"""
        user_data = self.get_user_data(user_id)
        
        if "inventory" not in user_data:
            user_data["inventory"] = {}
        
        if item_name in user_data["inventory"]:
            user_data["inventory"][item_name] += quantity
        else:
            user_data["inventory"][item_name] = quantity
        
        self.save_economy_data()
    
    def check_cooldown(self, user_id, cooldown_type):
        """Check if a cooldown has passed"""
        user_data = self.get_user_data(user_id)
        last_used_key = f"last_{cooldown_type}"
        
        if user_data.get(last_used_key) is None:
            return True
        
        last_used = datetime.fromisoformat(user_data[last_used_key])
        cooldown_time = timedelta(seconds=self.cooldowns[cooldown_type])
        
        if datetime.now() - last_used >= cooldown_time:
            return True
            
        return False
    
    def get_cooldown_remaining(self, user_id, cooldown_type):
        """Get remaining cooldown time in seconds"""
        user_data = self.get_user_data(user_id)
        last_used_key = f"last_{cooldown_type}"
        
        if user_data.get(last_used_key) is None:
            return 0
        
        last_used = datetime.fromisoformat(user_data[last_used_key])
        cooldown_time = timedelta(seconds=self.cooldowns[cooldown_type])
        time_passed = datetime.now() - last_used
        
        if time_passed >= cooldown_time:
            return 0
            
        return (cooldown_time - time_passed).total_seconds()
    
    def format_time(self, seconds):
        """Format seconds into a readable time string"""
        minutes, seconds = divmod(int(seconds), 60)
        hours, minutes = divmod(minutes, 60)
        
        time_parts = []
        if hours > 0:
            time_parts.append(f"{hours}h")
        if minutes > 0:
            time_parts.append(f"{minutes}m")
        if seconds > 0 or not time_parts:
            time_parts.append(f"{seconds}s")
            
        return " ".join(time_parts)
    
    @commands.command(aliases=["bal"])
    async def balance(self, ctx, member: discord.Member = None):
        """
        Ver seu saldo de moedas
        Usage: !balance [membro]
        """
        target = member or ctx.author
        user_data = self.get_user_data(target.id)
        
        embed = discord.Embed(
            title=f"💰 Saldo de {target.display_name}",
            color=discord.Color.gold()
        )
        
        embed.add_field(name="Carteira", value=f"**{user_data['balance']}** moedas", inline=True)
        embed.add_field(name="Banco", value=f"**{user_data['bank']}** moedas", inline=True)
        embed.add_field(name="Total", value=f"**{user_data['balance'] + user_data['bank']}** moedas", inline=True)
        
        embed.set_thumbnail(url=target.avatar.url if target.avatar else target.default_avatar.url)
        embed.set_footer(text=f"Solicitado por {ctx.author.name}")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def daily(self, ctx):
        """
        Coletar recompensa diária de moedas
        Usage: !daily
        """
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        if not self.check_cooldown(user_id, "daily"):
            cooldown_remaining = self.get_cooldown_remaining(user_id, "daily")
            return await ctx.send(f"⏲️ Você precisa esperar **{self.format_time(cooldown_remaining)}** para coletar sua recompensa diária novamente!")
        
        daily_amount = random.randint(100, 200)
        user_data["balance"] += daily_amount
        user_data["last_daily"] = datetime.now().isoformat()
        self.save_economy_data()
        
        embed = discord.Embed(
            title="💰 Recompensa Diária",
            description=f"Você coletou **{daily_amount}** moedas da sua recompensa diária!",
            color=discord.Color.green()
        )
        
        embed.set_footer(text=f"Volte em 24 horas para coletar novamente!")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def work(self, ctx):
        """
        Trabalhar para ganhar moedas
        Usage: !work
        """
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        if not self.check_cooldown(user_id, "work"):
            cooldown_remaining = self.get_cooldown_remaining(user_id, "work")
            return await ctx.send(f"⏲️ Você ainda está cansado do trabalho anterior! Descanse por mais **{self.format_time(cooldown_remaining)}**.")
        
        job, (min_amount, max_amount, message_template) = random.choice(list(self.work_rewards.items()))
        earned = random.randint(min_amount, max_amount)
        
        user_data["balance"] += earned
        user_data["last_work"] = datetime.now().isoformat()
        self.save_economy_data()
        
        message = message_template.format(amount=earned)
        
        embed = discord.Embed(
            title=f"💼 Trabalho: {job.capitalize()}",
            description=message,
            color=discord.Color.blue()
        )
        
        embed.set_footer(text=f"Você pode trabalhar novamente em 1 hora.")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def mine(self, ctx):
        """
        Minerar recursos e ganhar moedas
        Usage: !mine
        """
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        if not self.check_cooldown(user_id, "mine"):
            cooldown_remaining = self.get_cooldown_remaining(user_id, "mine")
            return await ctx.send(f"⏲️ Sua picareta está se recuperando! Tente novamente em **{self.format_time(cooldown_remaining)}**.")
        
        # Choose item based on chance
        items = list(self.mine_items.items())
        items.sort(key=lambda x: x[1]["chance"])
        
        rand_val = random.random()
        cumulative_chance = 0
        found_item = None
        
        for item_name, item_data in items:
            cumulative_chance += item_data["chance"]
            if rand_val <= cumulative_chance:
                found_item = (item_name, item_data)
                break
        
        # If no item was selected (shouldn't happen, but just in case)
        if not found_item:
            found_item = items[-1]
        
        item_name, item_data = found_item
        item_value = item_data["value"]
        item_emoji = item_data["emoji"]
        
        user_data["balance"] += item_value
        user_data["last_mine"] = datetime.now().isoformat()
        self.add_item_to_inventory(user_id, item_name)
        self.save_economy_data()
        
        embed = discord.Embed(
            title=f"⛏️ Mineração",
            description=f"Você encontrou {item_emoji} **{item_name}** e vendeu por **{item_value}** moedas!",
            color=discord.Color.dark_gray()
        )
        
        embed.set_footer(text="Você pode minerar novamente em 30 minutos.")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def fish(self, ctx):
        """
        Pescar e ganhar moedas
        Usage: !fish
        """
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        if not self.check_cooldown(user_id, "fish"):
            cooldown_remaining = self.get_cooldown_remaining(user_id, "fish")
            return await ctx.send(f"⏲️ Os peixes ainda estão assustados! Tente novamente em **{self.format_time(cooldown_remaining)}**.")
        
        # Simulate fishing with loading message
        message = await ctx.send("🎣 Pescando...")
        await asyncio.sleep(2)
        
        # Choose item based on chance
        items = list(self.fish_items.items())
        items.sort(key=lambda x: x[1]["chance"])
        
        rand_val = random.random()
        cumulative_chance = 0
        caught_item = None
        
        for item_name, item_data in items:
            cumulative_chance += item_data["chance"]
            if rand_val <= cumulative_chance:
                caught_item = (item_name, item_data)
                break
        
        # If no item was selected (shouldn't happen, but just in case)
        if not caught_item:
            caught_item = items[-1]
        
        item_name, item_data = caught_item
        item_value = item_data["value"]
        item_emoji = item_data["emoji"]
        
        user_data["balance"] += item_value
        user_data["last_fish"] = datetime.now().isoformat()
        self.add_item_to_inventory(user_id, item_name)
        self.save_economy_data()
        
        embed = discord.Embed(
            title=f"🎣 Pesca",
            description=f"Você pescou {item_emoji} **{item_name}** e vendeu por **{item_value}** moedas!",
            color=discord.Color.blue()
        )
        
        embed.set_footer(text="Você pode pescar novamente em 20 minutos.")
        
        await message.edit(content=None, embed=embed)
    
    @commands.command(aliases=["inv"])
    async def inventory(self, ctx, member: discord.Member = None):
        """
        Ver seu inventário
        Usage: !inventory [membro]
        """
        target = member or ctx.author
        user_data = self.get_user_data(target.id)
        
        if "inventory" not in user_data or not user_data["inventory"]:
            return await ctx.send(f"🎒 {target.mention} não tem nenhum item no inventário!")
        
        embed = discord.Embed(
            title=f"🎒 Inventário de {target.display_name}",
            color=discord.Color.dark_green()
        )
        
        all_items = {**self.fish_items, **self.mine_items}
        
        # Group items by type
        mines = []
        fish = []
        other = []
        
        for item_name, quantity in user_data["inventory"].items():
            if quantity <= 0:
                continue
                
            if item_name in self.mine_items:
                emoji = self.mine_items[item_name]["emoji"]
                mines.append(f"{emoji} **{item_name}**: {quantity}")
            elif item_name in self.fish_items:
                emoji = self.fish_items[item_name]["emoji"]
                fish.append(f"{emoji} **{item_name}**: {quantity}")
            else:
                other.append(f"**{item_name}**: {quantity}")
        
        if mines:
            embed.add_field(name="⛏️ Minerais", value="\n".join(mines), inline=False)
        
        if fish:
            embed.add_field(name="🎣 Pescaria", value="\n".join(fish), inline=False)
        
        if other:
            embed.add_field(name="📦 Outros", value="\n".join(other), inline=False)
        
        embed.set_thumbnail(url=target.avatar.url if target.avatar else target.default_avatar.url)
        embed.set_footer(text=f"Solicitado por {ctx.author.name}")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def deposit(self, ctx, amount: str):
        """
        Depositar moedas no banco
        Usage: !deposit <quantidade/all>
        """
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        if amount.lower() == "all" or amount.lower() == "tudo":
            amount = user_data["balance"]
        else:
            try:
                amount = int(amount)
                if amount <= 0:
                    return await ctx.send("❌ A quantidade deve ser um número positivo!")
            except ValueError:
                return await ctx.send("❌ Por favor, informe um número válido ou 'all'/'tudo'!")
        
        if user_data["balance"] < amount:
            return await ctx.send("❌ Você não tem moedas suficientes na carteira!")
        
        user_data["balance"] -= amount
        user_data["bank"] += amount
        self.save_economy_data()
        
        embed = discord.Embed(
            title="🏦 Depósito",
            description=f"Você depositou **{amount}** moedas no banco!",
            color=discord.Color.green()
        )
        
        embed.add_field(name="Carteira", value=f"**{user_data['balance']}** moedas", inline=True)
        embed.add_field(name="Banco", value=f"**{user_data['bank']}** moedas", inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def withdraw(self, ctx, amount: str):
        """
        Sacar moedas do banco
        Usage: !withdraw <quantidade/all>
        """
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        if amount.lower() == "all" or amount.lower() == "tudo":
            amount = user_data["bank"]
        else:
            try:
                amount = int(amount)
                if amount <= 0:
                    return await ctx.send("❌ A quantidade deve ser um número positivo!")
            except ValueError:
                return await ctx.send("❌ Por favor, informe um número válido ou 'all'/'tudo'!")
        
        if user_data["bank"] < amount:
            return await ctx.send("❌ Você não tem moedas suficientes no banco!")
        
        user_data["bank"] -= amount
        user_data["balance"] += amount
        self.save_economy_data()
        
        embed = discord.Embed(
            title="🏦 Saque",
            description=f"Você sacou **{amount}** moedas do banco!",
            color=discord.Color.green()
        )
        
        embed.add_field(name="Carteira", value=f"**{user_data['balance']}** moedas", inline=True)
        embed.add_field(name="Banco", value=f"**{user_data['bank']}** moedas", inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def pay(self, ctx, member: discord.Member, amount: int):
        """
        Transferir moedas para outro usuário
        Usage: !pay <membro> <quantidade>
        """
        if member.id == ctx.author.id:
            return await ctx.send("❌ Você não pode transferir moedas para si mesmo!")
        
        if amount <= 0:
            return await ctx.send("❌ A quantidade deve ser um número positivo!")
        
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        if user_data["balance"] < amount:
            return await ctx.send("❌ Você não tem moedas suficientes na carteira!")
        
        target_data = self.get_user_data(member.id)
        
        user_data["balance"] -= amount
        target_data["balance"] += amount
        self.save_economy_data()
        
        embed = discord.Embed(
            title="💸 Transferência",
            description=f"Você transferiu **{amount}** moedas para {member.mention}!",
            color=discord.Color.green()
        )
        
        embed.set_footer(text=f"Seu saldo atual: {user_data['balance']} moedas")
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def leaderboard(self, ctx):
        """
        Ver os usuários mais ricos
        Usage: !leaderboard
        """
        # Get all users with economy data
        user_list = []
        
        for user_id, data in self.economy_data.items():
            try:
                total_money = data["balance"] + data["bank"]
                user_list.append((int(user_id), total_money))
            except (KeyError, ValueError):
                continue
        
        # Sort by total money and take top 10
        user_list.sort(key=lambda x: x[1], reverse=True)
        top_users = user_list[:10]
        
        if not top_users:
            return await ctx.send("❌ Não há usuários com dinheiro ainda!")
        
        embed = discord.Embed(
            title="💰 Ranking de Riqueza",
            description="Os usuários mais ricos do servidor:",
            color=discord.Color.gold()
        )
        
        for index, (user_id, total_money) in enumerate(top_users, 1):
            medal = "🥇" if index == 1 else "🥈" if index == 2 else "🥉" if index == 3 else f"{index}."
            user = self.bot.get_user(user_id)
            user_name = user.name if user else f"Usuário {user_id}"
            
            embed.add_field(
                name=f"{medal} {user_name}",
                value=f"**{total_money}** moedas",
                inline=False
            )
        
        embed.set_footer(text=f"Solicitado por {ctx.author.name}")
        
        await ctx.send(embed=embed)

    @commands.command()
    async def crime(self, ctx):
        """
        Cometer um crime para ganhar ou perder moedas (alto risco, alta recompensa)
        Usage: !crime
        """
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        if not self.check_cooldown(user_id, "crime"):
            cooldown_remaining = self.get_cooldown_remaining(user_id, "crime")
            return await ctx.send(f"⏲️ As autoridades estão em alerta! Espere **{self.format_time(cooldown_remaining)}** antes de tentar outro crime.")
        
        crime_activity = random.choice(self.crime_activities)
        success = random.random() < crime_activity["success_rate"]
        
        user_data["last_crime"] = datetime.now().isoformat()
        
        if success:
            # Crime succeeded
            reward = random.randint(crime_activity["min_reward"], crime_activity["max_reward"])
            user_data["balance"] += reward
            
            embed = discord.Embed(
                title="🕵️ Crime Bem-Sucedido",
                description=f"Você cometeu um **{crime_activity['name']}** e conseguiu escapar com **{reward}** moedas!",
                color=discord.Color.green()
            )
            
            embed.set_footer(text=f"Você pode tentar outro crime em {self.format_time(self.cooldowns['crime'])}.")
        else:
            # Crime failed
            penalty = crime_activity["penalty"]
            user_data["balance"] = max(0, user_data["balance"] - penalty)
            
            embed = discord.Embed(
                title="🚨 Crime Fracassado",
                description=f"Você tentou um **{crime_activity['name']}** e foi pego! Você pagou **{penalty}** moedas de multa.",
                color=discord.Color.red()
            )
            
            embed.set_footer(text=f"Você pode tentar outro crime em {self.format_time(self.cooldowns['crime'])}.")
        
        self.save_economy_data()
        await ctx.send(embed=embed)
    
    @commands.command()
    async def search(self, ctx, location: str = None):
        """
        Procurar moedas em locais específicos
        Usage: !search [local]
        """
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        if not self.check_cooldown(user_id, "search"):
            cooldown_remaining = self.get_cooldown_remaining(user_id, "search")
            return await ctx.send(f"⏲️ Você já procurou recentemente! Espere **{self.format_time(cooldown_remaining)}** antes de procurar novamente.")
        
        if location is None:
            # Show available locations
            locations_str = ", ".join([f"**{loc}**" for loc in self.search_locations.keys()])
            return await ctx.send(f"🔍 Onde você quer procurar? Use `!search <local>`\nLocais disponíveis: {locations_str}")
        
        location = location.lower()
        if location not in self.search_locations:
            locations_str = ", ".join([f"**{loc}**" for loc in self.search_locations.keys()])
            return await ctx.send(f"❌ Local inválido! Locais disponíveis: {locations_str}")
        
        user_data["last_search"] = datetime.now().isoformat()
        
        location_data = self.search_locations[location]
        success = random.random() < location_data["success_rate"]
        
        if success:
            amount = random.randint(location_data["min_reward"], location_data["max_reward"])
            user_data["balance"] += amount
            
            embed = discord.Embed(
                title=f"🔍 Busca em {location.capitalize()}",
                description=f"Você procurou no(a) **{location}** e encontrou **{amount}** moedas!",
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title=f"🔍 Busca em {location.capitalize()}",
                description=f"Você procurou no(a) **{location}** mas não encontrou nada de valor.",
                color=discord.Color.light_grey()
            )
        
        embed.set_footer(text=f"Você pode procurar novamente em {self.format_time(self.cooldowns['search'])}.")
        
        self.save_economy_data()
        await ctx.send(embed=embed)
    
    @commands.command(aliases=["slots"])
    async def gamble(self, ctx, amount: int = None):
        """
        Apostar moedas em um caça-níquel
        Usage: !gamble <quantidade>
        """
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        if amount is None:
            return await ctx.send("❌ Por favor, especifique uma quantidade para apostar: `!gamble <quantidade>`")
        
        if amount < 10:
            return await ctx.send("❌ Você deve apostar pelo menos 10 moedas!")
        
        if user_data["balance"] < amount:
            return await ctx.send("❌ Você não tem moedas suficientes para fazer essa aposta!")
        
        if not self.check_cooldown(user_id, "gamble"):
            cooldown_remaining = self.get_cooldown_remaining(user_id, "gamble")
            return await ctx.send(f"⏲️ O cassino está fechado para você! Espere **{self.format_time(cooldown_remaining)}** antes de apostar novamente.")
        
        user_data["last_gamble"] = datetime.now().isoformat()
        
        # Slot machine simulation
        emojis = ["🍒", "🍊", "🍋", "🍇", "🍉", "💎", "7️⃣", "🍀"]
        weights = [20, 20, 20, 15, 10, 7, 5, 3]  # Probability weights
        
        slots = []
        for _ in range(3):
            slots.append(random.choices(emojis, weights=weights, k=1)[0])
        
        result_str = " | ".join(slots)
        
        # Check for wins
        if slots[0] == slots[1] == slots[2]:
            # Jackpot - all three match
            if slots[0] == "7️⃣":
                # Super jackpot
                multiplier = 10
                win_message = "🎉 **SUPER JACKPOT!** 🎉"
            elif slots[0] == "💎":
                # Diamond jackpot
                multiplier = 7
                win_message = "💎 **DIAMOND JACKPOT!** 💎"
            elif slots[0] == "🍀":
                # Lucky jackpot
                multiplier = 5
                win_message = "🍀 **LUCKY JACKPOT!** 🍀"
            else:
                # Regular jackpot
                multiplier = 3
                win_message = "🎰 **JACKPOT!** 🎰"
            
            winnings = amount * multiplier
            user_data["balance"] += winnings - amount  # Subtract bet, add winnings
            
            embed = discord.Embed(
                title="🎰 Caça-Níquel",
                description=f"**[ {result_str} ]**\n\n{win_message}\nVocê ganhou **{winnings}** moedas (x{multiplier})!",
                color=discord.Color.gold()
            )
        
        elif slots[0] == slots[1] or slots[1] == slots[2] or slots[0] == slots[2]:
            # Two matching symbols
            multiplier = 1.5
            winnings = int(amount * multiplier)
            user_data["balance"] += winnings - amount  # Subtract bet, add winnings
            
            embed = discord.Embed(
                title="🎰 Caça-Níquel",
                description=f"**[ {result_str} ]**\n\n2 símbolos iguais!\nVocê ganhou **{winnings}** moedas (x{multiplier})!",
                color=discord.Color.green()
            )
        
        else:
            # Loss
            user_data["balance"] -= amount
            
            embed = discord.Embed(
                title="🎰 Caça-Níquel",
                description=f"**[ {result_str} ]**\n\nQue pena! Você perdeu **{amount}** moedas.",
                color=discord.Color.red()
            )
        
        embed.set_footer(text=f"Saldo atual: {user_data['balance']} moedas")
        
        self.save_economy_data()
        await ctx.send(embed=embed)
    
    @commands.group(aliases=["store", "loja"], invoke_without_command=True)
    async def shop(self, ctx):
        """
        Loja para comprar itens com moedas
        Usage: !shop
        """
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="🛒 Loja de Itens",
                description="Compre itens especiais com suas moedas!",
                color=discord.Color.dark_teal()
            )
            
            # Group items by category
            roles = []
            consumables = []
            cosmetics = []
            tools = []
            
            for item_id, item in self.shop_items.items():
                item_str = f"{item['emoji']} **{item['name']}** - {item['price']} moedas\n*{item['description']}*"
                
                if item['type'] == 'role':
                    roles.append(item_str)
                elif item['type'] == 'consumable':
                    consumables.append(item_str)
                elif item['type'] == 'cosmetic':
                    cosmetics.append(item_str)
                elif item['type'] == 'tool':
                    tools.append(item_str)
            
            if roles:
                embed.add_field(name="⭐ Cargos", value="\n\n".join(roles), inline=False)
            
            if consumables:
                embed.add_field(name="🧪 Consumíveis", value="\n\n".join(consumables), inline=False)
            
            if tools:
                embed.add_field(name="🔨 Ferramentas", value="\n\n".join(tools), inline=False)
            
            if cosmetics:
                embed.add_field(name="🖼️ Cosméticos", value="\n\n".join(cosmetics), inline=False)
            
            embed.set_footer(text=f"Use {ctx.prefix}shop buy <item_id> para comprar um item")
            
            await ctx.send(embed=embed)
    
    @shop.command(name="buy")
    async def shop_buy(self, ctx, item_id: str = None):
        """
        Comprar um item da loja
        Usage: !shop buy <item_id>
        """
        if item_id is None:
            return await ctx.send(f"❌ Por favor, especifique o ID do item para comprar. Use `{ctx.prefix}shop` para ver os itens disponíveis.")
        
        item_id = item_id.lower()
        
        if item_id not in self.shop_items:
            return await ctx.send(f"❌ Item não encontrado. Use `{ctx.prefix}shop` para ver os itens disponíveis.")
        
        item = self.shop_items[item_id]
        user_id = ctx.author.id
        user_data = self.get_user_data(user_id)
        
        # Check if user has enough money
        if user_data["balance"] < item["price"]:
            return await ctx.send(f"❌ Você não tem moedas suficientes para comprar este item! (Preço: {item['price']} moedas)")
        
        # Check if user already has this item
        if item_id in user_data["owned_items"]:
            return await ctx.send(f"❌ Você já possui este item!")
        
        # Process the purchase
        user_data["balance"] -= item["price"]
        user_data["owned_items"].append(item_id)
        
        # Special handling for different item types
        special_message = ""
        
        if item["type"] == "role":
            # Attempt to give the role if the user is in a guild
            if ctx.guild:
                # Find or create the role
                role_name = f"VIP {ctx.author.name}"
                role = discord.utils.get(ctx.guild.roles, name=role_name)
                
                try:
                    if not role:
                        role = await ctx.guild.create_role(name=role_name, color=discord.Color.gold())
                    
                    await ctx.author.add_roles(role)
                    special_message = f"\nO cargo **{role_name}** foi adicionado ao seu perfil!"
                except discord.Forbidden:
                    special_message = "\nNão foi possível adicionar o cargo automaticamente. Por favor, peça a um administrador."
                except Exception as e:
                    special_message = f"\nOcorreu um erro ao adicionar o cargo: {str(e)}"
        
        elif item["type"] == "consumable":
            if item_id == "lottery_ticket":
                special_message = "\nBoa sorte no sorteio semanal da loteria!"
            elif item_id == "xp_boost" or item_id == "xp_boost_plus":
                # Add XP boost based on the item type
                if item_id == "xp_boost":
                    # Regular XP boost (50% for 24 hours)
                    duration_hours = 24
                    multiplier = 1.5
                    duration_text = "24 horas"
                else:
                    # Premium XP boost (100% for 3 days)
                    duration_hours = 72  # 3 days
                    multiplier = 2.0
                    duration_text = "3 dias"
                
                expire_time = (datetime.now() + timedelta(hours=duration_hours)).isoformat()
                
                if "active_buffs" not in user_data:
                    user_data["active_buffs"] = {}
                
                # Check for existing boost of the same type
                if "xp_boost" in user_data["active_buffs"]:
                    # If there's an existing boost, extend it or upgrade it
                    existing_boost = user_data["active_buffs"]["xp_boost"]
                    existing_end_time = datetime.fromisoformat(existing_boost["expires"])
                    existing_multiplier = existing_boost["multiplier"]
                    
                    # Use the higher multiplier
                    effective_multiplier = max(multiplier, existing_multiplier)
                    
                    # Add the new duration to the existing time
                    new_end_time = max(
                        existing_end_time,
                        datetime.now() + timedelta(hours=duration_hours)
                    )
                    
                    user_data["active_buffs"]["xp_boost"] = {
                        "expires": new_end_time.isoformat(),
                        "multiplier": effective_multiplier
                    }
                    
                    special_message = f"\nSeu boost de XP foi atualizado! Agora com multiplicador de {effective_multiplier}x até {new_end_time.strftime('%d/%m/%Y %H:%M')}."
                else:
                    # Add new boost
                    user_data["active_buffs"]["xp_boost"] = {
                        "expires": expire_time,
                        "multiplier": multiplier
                    }
                    
                    special_message = f"\nSeu boost de XP estará ativo por {duration_text}!"
        
        elif item["type"] == "tool":
            # Add tool buff for 7 days
            expire_time = (datetime.now() + timedelta(days=7)).isoformat()
            
            if "active_buffs" not in user_data:
                user_data["active_buffs"] = {}
            
            buff_id = f"{item_id}_buff"
            user_data["active_buffs"][buff_id] = {
                "expires": expire_time,
                "multiplier": 1.5
            }
            
            special_message = f"\nSua {item['name']} estará ativa por 7 dias!"
        
        self.save_economy_data()
        
        embed = discord.Embed(
            title="🛍️ Compra Realizada",
            description=f"Você comprou **{item['name']}** por **{item['price']}** moedas!{special_message}",
            color=discord.Color.green()
        )
        
        embed.add_field(name="Saldo Atual", value=f"{user_data['balance']} moedas", inline=False)
        embed.set_footer(text=f"Use {ctx.prefix}inventory para ver seus itens")
        
        await ctx.send(embed=embed)
    
    @shop.command(name="inventory", aliases=["inv"])
    async def shop_inventory(self, ctx, member: discord.Member = None):
        """
        Ver os itens da loja que você possui
        Usage: !shop inventory [membro]
        """
        target = member or ctx.author
        user_data = self.get_user_data(target.id)
        
        if not user_data.get("owned_items"):
            return await ctx.send(f"{'Você não possui' if target.id == ctx.author.id else f'{target.name} não possui'} nenhum item da loja!")
        
        embed = discord.Embed(
            title=f"🛍️ Itens da Loja de {target.display_name}",
            color=discord.Color.blue()
        )
        
        # Group items by category
        roles = []
        consumables = []
        cosmetics = []
        tools = []
        
        for item_id in user_data["owned_items"]:
            if item_id in self.shop_items:
                item = self.shop_items[item_id]
                item_str = f"{item['emoji']} **{item['name']}**"
                
                active_status = ""
                if "active_buffs" in user_data:
                    if (item_id == "xp_boost" or item_id == "xp_boost_plus") and "xp_boost" in user_data["active_buffs"]:
                        expiry = datetime.fromisoformat(user_data["active_buffs"]["xp_boost"]["expires"])
                        if expiry > datetime.now():
                            time_left = expiry - datetime.now()
                            active_status = f" (Ativo por mais {self.format_time(time_left.total_seconds())})"
                    
                    elif item["type"] == "tool":
                        buff_id = f"{item_id}_buff"
                        if buff_id in user_data["active_buffs"]:
                            expiry = datetime.fromisoformat(user_data["active_buffs"][buff_id]["expires"])
                            if expiry > datetime.now():
                                time_left = expiry - datetime.now()
                                active_status = f" (Ativo por mais {self.format_time(time_left.total_seconds())})"
                
                item_str += active_status
                
                if item["type"] == "role":
                    roles.append(item_str)
                elif item["type"] == "consumable":
                    consumables.append(item_str)
                elif item["type"] == "cosmetic":
                    cosmetics.append(item_str)
                elif item["type"] == "tool":
                    tools.append(item_str)
        
        if roles:
            embed.add_field(name="⭐ Cargos", value="\n".join(roles), inline=False)
        
        if consumables:
            embed.add_field(name="🧪 Consumíveis", value="\n".join(consumables), inline=False)
        
        if tools:
            embed.add_field(name="🔨 Ferramentas", value="\n".join(tools), inline=False)
        
        if cosmetics:
            embed.add_field(name="🖼️ Cosméticos", value="\n".join(cosmetics), inline=False)
        
        embed.set_thumbnail(url=target.avatar.url if target.avatar else target.default_avatar.url)
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Economy(bot))