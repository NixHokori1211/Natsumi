"""
Pet system for the Discord bot.
Allows users to adopt and care for virtual pets.
"""
import discord
from discord.ext import commands
import logging
import json
import os
import random
from datetime import datetime, timedelta
import asyncio
from typing import Dict, List, Optional, Union, Tuple

logger = logging.getLogger(__name__)

class Pets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.pets_data_file = "pets_data.json"
        self.pets_data = self.load_pets_data()
        
        # Available pet types with their attributes
        self.pet_types = {
            "dog": {
                "name": "Cachorro",
                "emoji": "🐕",
                "hunger_rate": 0.5,  # Points per hour
                "happiness_decay": 0.4,  # Points per hour
                "energy_recovery": 1.0,  # Points per hour when sleeping
                "max_level": 50,
                "abilities": ["Buscar", "Farejar", "Acompanhar"],
                "foods": ["ração", "osso", "carne"],
                "toys": ["bolinha", "pelúcia", "corda"]
            },
            "cat": {
                "name": "Gato",
                "emoji": "🐈",
                "hunger_rate": 0.3,
                "happiness_decay": 0.5,
                "energy_recovery": 1.2,
                "max_level": 50,
                "abilities": ["Caçar", "Escalar", "Ronronar"],
                "foods": ["ração", "peixe", "leite"],
                "toys": ["novelo", "laser", "varinha"]
            },
            "bird": {
                "name": "Pássaro",
                "emoji": "🐦",
                "hunger_rate": 0.4,
                "happiness_decay": 0.6,
                "energy_recovery": 0.8,
                "max_level": 30,
                "abilities": ["Cantar", "Falar", "Voar"],
                "foods": ["alpiste", "fruta", "milho"],
                "toys": ["espelho", "sino", "escada"]
            },
            "rabbit": {
                "name": "Coelho",
                "emoji": "🐇",
                "hunger_rate": 0.6,
                "happiness_decay": 0.3,
                "energy_recovery": 0.9,
                "max_level": 30,
                "abilities": ["Pular", "Escavar", "Esconder"],
                "foods": ["cenoura", "alface", "ração"],
                "toys": ["bola", "túnel", "mordedor"]
            },
            "hamster": {
                "name": "Hamster",
                "emoji": "🐹",
                "hunger_rate": 0.4,
                "happiness_decay": 0.5,
                "energy_recovery": 1.0,
                "max_level": 20,
                "abilities": ["Girar", "Roer", "Armazenar"],
                "foods": ["sementes", "ração", "vegetais"],
                "toys": ["roda", "tubo", "casinha"]
            },
            "dragon": {
                "name": "Dragão",
                "emoji": "🐉",
                "hunger_rate": 0.7,
                "happiness_decay": 0.2,
                "energy_recovery": 0.6,
                "max_level": 100,
                "abilities": ["Fogo", "Voar", "Proteger"],
                "foods": ["carne", "ouro", "gemas"],
                "toys": ["tesouro", "espada", "escudo"]
            }
        }
        
        # XP requirements per level (increasing)
        self.level_xp_requirements = {}
        for level in range(1, 101):
            self.level_xp_requirements[level] = int(100 * (level ** 1.5))
    
    def load_pets_data(self):
        """Load pets data from JSON file"""
        if os.path.exists(self.pets_data_file):
            try:
                with open(self.pets_data_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading pets data: {e}")
                return {}
        return {}
    
    def save_pets_data(self):
        """Save pets data to JSON file"""
        try:
            with open(self.pets_data_file, "w", encoding="utf-8") as f:
                json.dump(self.pets_data, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving pets data: {e}")
    
    def has_pet(self, user_id: int) -> bool:
        """Check if a user has a pet"""
        str_user_id = str(user_id)
        return str_user_id in self.pets_data
    
    def get_pet_data(self, user_id: int) -> Optional[Dict]:
        """Get a user's pet data"""
        str_user_id = str(user_id)
        if str_user_id in self.pets_data:
            return self.pets_data[str_user_id]
        return None
    
    def create_pet(self, user_id: int, pet_type: str, pet_name: str):
        """Create a new pet for a user"""
        str_user_id = str(user_id)
        
        if pet_type not in self.pet_types:
            raise ValueError(f"Invalid pet type: {pet_type}")
        
        self.pets_data[str_user_id] = {
            "name": pet_name,
            "type": pet_type,
            "created_at": datetime.now().isoformat(),
            "last_interaction": datetime.now().isoformat(),
            "hunger": 100,  # 0-100
            "happiness": 100,  # 0-100
            "energy": 100,  # 0-100
            "sleeping": False,
            "xp": 0,
            "level": 1,
            "inventory": {
                "food": {},
                "toys": {}
            }
        }
        
        self.save_pets_data()
    
    def update_pet_stats(self, user_id: int):
        """Update pet stats based on time passed since last interaction"""
        pet_data = self.get_pet_data(user_id)
        if not pet_data:
            return
        
        pet_type = pet_data["type"]
        pet_type_data = self.pet_types[pet_type]
        
        last_interaction = datetime.fromisoformat(pet_data["last_interaction"])
        now = datetime.now()
        
        # Calculate hours passed
        hours_passed = (now - last_interaction).total_seconds() / 3600
        
        # Update hunger (decreases over time)
        if not pet_data["sleeping"]:
            hunger_decrease = pet_type_data["hunger_rate"] * hours_passed
            pet_data["hunger"] = max(0, pet_data["hunger"] - hunger_decrease)
        else:
            # Sleeping pets get hungry slower
            hunger_decrease = pet_type_data["hunger_rate"] * hours_passed * 0.5
            pet_data["hunger"] = max(0, pet_data["hunger"] - hunger_decrease)
        
        # Update happiness (decreases over time)
        happiness_decrease = pet_type_data["happiness_decay"] * hours_passed
        pet_data["happiness"] = max(0, pet_data["happiness"] - happiness_decrease)
        
        # Update energy
        if pet_data["sleeping"]:
            # Energy increases when sleeping
            energy_increase = pet_type_data["energy_recovery"] * hours_passed
            pet_data["energy"] = min(100, pet_data["energy"] + energy_increase)
            
            # Wake up pet if energy is full
            if pet_data["energy"] >= 100:
                pet_data["sleeping"] = False
                pet_data["energy"] = 100
        else:
            # Energy decreases when awake
            energy_decrease = 0.3 * hours_passed
            pet_data["energy"] = max(0, pet_data["energy"] - energy_decrease)
        
        # Update last interaction time
        pet_data["last_interaction"] = now.isoformat()
        
        self.save_pets_data()
    
    def feed_pet(self, user_id: int, food_item: str) -> Tuple[bool, str]:
        """Feed a pet with a specific food item"""
        pet_data = self.get_pet_data(user_id)
        if not pet_data:
            return False, "Você não tem um pet para alimentar!"
        
        # Check if pet is sleeping
        if pet_data["sleeping"]:
            return False, f"{pet_data['name']} está dormindo! Acorde-o primeiro."
        
        pet_type = pet_data["type"]
        pet_type_data = self.pet_types[pet_type]
        
        # Check if food is valid for this pet type
        if food_item not in pet_type_data["foods"]:
            return False, f"{pet_data['name']} não come {food_item}! Alimentos aceitos: {', '.join(pet_type_data['foods'])}"
        
        # Check if user has this food in inventory
        if food_item not in pet_data["inventory"]["food"] or pet_data["inventory"]["food"][food_item] <= 0:
            return False, f"Você não tem {food_item} no inventário!"
        
        # Feed the pet
        hunger_increase = random.randint(10, 25)
        pet_data["hunger"] = min(100, pet_data["hunger"] + hunger_increase)
        
        # Also increases happiness a bit
        happiness_increase = random.randint(1, 5)
        pet_data["happiness"] = min(100, pet_data["happiness"] + happiness_increase)
        
        # Remove item from inventory
        pet_data["inventory"]["food"][food_item] -= 1
        
        # Add experience
        self.add_pet_xp(user_id, random.randint(1, 3))
        
        # Update last interaction time
        pet_data["last_interaction"] = datetime.now().isoformat()
        
        self.save_pets_data()
        
        return True, f"{pet_data['name']} comeu {food_item} e ficou mais satisfeito! (+{hunger_increase} fome, +{happiness_increase} felicidade)"
    
    def play_with_pet(self, user_id: int, toy_item: str = None) -> Tuple[bool, str]:
        """Play with a pet, optionally using a toy"""
        pet_data = self.get_pet_data(user_id)
        if not pet_data:
            return False, "Você não tem um pet para brincar!"
        
        # Check if pet is sleeping
        if pet_data["sleeping"]:
            return False, f"{pet_data['name']} está dormindo! Acorde-o primeiro."
        
        pet_type = pet_data["type"]
        pet_type_data = self.pet_types[pet_type]
        
        # If no toy specified, just play normally
        if toy_item is None:
            happiness_increase = random.randint(5, 15)
            energy_decrease = random.randint(5, 10)
            xp_gain = random.randint(1, 3)
            message = f"Você brincou com {pet_data['name']}!"
        else:
            # Check if toy is valid for this pet type
            if toy_item not in pet_type_data["toys"]:
                return False, f"{pet_data['name']} não brinca com {toy_item}! Brinquedos aceitos: {', '.join(pet_type_data['toys'])}"
            
            # Check if user has this toy in inventory
            if toy_item not in pet_data["inventory"]["toys"] or pet_data["inventory"]["toys"][toy_item] <= 0:
                return False, f"Você não tem {toy_item} no inventário!"
            
            happiness_increase = random.randint(15, 30)
            energy_decrease = random.randint(7, 15)
            xp_gain = random.randint(3, 6)
            message = f"Você brincou com {pet_data['name']} usando {toy_item}!"
            
            # Toys don't get consumed, so no need to remove from inventory
        
        # Update pet stats
        pet_data["happiness"] = min(100, pet_data["happiness"] + happiness_increase)
        pet_data["energy"] = max(0, pet_data["energy"] - energy_decrease)
        
        # Add experience
        self.add_pet_xp(user_id, xp_gain)
        
        # Update last interaction time
        pet_data["last_interaction"] = datetime.now().isoformat()
        
        self.save_pets_data()
        
        return True, f"{message} (+{happiness_increase} felicidade, -{energy_decrease} energia)"
    
    def put_pet_to_sleep(self, user_id: int) -> Tuple[bool, str]:
        """Put a pet to sleep to recover energy"""
        pet_data = self.get_pet_data(user_id)
        if not pet_data:
            return False, "Você não tem um pet para colocar para dormir!"
        
        if pet_data["sleeping"]:
            return False, f"{pet_data['name']} já está dormindo!"
        
        pet_data["sleeping"] = True
        
        # Update last interaction time
        pet_data["last_interaction"] = datetime.now().isoformat()
        
        self.save_pets_data()
        
        return True, f"{pet_data['name']} agora está dormindo e recuperando energia!"
    
    def wake_pet_up(self, user_id: int) -> Tuple[bool, str]:
        """Wake up a sleeping pet"""
        pet_data = self.get_pet_data(user_id)
        if not pet_data:
            return False, "Você não tem um pet para acordar!"
        
        if not pet_data["sleeping"]:
            return False, f"{pet_data['name']} já está acordado!"
        
        pet_data["sleeping"] = False
        
        # Update last interaction time
        pet_data["last_interaction"] = datetime.now().isoformat()
        
        self.save_pets_data()
        
        return True, f"Você acordou {pet_data['name']}!"
    
    def add_pet_xp(self, user_id: int, amount: int):
        """Add XP to a pet and handle level-ups"""
        pet_data = self.get_pet_data(user_id)
        if not pet_data:
            return
        
        pet_data["xp"] += amount
        
        # Check if pet can level up
        current_level = pet_data["level"]
        pet_type = pet_data["type"]
        max_level = self.pet_types[pet_type]["max_level"]
        
        # Don't level up if already at max level
        if current_level >= max_level:
            return
        
        # Check if XP is enough for next level
        next_level = current_level + 1
        xp_needed = self.level_xp_requirements.get(next_level, 1000)
        
        if pet_data["xp"] >= xp_needed:
            pet_data["level"] = next_level
            self.save_pets_data()
    
    def add_item_to_inventory(self, user_id: int, item_type: str, item_name: str, quantity: int = 1):
        """Add an item to a pet's inventory"""
        pet_data = self.get_pet_data(user_id)
        if not pet_data:
            return False
        
        if item_type not in ["food", "toys"]:
            return False
        
        if item_name not in pet_data["inventory"][item_type]:
            pet_data["inventory"][item_type][item_name] = 0
        
        pet_data["inventory"][item_type][item_name] += quantity
        self.save_pets_data()
        return True
    
    def get_pet_status_emoji(self, pet_data: Dict) -> str:
        """Get emoji indicating pet's overall status"""
        hunger = pet_data["hunger"]
        happiness = pet_data["happiness"]
        energy = pet_data["energy"]
        
        if hunger <= 20 or happiness <= 20:
            return "😞"  # Sad/hungry
        elif hunger >= 80 and happiness >= 80 and energy >= 80:
            return "😄"  # Very happy and healthy
        elif hunger >= 50 and happiness >= 50:
            return "🙂"  # Content
        else:
            return "😐"  # Neutral
    
    @commands.group(aliases=["pet"], invoke_without_command=True)
    async def pets(self, ctx):
        """
        Sistema de Pets
        Usage: !pet
        """
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="🐾 Sistema de Pets",
                description="Adote e cuide do seu pet virtual!",
                color=discord.Color.teal()
            )
            
            prefix = ctx.prefix
            
            embed.add_field(
                name="Comandos Disponíveis",
                value=(
                    f"**`{prefix}pet adopt <tipo> <nome>`** - Adotar um pet\n"
                    f"**`{prefix}pet info`** - Ver informações do seu pet\n"
                    f"**`{prefix}pet feed <comida>`** - Alimentar seu pet\n"
                    f"**`{prefix}pet play [brinquedo]`** - Brincar com seu pet\n"
                    f"**`{prefix}pet sleep`** - Colocar seu pet para dormir\n"
                    f"**`{prefix}pet wake`** - Acordar seu pet\n"
                    f"**`{prefix}pet shop`** - Comprar itens para seu pet\n"
                    f"**`{prefix}pet inventory`** - Ver seu inventário de itens\n"
                    f"**`{prefix}pet types`** - Ver tipos de pets disponíveis"
                ),
                inline=False
            )
            
            await ctx.send(embed=embed)
    
    @pets.command(name="adopt")
    async def adopt_pet(self, ctx, pet_type: str = None, *, pet_name: str = None):
        """
        Adotar um pet
        Usage: !pet adopt <tipo> <nome>
        """
        if self.has_pet(ctx.author.id):
            pet_data = self.get_pet_data(ctx.author.id)
            return await ctx.send(f"❌ Você já tem um pet chamado **{pet_data['name']}**!")
        
        if pet_type is None or pet_name is None:
            embed = discord.Embed(
                title="🐾 Adoção de Pets",
                description="Para adotar um pet, use o comando:\n`!pet adopt <tipo> <nome>`",
                color=discord.Color.teal()
            )
            
            embed.add_field(
                name="Tipos disponíveis",
                value=(
                    "**dog** (Cachorro) 🐕\n"
                    "**cat** (Gato) 🐈\n"
                    "**bird** (Pássaro) 🐦\n"
                    "**rabbit** (Coelho) 🐇\n"
                    "**hamster** (Hamster) 🐹\n"
                    "**dragon** (Dragão) 🐉"
                ),
                inline=False
            )
            
            embed.add_field(
                name="Exemplo",
                value="`!pet adopt dog Rex`",
                inline=False
            )
            
            return await ctx.send(embed=embed)
        
        pet_type = pet_type.lower()
        
        if pet_type not in self.pet_types:
            pet_types_list = ", ".join(self.pet_types.keys())
            return await ctx.send(f"❌ Tipo de pet inválido! Tipos disponíveis: {pet_types_list}")
        
        if len(pet_name) > 20:
            return await ctx.send("❌ O nome do pet não pode ter mais de 20 caracteres!")
        
        # Create the pet
        self.create_pet(ctx.author.id, pet_type, pet_name)
        
        pet_emoji = self.pet_types[pet_type]["emoji"]
        pet_species = self.pet_types[pet_type]["name"]
        
        embed = discord.Embed(
            title=f"🎉 Pet Adotado!",
            description=f"Você adotou um(a) {pet_species} chamado(a) **{pet_name}**!",
            color=discord.Color.green()
        )
        
        embed.add_field(
            name="Próximos passos",
            value=(
                f"Use `!pet info` para ver informações do seu pet.\n"
                f"Alimente-o com `!pet feed <comida>`.\n"
                f"Brinque com ele usando `!pet play`."
            ),
            inline=False
        )
        
        embed.set_footer(text=f"Dica: Pets precisam de comida, diversão e descanso!")
        
        await ctx.send(embed=embed)
        
        # Add some starter items to inventory
        pet_data = self.get_pet_data(ctx.author.id)
        starter_food = self.pet_types[pet_type]["foods"][0]
        self.add_item_to_inventory(ctx.author.id, "food", starter_food, 3)
        
        await ctx.send(f"🎁 Você recebeu 3x {starter_food} como presente de boas-vindas!")
    
    @pets.command(name="info")
    async def pet_info(self, ctx, member: discord.Member = None):
        """
        Ver informações do seu pet
        Usage: !pet info [@membro]
        """
        target = member or ctx.author
        
        if not self.has_pet(target.id):
            if target.id == ctx.author.id:
                return await ctx.send("❌ Você não tem um pet! Use `!pet adopt` para adotar um.")
            else:
                return await ctx.send(f"❌ **{target.name}** não tem um pet!")
        
        # Update pet stats based on time passed
        self.update_pet_stats(target.id)
        
        pet_data = self.get_pet_data(target.id)
        pet_type = pet_data["type"]
        pet_type_data = self.pet_types[pet_type]
        
        pet_emoji = pet_type_data["emoji"]
        pet_species = pet_type_data["name"]
        
        # Calculate pet age in days
        creation_date = datetime.fromisoformat(pet_data["created_at"])
        days_old = (datetime.now() - creation_date).days
        
        # Calculate XP progress to next level
        current_level = pet_data["level"]
        current_xp = pet_data["xp"]
        
        if current_level < pet_type_data["max_level"]:
            next_level = current_level + 1
            xp_needed = self.level_xp_requirements.get(next_level, 1000)
            xp_progress = f"{current_xp}/{xp_needed}"
        else:
            xp_progress = f"{current_xp} (Nível máximo)"
        
        # Get status emoji
        status_emoji = self.get_pet_status_emoji(pet_data)
        
        # Create embed
        embed = discord.Embed(
            title=f"{pet_emoji} {pet_data['name']} {status_emoji}",
            description=f"**Tipo:** {pet_species}\n**Dono:** {target.mention}",
            color=discord.Color.teal()
        )
        
        # Stats
        embed.add_field(name="Nível", value=f"{pet_data['level']}/{pet_type_data['max_level']}", inline=True)
        embed.add_field(name="XP", value=xp_progress, inline=True)
        embed.add_field(name="Idade", value=f"{days_old} dias", inline=True)
        
        # Status bars
        hunger_bar = self.create_status_bar(pet_data["hunger"])
        happiness_bar = self.create_status_bar(pet_data["happiness"])
        energy_bar = self.create_status_bar(pet_data["energy"])
        
        embed.add_field(name="Fome", value=hunger_bar, inline=False)
        embed.add_field(name="Felicidade", value=happiness_bar, inline=False)
        embed.add_field(name="Energia", value=energy_bar, inline=False)
        
        # Status message
        status_message = "Dormindo 💤" if pet_data["sleeping"] else "Acordado 👀"
        embed.add_field(name="Status", value=status_message, inline=False)
        
        # Available abilities based on level
        abilities = []
        for i, ability in enumerate(pet_type_data["abilities"]):
            level_req = (i + 1) * 10
            if pet_data["level"] >= level_req:
                abilities.append(f"{ability} ✅")
            else:
                abilities.append(f"{ability} (Nível {level_req} necessário) ❌")
        
        if abilities:
            embed.add_field(name="Habilidades", value="\n".join(abilities), inline=False)
        
        embed.set_footer(text=f"Pet adotado em {creation_date.strftime('%d/%m/%Y')}")
        
        await ctx.send(embed=embed)
    
    def create_status_bar(self, value: float, max_value: float = 100.0, segments: int = 10) -> str:
        """Create a visual status bar using emoji"""
        value = max(0, min(value, max_value))
        filled_segments = int((value / max_value) * segments)
        
        if filled_segments <= 2:
            color = "🟥"  # Red for critical
        elif filled_segments <= 5:
            color = "🟨"  # Yellow for medium
        else:
            color = "🟩"  # Green for good
        
        bar = color * filled_segments + "⬜" * (segments - filled_segments)
        return f"{bar} {int(value)}%"
    
    @pets.command(name="feed")
    async def feed_pet_command(self, ctx, food_item: str = None):
        """
        Alimentar seu pet
        Usage: !pet feed <comida>
        """
        if not self.has_pet(ctx.author.id):
            return await ctx.send("❌ Você não tem um pet! Use `!pet adopt` para adotar um.")
        
        # Update pet stats
        self.update_pet_stats(ctx.author.id)
        
        pet_data = self.get_pet_data(ctx.author.id)
        pet_type = pet_data["type"]
        pet_type_data = self.pet_types[pet_type]
        
        if food_item is None:
            foods_list = ", ".join(pet_type_data["foods"])
            inventory = pet_data["inventory"]["food"]
            
            food_items = []
            for food in pet_type_data["foods"]:
                count = inventory.get(food, 0)
                food_items.append(f"{food}: {count}x")
            
            embed = discord.Embed(
                title=f"🍽️ Alimentar {pet_data['name']}",
                description=f"Use `!pet feed <comida>` para alimentar seu pet.",
                color=discord.Color.orange()
            )
            
            embed.add_field(
                name="Alimentos aceitos",
                value=foods_list,
                inline=False
            )
            
            embed.add_field(
                name="Seu inventário",
                value="\n".join(food_items) if food_items else "Você não tem comida! Use `!pet shop` para comprar.",
                inline=False
            )
            
            embed.add_field(
                name="Fome atual",
                value=self.create_status_bar(pet_data["hunger"]),
                inline=False
            )
            
            return await ctx.send(embed=embed)
        
        success, message = self.feed_pet(ctx.author.id, food_item)
        await ctx.send(message)
    
    @pets.command(name="play")
    async def play_with_pet_command(self, ctx, toy_item: str = None):
        """
        Brincar com seu pet
        Usage: !pet play [brinquedo]
        """
        if not self.has_pet(ctx.author.id):
            return await ctx.send("❌ Você não tem um pet! Use `!pet adopt` para adotar um.")
        
        # Update pet stats
        self.update_pet_stats(ctx.author.id)
        
        success, message = self.play_with_pet(ctx.author.id, toy_item)
        await ctx.send(message)
    
    @pets.command(name="sleep")
    async def sleep_pet_command(self, ctx):
        """
        Colocar seu pet para dormir
        Usage: !pet sleep
        """
        if not self.has_pet(ctx.author.id):
            return await ctx.send("❌ Você não tem um pet! Use `!pet adopt` para adotar um.")
        
        # Update pet stats
        self.update_pet_stats(ctx.author.id)
        
        success, message = self.put_pet_to_sleep(ctx.author.id)
        await ctx.send(message)
    
    @pets.command(name="wake")
    async def wake_pet_command(self, ctx):
        """
        Acordar seu pet
        Usage: !pet wake
        """
        if not self.has_pet(ctx.author.id):
            return await ctx.send("❌ Você não tem um pet! Use `!pet adopt` para adotar um.")
        
        # Update pet stats
        self.update_pet_stats(ctx.author.id)
        
        success, message = self.wake_pet_up(ctx.author.id)
        await ctx.send(message)
    
    @pets.command(name="shop")
    async def pet_shop(self, ctx):
        """
        Comprar itens para seu pet
        Usage: !pet shop
        """
        if not self.has_pet(ctx.author.id):
            return await ctx.send("❌ Você não tem um pet! Use `!pet adopt` para adotar um.")
        
        pet_data = self.get_pet_data(ctx.author.id)
        pet_type = pet_data["type"]
        pet_type_data = self.pet_types[pet_type]
        
        embed = discord.Embed(
            title="🛒 Loja de Pets",
            description="Aqui você pode comprar itens para seu pet!",
            color=discord.Color.gold()
        )
        
        # Food items for this pet
        food_items = []
        for food in pet_type_data["foods"]:
            price = random.randint(10, 30)  # Random price for demonstration
            food_items.append(f"{food}: {price} moedas")
        
        # Toy items for this pet
        toy_items = []
        for toy in pet_type_data["toys"]:
            price = random.randint(30, 100)  # Toys are more expensive
            toy_items.append(f"{toy}: {price} moedas")
        
        embed.add_field(
            name="🍽️ Comidas",
            value="\n".join(food_items),
            inline=False
        )
        
        embed.add_field(
            name="🎮 Brinquedos",
            value="\n".join(toy_items),
            inline=False
        )
        
        embed.add_field(
            name="Como comprar",
            value="Este é apenas um exemplo de loja. Para um sistema de loja funcional, é necessário integrar com o sistema de economia!",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @pets.command(name="inventory")
    async def pet_inventory(self, ctx):
        """
        Ver seu inventário de itens para pets
        Usage: !pet inventory
        """
        if not self.has_pet(ctx.author.id):
            return await ctx.send("❌ Você não tem um pet! Use `!pet adopt` para adotar um.")
        
        pet_data = self.get_pet_data(ctx.author.id)
        
        embed = discord.Embed(
            title=f"🎒 Inventário de {pet_data['name']}",
            description=f"Itens disponíveis para seu pet.",
            color=discord.Color.dark_green()
        )
        
        # Food items
        food_inventory = pet_data["inventory"]["food"]
        food_items = []
        
        if food_inventory:
            for food, quantity in food_inventory.items():
                if quantity > 0:
                    food_items.append(f"{food}: {quantity}x")
        
        embed.add_field(
            name="🍽️ Comidas",
            value="\n".join(food_items) if food_items else "Nenhum alimento disponível.",
            inline=False
        )
        
        # Toy items
        toy_inventory = pet_data["inventory"]["toys"]
        toy_items = []
        
        if toy_inventory:
            for toy, quantity in toy_inventory.items():
                if quantity > 0:
                    toy_items.append(f"{toy}: {quantity}x")
        
        embed.add_field(
            name="🎮 Brinquedos",
            value="\n".join(toy_items) if toy_items else "Nenhum brinquedo disponível.",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @pets.command(name="types")
    async def pet_types_command(self, ctx):
        """
        Ver os tipos de pets disponíveis
        Usage: !pet types
        """
        embed = discord.Embed(
            title="🐾 Tipos de Pets Disponíveis",
            description="Escolha o tipo de pet que você deseja adotar!",
            color=discord.Color.teal()
        )
        
        for pet_code, pet_data in self.pet_types.items():
            embed.add_field(
                name=f"{pet_data['emoji']} {pet_data['name']} (`{pet_code}`)",
                value=(
                    f"**Nível máximo:** {pet_data['max_level']}\n"
                    f"**Habilidades:** {', '.join(pet_data['abilities'])}\n"
                    f"**Comidas:** {', '.join(pet_data['foods'])}"
                ),
                inline=False
            )
        
        embed.set_footer(text="Use !pet adopt <tipo> <nome> para adotar um pet!")
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Pets(bot))