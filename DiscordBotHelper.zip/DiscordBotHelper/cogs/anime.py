"""
Anime-related commands for the Discord bot.
Provides anime information, images, and other anime-related features.
"""
import random
import aiohttp
import discord
from discord.ext import commands
import logging
import json
import os
from typing import Dict, List, Optional, Union

logger = logging.getLogger(__name__)

class Anime(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.jikan_rate_limit = 4  # Seconds between requests to avoid rate limits
        self.last_jikan_request = 0
        self.anime_cache = {}
        self.character_cache = {}
        
        # Safebooru categories for anime images
        self.image_categories = [
            "waifu",
            "neko",
            "shinobu",
            "megumin",
            "bully",
            "cuddle",
            "cry",
            "hug",
            "awoo",
            "kiss",
            "lick",
            "pat",
            "smug",
            "bonk",
            "yeet",
            "blush",
            "smile",
            "wave",
            "highfive",
            "handhold",
            "nom",
            "bite",
            "slap",
            "happy",
            "wink",
            "dance",
            "cringe"
        ]
    
    @commands.group(aliases=["a", "ani"], invoke_without_command=True)
    async def anime(self, ctx, *, anime_name: str = None):
        """
        Informações sobre anime
        Usage: !anime <nome do anime>
        """
        if ctx.invoked_subcommand is None:
            if anime_name is None:
                embed = discord.Embed(
                    title="🎌 Comandos de Anime",
                    description="Use estes comandos para obter informações relacionadas a anime!",
                    color=discord.Color.purple()
                )
                
                prefix = ctx.prefix
                
                embed.add_field(
                    name="Comandos Disponíveis",
                    value=(
                        f"**`{prefix}anime <nome do anime>`** - Pesquisar informações sobre um anime\n"
                        f"**`{prefix}anime character <nome do personagem>`** - Pesquisar informações sobre um personagem\n"
                        f"**`{prefix}anime random`** - Obter informações sobre um anime aleatório\n"
                        f"**`{prefix}anime season [ano] [temporada]`** - Ver animes da temporada atual ou especificada\n"
                        f"**`{prefix}anime image <categoria>`** - Obter uma imagem de anime"
                    ),
                    inline=False
                )
                
                return await ctx.send(embed=embed)
            
            await self.search_anime(ctx, anime_name)
    
    async def search_anime(self, ctx, anime_name: str):
        """Search for anime information using Jikan API"""
        loading_message = await ctx.send("🔍 Pesquisando informações sobre o anime...")
        
        # Use cache if available
        cache_key = anime_name.lower().strip()
        if cache_key in self.anime_cache:
            anime_data = self.anime_cache[cache_key]
            await loading_message.delete()
            return await self.send_anime_embed(ctx, anime_data)
        
        # Search using Jikan API
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.jikan.moe/v4/anime?q={anime_name}&sfw=true") as response:
                    if response.status != 200:
                        await loading_message.delete()
                        return await ctx.send(f"❌ Não foi possível acessar a API do Jikan. Status: {response.status}")
                    
                    data = await response.json()
                    
                    if not data.get("data") or len(data["data"]) == 0:
                        await loading_message.delete()
                        return await ctx.send(f"❌ Nenhum anime encontrado com o nome '{anime_name}'.")
                    
                    # Get first result
                    anime_data = data["data"][0]
                    self.anime_cache[cache_key] = anime_data
                    
                    await loading_message.delete()
                    await self.send_anime_embed(ctx, anime_data)
        except Exception as e:
            logger.error(f"Error searching anime: {e}")
            await loading_message.delete()
            await ctx.send(f"❌ Ocorreu um erro ao buscar informações: {str(e)}")
    
    async def send_anime_embed(self, ctx, anime_data: Dict):
        """Format and send anime information embed"""
        try:
            # Extract information
            title = anime_data["title"]
            english_title = anime_data.get("title_english", "N/A")
            japanese_title = anime_data.get("title_japanese", "N/A")
            synopsis = anime_data.get("synopsis", "Sem sinopse disponível.")
            
            # Truncate synopsis if too long
            if len(synopsis) > 300:
                synopsis = synopsis[:297] + "..."
            
            image_url = anime_data.get("images", {}).get("jpg", {}).get("large_image_url", "")
            episodes = anime_data.get("episodes", "?")
            score = anime_data.get("score", "N/A")
            status = anime_data.get("status", "N/A")
            aired = anime_data.get("aired", {}).get("string", "N/A")
            duration = anime_data.get("duration", "N/A")
            rating = anime_data.get("rating", "N/A")
            
            # Get genres
            genres = []
            for genre in anime_data.get("genres", []):
                genres.append(genre.get("name", ""))
            
            # Create embed
            embed = discord.Embed(
                title=title,
                description=synopsis,
                color=discord.Color.blue(),
                url=anime_data.get("url", "")
            )
            
            # Add information fields
            if english_title != "N/A" and english_title != title:
                embed.add_field(name="Título em Inglês", value=english_title, inline=True)
            
            if japanese_title != "N/A":
                embed.add_field(name="Título em Japonês", value=japanese_title, inline=True)
            
            embed.add_field(name="Episódios", value=episodes, inline=True)
            embed.add_field(name="Pontuação", value=score, inline=True)
            embed.add_field(name="Status", value=status, inline=True)
            embed.add_field(name="Exibido", value=aired, inline=True)
            embed.add_field(name="Duração", value=duration, inline=True)
            embed.add_field(name="Classificação", value=rating, inline=True)
            
            if genres:
                embed.add_field(name="Gêneros", value=", ".join(genres), inline=False)
            
            # Set thumbnail
            if image_url:
                embed.set_thumbnail(url=image_url)
            
            # Set footer
            embed.set_footer(text="Informações via MyAnimeList")
            
            await ctx.send(embed=embed)
        
        except Exception as e:
            logger.error(f"Error creating anime embed: {e}")
            await ctx.send(f"❌ Ocorreu um erro ao exibir informações: {str(e)}")
    
    @anime.command(name="character", aliases=["char", "personagem"])
    async def anime_character(self, ctx, *, character_name: str = None):
        """
        Pesquisar informações sobre um personagem de anime
        Usage: !anime character <nome do personagem>
        """
        if character_name is None:
            return await ctx.send("❌ Por favor, forneça o nome de um personagem para pesquisar!")
        
        loading_message = await ctx.send("🔍 Pesquisando informações sobre o personagem...")
        
        # Use cache if available
        cache_key = character_name.lower().strip()
        if cache_key in self.character_cache:
            character_data = self.character_cache[cache_key]
            await loading_message.delete()
            return await self.send_character_embed(ctx, character_data)
        
        # Search using Jikan API
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.jikan.moe/v4/characters?q={character_name}") as response:
                    if response.status != 200:
                        await loading_message.delete()
                        return await ctx.send(f"❌ Não foi possível acessar a API do Jikan. Status: {response.status}")
                    
                    data = await response.json()
                    
                    if not data.get("data") or len(data["data"]) == 0:
                        await loading_message.delete()
                        return await ctx.send(f"❌ Nenhum personagem encontrado com o nome '{character_name}'.")
                    
                    # Get first result
                    character_data = data["data"][0]
                    
                    # Get more detailed character information
                    char_id = character_data["mal_id"]
                    async with session.get(f"https://api.jikan.moe/v4/characters/{char_id}/full") as detailed_response:
                        if detailed_response.status == 200:
                            detailed_data = await detailed_response.json()
                            if detailed_data.get("data"):
                                character_data = detailed_data["data"]
                    
                    self.character_cache[cache_key] = character_data
                    
                    await loading_message.delete()
                    await self.send_character_embed(ctx, character_data)
        except Exception as e:
            logger.error(f"Error searching character: {e}")
            await loading_message.delete()
            await ctx.send(f"❌ Ocorreu um erro ao buscar informações: {str(e)}")
    
    async def send_character_embed(self, ctx, character_data: Dict):
        """Format and send character information embed"""
        try:
            # Extract information
            name = character_data["name"]
            name_kanji = character_data.get("name_kanji", "N/A")
            about = character_data.get("about", "Sem informações disponíveis.")
            
            # Truncate about if too long
            if len(about) > 500:
                about = about[:497] + "..."
            
            image_url = character_data.get("images", {}).get("jpg", {}).get("image_url", "")
            
            # Get anime appearances
            animes = []
            for anime in character_data.get("anime", []):
                anime_info = anime.get("anime", {})
                if anime_info:
                    animes.append(anime_info.get("title", ""))
            
            # Create embed
            embed = discord.Embed(
                title=name,
                description=about,
                color=discord.Color.purple(),
                url=character_data.get("url", "")
            )
            
            # Add information fields
            if name_kanji != "N/A":
                embed.add_field(name="Nome em Kanji", value=name_kanji, inline=True)
            
            if animes:
                # Show up to 5 anime appearances
                anime_list = animes[:5]
                if len(animes) > 5:
                    anime_list.append(f"E mais {len(animes) - 5} outros...")
                
                embed.add_field(name="Aparece em", value="\n".join(anime_list), inline=False)
            
            # Set image
            if image_url:
                embed.set_image(url=image_url)
            
            # Set footer
            embed.set_footer(text="Informações via MyAnimeList")
            
            await ctx.send(embed=embed)
        
        except Exception as e:
            logger.error(f"Error creating character embed: {e}")
            await ctx.send(f"❌ Ocorreu um erro ao exibir informações: {str(e)}")
    
    @anime.command(name="random")
    async def anime_random(self, ctx):
        """
        Obter informações sobre um anime aleatório
        Usage: !anime random
        """
        loading_message = await ctx.send("🎲 Gerando um anime aleatório...")
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get("https://api.jikan.moe/v4/random/anime") as response:
                    if response.status != 200:
                        await loading_message.delete()
                        return await ctx.send(f"❌ Não foi possível acessar a API do Jikan. Status: {response.status}")
                    
                    data = await response.json()
                    
                    if not data.get("data"):
                        await loading_message.delete()
                        return await ctx.send("❌ Não foi possível obter um anime aleatório.")
                    
                    anime_data = data["data"]
                    
                    # Skip adult content
                    if anime_data.get("rating") == "Rx - Hentai" or anime_data.get("genres", [{"name": ""}])[0].get("name") == "Hentai":
                        await loading_message.delete()
                        return await self.anime_random(ctx)
                    
                    await loading_message.delete()
                    await self.send_anime_embed(ctx, anime_data)
        except Exception as e:
            logger.error(f"Error getting random anime: {e}")
            await loading_message.delete()
            await ctx.send(f"❌ Ocorreu um erro ao buscar anime: {str(e)}")
    
    @anime.command(name="season")
    async def anime_season(self, ctx, year: int = None, season: str = None):
        """
        Ver animes da temporada atual ou especificada
        Usage: !anime season [ano] [temporada]
        Temporadas: winter, spring, summer, fall
        """
        # If no year/season provided, use current
        if year is None or season is None:
            loading_message = await ctx.send("🔍 Buscando animes da temporada atual...")
            season_url = "https://api.jikan.moe/v4/seasons/now"
            season_text = "atual"
        else:
            # Validate season
            valid_seasons = ["winter", "spring", "summer", "fall"]
            season = season.lower()
            
            if season not in valid_seasons:
                return await ctx.send(f"❌ Temporada inválida! Use: {', '.join(valid_seasons)}")
            
            loading_message = await ctx.send(f"🔍 Buscando animes da temporada {season} de {year}...")
            season_url = f"https://api.jikan.moe/v4/seasons/{year}/{season}"
            season_text = f"{season} de {year}"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(season_url) as response:
                    if response.status != 200:
                        await loading_message.delete()
                        return await ctx.send(f"❌ Não foi possível acessar a API do Jikan. Status: {response.status}")
                    
                    data = await response.json()
                    
                    if not data.get("data") or len(data["data"]) == 0:
                        await loading_message.delete()
                        return await ctx.send(f"❌ Nenhum anime encontrado para a temporada {season_text}.")
                    
                    # Get top 10 animes of the season
                    animes = data["data"][:10]
                    
                    # Create embed
                    embed = discord.Embed(
                        title=f"🌸 Animes da Temporada {season_text.capitalize()}",
                        color=discord.Color.teal()
                    )
                    
                    for i, anime in enumerate(animes, 1):
                        title = anime.get("title", "Sem título")
                        score = anime.get("score", "N/A")
                        episodes = anime.get("episodes", "?")
                        
                        embed.add_field(
                            name=f"{i}. {title}",
                            value=f"⭐ **Score:** {score}\n📺 **Episódios:** {episodes}",
                            inline=False
                        )
                    
                    embed.set_footer(text="Informações via MyAnimeList")
                    
                    await loading_message.delete()
                    await ctx.send(embed=embed)
        except Exception as e:
            logger.error(f"Error getting season anime: {e}")
            await loading_message.delete()
            await ctx.send(f"❌ Ocorreu um erro ao buscar animes: {str(e)}")
    
    @anime.command(name="image", aliases=["img", "pic"])
    async def anime_image(self, ctx, category: str = None):
        """
        Obter uma imagem de anime de uma categoria específica
        Usage: !anime image <categoria>
        """
        if category is None:
            categories_text = ", ".join(self.image_categories)
            return await ctx.send(f"❌ Por favor, especifique uma categoria! Categorias disponíveis: {categories_text}")
        
        category = category.lower()
        
        if category not in self.image_categories:
            categories_text = ", ".join(self.image_categories)
            return await ctx.send(f"❌ Categoria inválida! Categorias disponíveis: {categories_text}")
        
        loading_message = await ctx.send(f"🖼️ Buscando uma imagem de anime da categoria: {category}...")
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.waifu.pics/sfw/{category}") as response:
                    if response.status != 200:
                        await loading_message.delete()
                        return await ctx.send(f"❌ Não foi possível acessar a API. Status: {response.status}")
                    
                    data = await response.json()
                    
                    if not data.get("url"):
                        await loading_message.delete()
                        return await ctx.send("❌ Não foi possível obter uma imagem.")
                    
                    image_url = data["url"]
                    
                    # Create embed
                    embed = discord.Embed(
                        title=f"🖼️ Imagem de Anime: {category.capitalize()}",
                        color=discord.Color.random()
                    )
                    
                    embed.set_image(url=image_url)
                    embed.set_footer(text=f"Solicitado por {ctx.author.name}")
                    
                    await loading_message.delete()
                    await ctx.send(embed=embed)
        except Exception as e:
            logger.error(f"Error getting anime image: {e}")
            await loading_message.delete()
            await ctx.send(f"❌ Ocorreu um erro ao buscar imagem: {str(e)}")
    
    @commands.command(aliases=["waifu"])
    async def anime_girl(self, ctx):
        """
        Receba uma imagem aleatória de waifu
        Usage: !waifu
        """
        await self.anime_image(ctx, "waifu")
    
    @commands.command(aliases=["neko"])
    async def anime_cat(self, ctx):
        """
        Receba uma imagem aleatória de neko
        Usage: !neko
        """
        await self.anime_image(ctx, "neko")

async def setup(bot):
    await bot.add_cog(Anime(bot))