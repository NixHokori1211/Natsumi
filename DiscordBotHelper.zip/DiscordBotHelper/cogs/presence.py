"""
Rich Presence functionality for the Discord bot.
Allows the bot to display detailed and dynamic activity statuses.
"""
import discord
from discord.ext import commands, tasks
import logging
import random
import datetime
import asyncio

logger = logging.getLogger(__name__)

class RichPresence(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.status_index = 0
        self.start_time = datetime.datetime.now()
        
        # List of different streaming statuses to cycle through
        self.status_list = [
            {"name": "I love you, Chwrmoon", "url": "https://www.twitch.tv/discord"},
            {"name": "Live Support 24/7", "url": "https://www.twitch.tv/discord"},
            {"name": "Serving {guild_count} servers", "url": "https://www.twitch.tv/discord"},
            {"name": "Live with {user_count} users", "url": "https://www.twitch.tv/discord"},
            {"name": "LIVE: {command_prefix}help for commands", "url": "https://www.twitch.tv/discord"},
            {"name": "Version 1.0.0 LIVE", "url": "https://www.twitch.tv/discord"},
            {"name": "🔴 LIVE: Bot Transmission", "url": "https://www.twitch.tv/discord"},
        ]
        
        # Start the status rotation
        self.rotate_status.start()
    
    def cog_unload(self):
        """Clean up when cog is unloaded"""
        self.rotate_status.cancel()
    
    @tasks.loop(minutes=2.0)
    async def rotate_status(self):
        """Rotate through different statuses"""
        # Get current status from list
        current_status = self.status_list[self.status_index]
        
        # Format dynamic values in status text
        status_name = current_status["name"]
        status_name = status_name.format(
            guild_count=len(self.bot.guilds),
            user_count=sum(guild.member_count for guild in self.bot.guilds),
            command_prefix=self.bot.command_prefix,
            uptime=self._get_uptime_string()
        )
        
        # Create streaming activity object
        activity = discord.Streaming(name=status_name, url=current_status["url"])
        
        # Update bot presence
        await self.bot.change_presence(activity=activity)
        logger.debug(f"Updated rich presence: Streaming {status_name}")
        
        # Move to next status in rotation
        self.status_index = (self.status_index + 1) % len(self.status_list)
    
    @rotate_status.before_loop
    async def before_rotate_status(self):
        """Wait until bot is ready before starting the status rotation"""
        await self.bot.wait_until_ready()
    
    def _get_uptime_string(self):
        """Format uptime as a readable string"""
        uptime = datetime.datetime.now() - self.start_time
        
        # Calculate days, hours, minutes
        days = uptime.days
        hours, remainder = divmod(uptime.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        if days > 0:
            return f"{days}d {hours}h {minutes}m"
        elif hours > 0:
            return f"{hours}h {minutes}m"
        else:
            return f"{minutes}m {seconds}s"
    
    @commands.command(name="setstatus")
    @commands.is_owner()
    async def set_status(self, ctx, *, status_text=None):
        """
        Manually set the bot's streaming status
        Usage: !setstatus [status text]
        """
        if not status_text:
            await ctx.send("❌ Please provide a status text. Example: `!setstatus Live Bot Commands`")
            return
        
        # Pause the rotation
        self.rotate_status.cancel()
        
        # Set the custom streaming status
        activity = discord.Streaming(name=status_text, url="https://www.twitch.tv/discord")
        await self.bot.change_presence(activity=activity)
        
        await ctx.send(f"✅ Streaming status set to: \"🔴 LIVE: {status_text}\"")
        logger.info(f"Manual streaming status set by {ctx.author}: {status_text}")
    
    @commands.command(name="resumerotation")
    @commands.is_owner()
    async def resume_rotation(self, ctx):
        """
        Resume the status rotation if it was stopped
        Usage: !resumerotation
        """
        if not self.rotate_status.is_running():
            self.rotate_status.start()
            await ctx.send("✅ Status rotation resumed")
            logger.info(f"Status rotation resumed by {ctx.author}")
        else:
            await ctx.send("ℹ️ Status rotation is already running")
    
    @commands.command(name="addstatus")
    @commands.is_owner()
    async def add_status(self, ctx, *, status_text=None):
        """
        Add a new streaming status to the rotation
        Usage: !addstatus [status text]
        """
        if not status_text:
            await ctx.send("❌ Please provide status text. Example: `!addstatus Live Bot Commands`")
            return
        
        # Add the new streaming status
        self.status_list.append({
            "name": status_text,
            "url": "https://www.twitch.tv/discord"
        })
        
        await ctx.send(f"✅ Added new streaming status to rotation: \"🔴 LIVE: {status_text}\"")
        logger.info(f"New streaming status added by {ctx.author}: {status_text}")
    
    @commands.command(name="liststatus")
    @commands.is_owner()
    async def list_status(self, ctx):
        """
        List all streaming statuses in the rotation
        Usage: !liststatus
        """
        embed = discord.Embed(
            title="Streaming Status Rotation List",
            description=f"Currently on index {self.status_index}",
            color=discord.Color.purple()  # Purple for streaming
        )
        
        for i, status in enumerate(self.status_list):
            embed.add_field(
                name=f"{i+1}. 🔴 LIVE", 
                value=status['name'],
                inline=False
            )
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(RichPresence(bot))