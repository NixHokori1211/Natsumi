"""
Music commands for the Discord bot.
Allows users to play music from YouTube and other supported platforms.
"""
import asyncio
import json
import logging
import math
import os
import random
import re
from datetime import datetime
from functools import partial
from typing import Optional, List, Dict, Any

import aiohttp
import discord
import requests
import yt_dlp
from discord.ext import commands

# Configure logging
logger = logging.getLogger(__name__)

# Suppress noise about console usage from errors
yt_dlp.utils.bug_reports_message = lambda: ""

# Setup yt-dlp options
YTDL_FORMAT_OPTIONS = {
    "format": "bestaudio/best",
    "outtmpl": "%(extractor)s-%(id)s-%(title)s.%(ext)s",
    "restrictfilenames": True,
    "noplaylist": True,
    "nocheckcertificate": True,
    "ignoreerrors": False,
    "logtostderr": False,
    "quiet": True,
    "no_warnings": True,
    "default_search": "auto",
    "source_address": "0.0.0.0"  # Bind to IPv4 since IPv6 can cause issues
}

FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn'
}

# Create ytdl with the options
ytdl = yt_dlp.YoutubeDL(YTDL_FORMAT_OPTIONS)


class YTDLSource(discord.PCMVolumeTransformer):
    """A class that handles downloading and playing music from YT and other platforms"""
    
    def __init__(self, source, *, data, volume=0.5):
        super().__init__(source, volume)
        
        self.data = data
        self.title = data.get('title')
        self.url = data.get('url')
        self.thumbnail = data.get('thumbnail')
        self.duration = self.parse_duration(int(data.get('duration', 0)))
        self.webpage_url = data.get('webpage_url')
        self.uploader = data.get('uploader')
        self.uploader_url = data.get('uploader_url')
        self.views = data.get('view_count', 0)
        self.likes = data.get('like_count', 0)
        
    @staticmethod
    def parse_duration(duration: int) -> str:
        """Convert duration in seconds to a string format"""
        if duration > 0:
            minutes, seconds = divmod(duration, 60)
            hours, minutes = divmod(minutes, 60)
            
            duration_str = f"{minutes:02d}:{seconds:02d}"
            if hours > 0:
                duration_str = f"{hours:02d}:{duration_str}"
                
            return duration_str
        return "00:00"
        
    @classmethod
    async def create_source(cls, search: str, *, loop: asyncio.AbstractEventLoop = None, stream: bool = True) -> dict:
        """
        Creates a source dictionary with information about the song
        
        Args:
            search: The song query or URL
            loop: The event loop to use
            stream: Whether to stream the song or download it
            
        Returns:
            A dictionary with song information
        """
        loop = loop or asyncio.get_event_loop()
        
        # Run YTDL in a separate thread to avoid blocking
        to_run = partial(ytdl.extract_info, url=search, download=not stream)
        data = await loop.run_in_executor(None, to_run)
        
        if 'entries' in data:
            # Take the first item from a playlist
            data = data['entries'][0]
            
        return {'title': data['title'], 'id': data['id'], 'url': data['url'], 'webpage_url': data['webpage_url'],
                'thumbnail': data['thumbnail'], 'duration': data.get('duration', 0), 'uploader': data.get('uploader', 'Unknown'),
                'uploader_url': data.get('uploader_url'), 'view_count': data.get('view_count', 0),
                'like_count': data.get('like_count', 0)}
    
    @classmethod
    async def from_url(cls, url, *, loop=None, stream=True):
        """Create a source directly from a URL"""
        loop = loop or asyncio.get_event_loop()
        data = await cls.create_source(url, loop=loop, stream=stream)
        
        filename = data['url']
        return cls(discord.FFmpegPCMAudio(filename, **FFMPEG_OPTIONS), data=data)


class MusicPlayer:
    """Main player class to handle a guild's music queue and playback"""
    
    def __init__(self, ctx):
        self.bot = ctx.bot
        self.guild = ctx.guild
        self.channel = ctx.channel
        self.cog = ctx.cog
        
        self.queue = []
        self.next_song = asyncio.Event()
        
        self.volume = 0.5
        self.current = None
        self.np_message = None  # Now playing message
        
        self.bot.loop.create_task(self.player_loop())
        
    async def player_loop(self):
        """The main player loop that plays songs from the queue"""
        await self.bot.wait_until_ready()
        
        while not self.bot.is_closed():
            self.next_song.clear()
            
            # Try to get a song from the queue
            try:
                # Wait for the next song. If timeout, stop the player
                async with asyncio.timeout(300):  # 5 minutes
                    if not self.queue:
                        # No songs in queue, wait for new ones
                        await self.next_song.wait()
                        
                    # Get the next song
                    source_dict = self.queue.pop(0)
                    url = source_dict['webpage_url']
            except asyncio.TimeoutError:
                # No song added in 5 minutes, cleanup
                return self.destroy(self.guild)
                
            # Download and create the source
            try:
                source = await YTDLSource.from_url(url, loop=self.bot.loop, stream=True)
                source.volume = self.volume
                self.current = source
                
                # Play the song
                self.guild.voice_client.play(source, after=lambda _: self.bot.loop.call_soon_threadsafe(self.next_song.set))
                
                # Create embed for now playing
                embed = discord.Embed(
                    title="Tocando agora / Now playing",
                    description=f"[{source.title}]({source.webpage_url})",
                    color=discord.Color.green()
                )
                embed.set_thumbnail(url=source.thumbnail)
                
                # Add song details
                embed.add_field(name="Duração / Duration", value=source.duration, inline=True)
                embed.add_field(name="Requisitado por / Requested by", value=source_dict['requester'], inline=True)
                embed.add_field(name="Uploader", value=f"[{source.uploader}]({source.uploader_url})" if source.uploader_url else source.uploader, inline=True)
                
                # Add stats if available
                if source.views:
                    embed.add_field(name="Visualizações / Views", value=f"{source.views:,}", inline=True)
                if source.likes:
                    embed.add_field(name="Likes", value=f"{source.likes:,}", inline=True)
                
                # Send the now playing message and store it for later use
                self.np_message = await self.channel.send(embed=embed)
                
                # Update song history for this song for anyone in the voice channel
                # This will help with recommendations
                if isinstance(source_dict.get('requester_id'), int):
                    try:
                        self.cog.add_song_to_history(source_dict['requester_id'], source_dict)
                    except Exception as e:
                        logger.error(f"Error adding song to history: {e}")
                
                # Wait for the song to finish
                await self.next_song.wait()
                
                # Clean up
                self.current = None
                if self.np_message:
                    try:
                        await self.np_message.delete()
                    except discord.HTTPException:
                        pass
                    self.np_message = None
                    
            except Exception as e:
                logger.error(f"Player error: {e}")
                await self.channel.send(f"❌ Erro ao tocar música: {e}")
                continue
    
    def destroy(self, guild):
        """Destroys the player and disconnects from voice"""
        return self.bot.loop.create_task(self.cog.cleanup(guild))


class Music(commands.Cog):
    """Music playback commands"""
    
    def __init__(self, bot):
        self.bot = bot
        self.players = {}  # Guild ID -> Music Player
        
        # Carregar dados de playlists salvas
        self.playlists_file = "playlists.json"
        self.playlists = self.load_playlists()
        
        # Dicionário para armazenar histórico de músicas por usuário
        # user_id -> [song_data]
        self.user_history = {}
        
        # Limite de músicas para manter no histórico
        self.history_limit = 50
    
    def get_player(self, ctx):
        """Retrieve or create a music player for the guild"""
        try:
            player = self.players.get(ctx.guild.id)
            
            if not player:
                player = MusicPlayer(ctx)
                self.players[ctx.guild.id] = player
                
            return player
        except Exception as e:
            logger.error(f"Error getting player: {e}")
            raise commands.CommandError(f"Erro ao obter player: {e}")
    
    async def cleanup(self, guild):
        """Disconnect and cleanup the player"""
        try:
            await guild.voice_client.disconnect()
        except AttributeError:
            pass
            
        try:
            del self.players[guild.id]
        except KeyError:
            pass
    
    @commands.command(name="join")
    async def join(self, ctx):
        """
        Entrar no canal de voz
        Usage: !join
        """
        if ctx.author.voice is None:
            return await ctx.send("Você precisa estar em um canal de voz para usar este comando.")
            
        if ctx.voice_client is not None:
            # Already in a voice channel, move to the new one
            return await ctx.voice_client.move_to(ctx.author.voice.channel)
            
        # Join the channel
        await ctx.author.voice.channel.connect()
        await ctx.send(f"Conectado a: {ctx.author.voice.channel.name}")
    
    @commands.command(name="leave", aliases=["disconnect", "dc"])
    async def leave(self, ctx):
        """
        Sair do canal de voz
        Usage: !leave
        """
        if ctx.voice_client is None:
            return await ctx.send("Não estou conectado a um canal de voz.")
            
        await self.cleanup(ctx.guild)
        await ctx.send("Desconectado do canal de voz.")
    
    @commands.command(name="play", aliases=["p"])
    async def play(self, ctx, *, search: str = None):
        """
        Tocar música do YouTube (URL ou busca)
        Usage: !play <url ou busca>
        """
        if search is None:
            return await ctx.send("Você precisa especificar uma música para tocar.")
            
        # Join the channel if not already in one
        if ctx.voice_client is None:
            if ctx.author.voice:
                await ctx.author.voice.channel.connect()
            else:
                return await ctx.send("Você precisa estar em um canal de voz para usar este comando.")
        
        # Send searching message
        search_msg = await ctx.send(f"🔍 Buscando: `{search}`")
        
        try:
            # Create source information
            source_data = await YTDLSource.create_source(search, loop=self.bot.loop)
            
            # Add requester info
            source_data['requester'] = ctx.author.mention
            source_data['requester_id'] = ctx.author.id
            
            # Get the player and add to queue
            player = self.get_player(ctx)
            player.queue.append(source_data)
            
            # Update user's song history for recommendations
            await self.update_play_history(ctx, source_data)
            
            # Create and send embed
            embed = discord.Embed(
                title="Adicionado à fila / Added to queue",
                description=f"[{source_data['title']}]({source_data['webpage_url']})",
                color=discord.Color.blue()
            )
            
            # Add duration if available
            if source_data.get('duration'):
                duration = YTDLSource.parse_duration(int(source_data['duration']))
                embed.add_field(name="Duração / Duration", value=duration, inline=True)
                
            embed.add_field(name="Posição na fila / Queue position", value=str(len(player.queue)), inline=True)
            embed.set_thumbnail(url=source_data['thumbnail'])
            embed.set_footer(text=f"Requisitado por / Requested by: {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
            
            # Delete searching message and send the added to queue message
            await search_msg.delete()
            await ctx.send(embed=embed)
            
            # If nothing is playing, trigger the next song
            if not ctx.voice_client.is_playing():
                player.next_song.set()
                
        except Exception as e:
            logger.error(f"Play error: {e}")
            await search_msg.delete()
            await ctx.send(f"❌ Erro ao adicionar música: {e}")
    
    @commands.command(name="pause")
    async def pause(self, ctx):
        """
        Pausar a música atual
        Usage: !pause
        """
        if ctx.voice_client is None or not ctx.voice_client.is_playing():
            return await ctx.send("Não estou tocando nada no momento.")
            
        ctx.voice_client.pause()
        await ctx.send("⏸️ Música pausada.")
    
    @commands.command(name="resume", aliases=["unpause"])
    async def resume(self, ctx):
        """
        Retomar música pausada
        Usage: !resume
        """
        if ctx.voice_client is None:
            return await ctx.send("Não estou conectado a um canal de voz.")
            
        if ctx.voice_client.is_paused():
            ctx.voice_client.resume()
            await ctx.send("▶️ Música retomada.")
        else:
            await ctx.send("A música não está pausada.")
    
    @commands.command(name="skip", aliases=["s"])
    async def skip(self, ctx):
        """
        Pular para a próxima música na fila
        Usage: !skip
        """
        if ctx.voice_client is None or not ctx.voice_client.is_playing():
            return await ctx.send("Não estou tocando nada no momento.")
            
        ctx.voice_client.stop()
        await ctx.send("⏭️ Música pulada.")
    
    @commands.command(name="queue", aliases=["q"])
    async def queue_info(self, ctx):
        """
        Exibir a fila de músicas atual
        Usage: !queue
        """
        player = self.get_player(ctx)
        
        if not player.queue and not player.current:
            return await ctx.send("A fila está vazia e nada está tocando no momento.")
            
        # Set up the embed
        embed = discord.Embed(
            title="Fila de Músicas / Music Queue",
            color=discord.Color.blue()
        )
        
        # Add current song if playing
        if player.current:
            embed.add_field(
                name="Tocando agora / Now playing",
                value=f"[{player.current.title}]({player.current.webpage_url}) | `{player.current.duration}`",
                inline=False
            )
        
        # Add queued songs if any
        if player.queue:
            # Calculate total pages and current page
            items_per_page = 10
            pages = math.ceil(len(player.queue) / items_per_page)
            page = 1
            
            # Create a field for up to 10 songs
            queue_value = ""
            start_idx = (page - 1) * items_per_page
            end_idx = min(start_idx + items_per_page, len(player.queue))
            
            for i, song in enumerate(player.queue[start_idx:end_idx], start=start_idx + 1):
                duration = YTDLSource.parse_duration(int(song.get('duration', 0)))
                queue_value += f"`{i}.` [{song['title']}]({song['webpage_url']}) | `{duration}` | {song['requester']}\n"
                
            if queue_value:
                embed.add_field(name=f"Próximas músicas / Next songs (Page {page}/{pages})", value=queue_value, inline=False)
                
            # Add queue info
            total_duration = sum(int(song.get('duration', 0)) for song in player.queue)
            embed.set_footer(text=f"Total: {len(player.queue)} música(s) | Duração: {YTDLSource.parse_duration(total_duration)}")
        else:
            embed.add_field(name="Próximas músicas / Next songs", value="Não há músicas na fila.", inline=False)
            
        await ctx.send(embed=embed)
    
    @commands.command(name="nowplaying", aliases=["np", "current"])
    async def now_playing(self, ctx):
        """
        Mostrar informações sobre a música atual
        Usage: !nowplaying
        """
        player = self.get_player(ctx)
        
        if not player.current:
            return await ctx.send("Não estou tocando nada no momento.")
            
        # Create embed
        embed = discord.Embed(
            title="Tocando agora / Now playing",
            description=f"[{player.current.title}]({player.current.webpage_url})",
            color=discord.Color.green()
        )
        embed.set_thumbnail(url=player.current.thumbnail)
        
        # Add details
        embed.add_field(name="Duração / Duration", value=player.current.duration, inline=True)
        
        if player.current.uploader:
            embed.add_field(
                name="Uploader", 
                value=f"[{player.current.uploader}]({player.current.uploader_url})" if player.current.uploader_url else player.current.uploader, 
                inline=True
            )
        
        # Add stats if available
        if player.current.views:
            embed.add_field(name="Visualizações / Views", value=f"{player.current.views:,}", inline=True)
        if player.current.likes:
            embed.add_field(name="Likes", value=f"{player.current.likes:,}", inline=True)
            
        # Show the current volume
        embed.add_field(name="Volume", value=f"{int(player.volume * 100)}%", inline=True)
        
        # Add queue info
        if player.queue:
            next_song = player.queue[0]
            embed.add_field(
                name="Próxima música / Next song",
                value=f"[{next_song['title']}]({next_song['webpage_url']})", 
                inline=False
            )
            embed.set_footer(text=f"Total na fila / Total in queue: {len(player.queue)} música(s)")
        
        await ctx.send(embed=embed)
    
    @commands.command(name="volume", aliases=["vol"])
    async def change_volume(self, ctx, volume: int = None):
        """
        Mudar o volume da música (0-100)
        Usage: !volume [level]
        """
        if ctx.voice_client is None:
            return await ctx.send("Não estou conectado a um canal de voz.")
        
        player = self.get_player(ctx)
        
        if volume is None:
            return await ctx.send(f"🔊 Volume atual: **{int(player.volume * 100)}%**")
            
        if not 0 <= volume <= 100:
            return await ctx.send("O volume deve estar entre 0 e 100.")
            
        # Set the volume for the player
        player.volume = volume / 100
        
        # Also set it for the current song if one is playing
        if player.current:
            ctx.voice_client.source.volume = volume / 100
            
        await ctx.send(f"🔊 Volume ajustado para: **{volume}%**")
    
    @commands.command(name="stop")
    async def stop(self, ctx):
        """
        Parar a reprodução e limpar a fila
        Usage: !stop
        """
        if ctx.voice_client is None or not ctx.voice_client.is_playing():
            return await ctx.send("Não estou tocando nada no momento.")
            
        player = self.get_player(ctx)
        player.queue.clear()  # Clear the queue
        ctx.voice_client.stop()  # Stop the current song
        
        await ctx.send("⏹️ Reprodução parada e fila limpa.")
    
    @commands.command(name="shuffle")
    async def shuffle(self, ctx):
        """
        Embaralhar a fila de músicas
        Usage: !shuffle
        """
        player = self.get_player(ctx)
        
        if not player.queue:
            return await ctx.send("A fila está vazia.")
            
        random.shuffle(player.queue)
        await ctx.send("🔀 Fila embaralhada.")
    
    @commands.command(name="remove", aliases=["rm"])
    async def remove(self, ctx, position: int = None):
        """
        Remover uma música da fila
        Usage: !remove <posição>
        """
        if position is None:
            return await ctx.send("Você precisa especificar a posição da música na fila.")
            
        player = self.get_player(ctx)
        
        if not player.queue:
            return await ctx.send("A fila está vazia.")
            
        # Adjust for 1-based indexing from user perspective
        position -= 1
        
        if 0 <= position < len(player.queue):
            removed_song = player.queue.pop(position)
            await ctx.send(f"Removido da fila: **{removed_song['title']}**")
        else:
            await ctx.send(f"Posição inválida. A fila tem {len(player.queue)} música(s).")
    
    @commands.command(name="clear")
    async def clear(self, ctx):
        """
        Limpar toda a fila de músicas
        Usage: !clear
        """
        player = self.get_player(ctx)
        
        if not player.queue:
            return await ctx.send("A fila já está vazia.")
            
        # Store number of songs for message
        num_songs = len(player.queue)
        player.queue.clear()
        
        await ctx.send(f"🧹 Fila limpa. {num_songs} música(s) removida(s).")
    
    # Error handlers
    @play.error
    async def play_error(self, ctx, error):
        if isinstance(error, commands.CommandError):
            await ctx.send(f"Erro: {error}")
    
    # Playlist management methods
    def load_playlists(self):
        """Load playlists data from JSON file"""
        try:
            if os.path.exists(self.playlists_file):
                with open(self.playlists_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            logger.error(f"Error loading playlists: {e}")
            return {}
    
    def save_playlists(self):
        """Save playlists data to JSON file"""
        try:
            with open(self.playlists_file, 'w', encoding='utf-8') as f:
                json.dump(self.playlists, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Error saving playlists: {e}")
    
    def add_song_to_history(self, user_id, song_data):
        """Add a song to the user's history"""
        # Convert user_id to string for JSON compatibility
        user_id = str(user_id)
        
        # Initialize user history if needed
        if user_id not in self.user_history:
            self.user_history[user_id] = []
        
        # Add song to history with timestamp
        song_history = {
            'title': song_data.get('title', 'Unknown'),
            'url': song_data.get('webpage_url', ''),
            'id': song_data.get('id', ''),
            'timestamp': datetime.now().isoformat()
        }
        
        # Add to the beginning of the list
        self.user_history[user_id].insert(0, song_history)
        
        # Limit history size
        if len(self.user_history[user_id]) > self.history_limit:
            self.user_history[user_id] = self.user_history[user_id][:self.history_limit]
    
    def get_recommendations(self, user_id, limit=5):
        """Get song recommendations based on user's listening history"""
        user_id = str(user_id)
        
        # Check if user has history
        if user_id not in self.user_history or not self.user_history[user_id]:
            return []
        
        # Get list of song IDs from history
        song_ids = [song['id'] for song in self.user_history[user_id] if song.get('id')]
        
        try:
            # Use last song for recommendations
            if song_ids:
                last_song_id = song_ids[0]
                # Get related videos from YouTube
                video_info = ytdl.extract_info(f"https://www.youtube.com/watch?v={last_song_id}", 
                                              download=False,
                                              process=False)
                
                # Extract recommendations
                recommendations = []
                if video_info and 'related_videos' in video_info:
                    for video in video_info['related_videos'][:limit]:
                        if video['id'] not in song_ids:  # Avoid recommending already heard songs
                            recommendations.append({
                                'title': video.get('title', 'Unknown'),
                                'url': f"https://www.youtube.com/watch?v={video['id']}",
                                'id': video['id']
                            })
                return recommendations
        except Exception as e:
            logger.error(f"Error getting recommendations: {e}")
        
        return []
    
    async def fetch_lyrics(self, song_title):
        """Fetch lyrics for a song"""
        # Remove any text in parentheses or brackets which often contains 
        # info like (Official Video) that hinders lyrics search
        clean_title = re.sub(r'\([^)]*\)|\[[^\]]*\]', '', song_title).strip()
        
        # Remove any featuring artists which can also hinder search
        clean_title = re.sub(r'ft\..*|feat\..*', '', clean_title).strip()
        
        try:
            # Try to get lyrics from the Genius API (public endpoint)
            search_url = f"https://api.genius.com/search?q={clean_title}"
            
            # Try the public API endpoint first
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://some-lyrics-api.herokuapp.com/lyrics?title={clean_title}") as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data and 'lyrics' in data:
                            return data['lyrics']
            
            # If that fails, try a web scraping approach (Genius lyrics page)
            search_url = f"https://genius.com/search?q={clean_title}"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            
            # Regular search first
            response = requests.get(search_url, headers=headers)
            
            if response.status_code == 200:
                # Find the first song result URL
                song_url_match = re.search(r'<a\s+class="mini_card"\s+href="([^"]+)"', response.text)
                
                if song_url_match:
                    song_url = song_url_match.group(1)
                    lyrics_response = requests.get(song_url, headers=headers)
                    
                    if lyrics_response.status_code == 200:
                        # Extract lyrics from the HTML - this is a bit brittle but can work
                        lyrics_match = re.search(r'<div\s+class="lyrics">(.+?)</div>', 
                                                lyrics_response.text, re.DOTALL)
                        
                        if lyrics_match:
                            lyrics = lyrics_match.group(1)
                            # Clean up HTML tags
                            lyrics = re.sub(r'<[^>]+>', '', lyrics)
                            return lyrics.strip()
            
            # Fallback message if lyrics can't be found
            return f"Não foi possível encontrar a letra para '{song_title}'.\nLyrics not found for '{song_title}'."
            
        except Exception as e:
            logger.error(f"Error fetching lyrics: {e}")
            return f"Erro ao buscar letra: {e}\nError fetching lyrics: {e}"
    
    @commands.command(name="playlist", aliases=["pl"])
    async def playlist_command(self, ctx, action=None, playlist_name=None, *, song_url=None):
        """
        Gerenciar playlists de músicas
        Usage: !playlist create/add/remove/play/list/view <nome_playlist> [url_música]
        """
        # Convert user ID to string for JSON compatibility
        user_id = str(ctx.author.id)
        
        # Initialize user playlists if they don't exist
        if user_id not in self.playlists:
            self.playlists[user_id] = {}
        
        if not action or action.lower() not in ["create", "add", "remove", "play", "list", "view", "delete"]:
            embed = discord.Embed(
                title="Comandos de Playlist / Playlist Commands",
                description="Gerenciar suas playlists de música / Manage your music playlists",
                color=discord.Color.blue()
            )
            embed.add_field(
                name="Criar playlist / Create playlist",
                value="!playlist create <nome_playlist>",
                inline=False
            )
            embed.add_field(
                name="Adicionar música / Add song",
                value="!playlist add <nome_playlist> <url_música ou busca>",
                inline=False
            )
            embed.add_field(
                name="Remover música / Remove song",
                value="!playlist remove <nome_playlist> <índice>",
                inline=False
            )
            embed.add_field(
                name="Tocar playlist / Play playlist",
                value="!playlist play <nome_playlist>",
                inline=False
            )
            embed.add_field(
                name="Listar playlists / List playlists",
                value="!playlist list",
                inline=False
            )
            embed.add_field(
                name="Ver músicas da playlist / View playlist",
                value="!playlist view <nome_playlist>",
                inline=False
            )
            embed.add_field(
                name="Excluir playlist / Delete playlist",
                value="!playlist delete <nome_playlist>",
                inline=False
            )
            return await ctx.send(embed=embed)
            
        # Create a new playlist
        if action.lower() == "create":
            if not playlist_name:
                return await ctx.send("Por favor, especifique um nome para a playlist.")
                
            if playlist_name in self.playlists[user_id]:
                return await ctx.send(f"Você já tem uma playlist chamada '{playlist_name}'.")
                
            self.playlists[user_id][playlist_name] = []
            self.save_playlists()
            
            await ctx.send(f"✅ Playlist '{playlist_name}' criada com sucesso.")
            
        # Add a song to a playlist
        elif action.lower() == "add":
            if not playlist_name:
                return await ctx.send("Por favor, especifique o nome da playlist.")
                
            if playlist_name not in self.playlists[user_id]:
                return await ctx.send(f"Você não tem uma playlist chamada '{playlist_name}'.")
                
            if not song_url:
                return await ctx.send("Por favor, forneça um URL ou termo de busca para a música.")
                
            # Send searching message
            search_msg = await ctx.send(f"🔍 Buscando: `{song_url}`")
            
            try:
                # Get song information
                source_data = await YTDLSource.create_source(song_url, loop=self.bot.loop)
                
                # Add song to playlist
                self.playlists[user_id][playlist_name].append({
                    'title': source_data['title'],
                    'url': source_data['webpage_url'],
                    'thumbnail': source_data['thumbnail'],
                    'duration': source_data['duration'],
                    'added_at': datetime.now().isoformat(),
                    'added_by': ctx.author.display_name
                })
                
                self.save_playlists()
                
                await search_msg.delete()
                await ctx.send(f"✅ Adicionado à playlist '{playlist_name}': **{source_data['title']}**")
                
            except Exception as e:
                logger.error(f"Playlist add error: {e}")
                await search_msg.delete()
                await ctx.send(f"❌ Erro ao adicionar música: {e}")
                
        # Remove a song from a playlist
        elif action.lower() == "remove":
            if not playlist_name:
                return await ctx.send("Por favor, especifique o nome da playlist.")
                
            if playlist_name not in self.playlists[user_id]:
                return await ctx.send(f"Você não tem uma playlist chamada '{playlist_name}'.")
                
            if not song_url or not song_url.isdigit():
                return await ctx.send("Por favor, forneça o índice da música a remover.")
                
            index = int(song_url) - 1  # Convert to 0-based index
            
            if index < 0 or index >= len(self.playlists[user_id][playlist_name]):
                return await ctx.send(f"Índice inválido. A playlist tem {len(self.playlists[user_id][playlist_name])} música(s).")
                
            # Remove the song
            removed_song = self.playlists[user_id][playlist_name].pop(index)
            self.save_playlists()
            
            await ctx.send(f"✅ Removido da playlist '{playlist_name}': **{removed_song['title']}**")
            
        # Play a playlist
        elif action.lower() == "play":
            if not playlist_name:
                return await ctx.send("Por favor, especifique o nome da playlist.")
                
            if playlist_name not in self.playlists[user_id]:
                return await ctx.send(f"Você não tem uma playlist chamada '{playlist_name}'.")
                
            if not self.playlists[user_id][playlist_name]:
                return await ctx.send(f"A playlist '{playlist_name}' está vazia.")
                
            # Join voice channel if not already in one
            if ctx.voice_client is None:
                if ctx.author.voice:
                    await ctx.author.voice.channel.connect()
                else:
                    return await ctx.send("Você precisa estar em um canal de voz para usar este comando.")
                    
            # Get player
            player = self.get_player(ctx)
            
            # Add all songs to queue
            added_count = 0
            for song in self.playlists[user_id][playlist_name]:
                try:
                    # Create source information
                    source_data = await YTDLSource.create_source(song['url'], loop=self.bot.loop)
                    
                    # Add requester info
                    source_data['requester'] = ctx.author.mention
                    
                    # Add to queue
                    player.queue.append(source_data)
                    added_count += 1
                    
                except Exception as e:
                    logger.error(f"Error adding song from playlist: {e}")
                    continue
                    
            # Send confirmation
            await ctx.send(f"✅ Adicionado {added_count} música(s) da playlist '{playlist_name}' à fila.")
            
            # If nothing is playing, trigger the next song
            if not ctx.voice_client.is_playing():
                player.next_song.set()
                
        # List all playlists
        elif action.lower() == "list":
            if not self.playlists.get(user_id):
                return await ctx.send("Você não tem nenhuma playlist salva.")
                
            embed = discord.Embed(
                title="Suas Playlists / Your Playlists",
                color=discord.Color.blue()
            )
            
            for playlist_name, songs in self.playlists[user_id].items():
                embed.add_field(
                    name=playlist_name,
                    value=f"{len(songs)} música(s)",
                    inline=True
                )
                
            await ctx.send(embed=embed)
            
        # View a playlist's contents
        elif action.lower() == "view":
            if not playlist_name:
                return await ctx.send("Por favor, especifique o nome da playlist.")
                
            if playlist_name not in self.playlists[user_id]:
                return await ctx.send(f"Você não tem uma playlist chamada '{playlist_name}'.")
                
            if not self.playlists[user_id][playlist_name]:
                return await ctx.send(f"A playlist '{playlist_name}' está vazia.")
                
            embed = discord.Embed(
                title=f"Playlist: {playlist_name}",
                color=discord.Color.blue()
            )
            
            # Add songs to embed (up to 15 songs to avoid hitting embed limits)
            songs_text = ""
            for i, song in enumerate(self.playlists[user_id][playlist_name][:15], start=1):
                duration = YTDLSource.parse_duration(int(song.get('duration', 0)))
                songs_text += f"`{i}.` [{song['title']}]({song['url']}) | `{duration}`\n"
                
            embed.description = songs_text
            
            # If there are more than 15 songs, add a note
            if len(self.playlists[user_id][playlist_name]) > 15:
                embed.set_footer(text=f"Exibindo 15 de {len(self.playlists[user_id][playlist_name])} músicas")
                
            await ctx.send(embed=embed)
            
        # Delete a playlist
        elif action.lower() == "delete":
            if not playlist_name:
                return await ctx.send("Por favor, especifique o nome da playlist.")
                
            if playlist_name not in self.playlists[user_id]:
                return await ctx.send(f"Você não tem uma playlist chamada '{playlist_name}'.")
                
            # Delete the playlist
            del self.playlists[user_id][playlist_name]
            self.save_playlists()
            
            await ctx.send(f"✅ Playlist '{playlist_name}' excluída com sucesso.")
            
    @commands.command(name="lyrics", aliases=["letra"])
    async def lyrics_command(self, ctx, *, song_title=None):
        """
        Mostrar letra da música atual ou da música especificada
        Usage: !lyrics [título da música]
        """
        # Get current playing song if no title is specified
        if not song_title:
            player = self.get_player(ctx)
            
            if not player.current:
                return await ctx.send("Não estou tocando nada no momento. Especifique o título da música.")
                
            song_title = player.current.title
            
        # Send typing indicator as this might take a moment
        async with ctx.typing():
            # Send searching message
            search_msg = await ctx.send(f"🔍 Buscando letra para: `{song_title}`")
            
            # Fetch lyrics
            lyrics = await self.fetch_lyrics(song_title)
            
            await search_msg.delete()
            
            # Check if lyrics are too long for a single message (Discord has a 2000 char limit)
            if len(lyrics) > 1990:
                # Split into multiple messages
                chunks = [lyrics[i:i+1990] for i in range(0, len(lyrics), 1990)]
                
                # Send first message with title
                await ctx.send(f"**Letra da Música / Lyrics: {song_title}**")
                
                # Send each chunk
                for chunk in chunks:
                    await ctx.send(f"```{chunk}```")
            else:
                # Send in a single message
                await ctx.send(f"**Letra da Música / Lyrics: {song_title}**\n```{lyrics}```")
                
    @commands.command(name="history", aliases=["histórico", "historico"])
    async def history_command(self, ctx, user: discord.Member = None):
        """
        Mostrar histórico de músicas tocadas
        Usage: !history [@membro]
        """
        # Default to command author if no user is specified
        target_user = user or ctx.author
        user_id = str(target_user.id)
        
        # Check if user has history
        if user_id not in self.user_history or not self.user_history[user_id]:
            return await ctx.send(f"{target_user.display_name} não tem histórico de músicas.")
            
        # Create embed
        embed = discord.Embed(
            title=f"Histórico de Músicas / Music History - {target_user.display_name}",
            color=discord.Color.blue()
        )
        
        # Add songs to embed (up to 10 most recent)
        history_limit = 10
        songs_text = ""
        for i, song in enumerate(self.user_history[user_id][:history_limit], start=1):
            songs_text += f"`{i}.` [{song['title']}]({song['url']})\n"
            
        embed.description = songs_text
        
        # If there are more than the limit, add a note
        if len(self.user_history[user_id]) > history_limit:
            embed.set_footer(text=f"Exibindo {history_limit} músicas mais recentes de {len(self.user_history[user_id])} no total")
            
        await ctx.send(embed=embed)
        
    @commands.command(name="recommend", aliases=["recomendação", "recomendacao", "rec"])
    async def recommend_command(self, ctx, user: discord.Member = None):
        """
        Receber recomendações de músicas baseadas no histórico
        Usage: !recommend [@membro]
        """
        # Default to command author if no user is specified
        target_user = user or ctx.author
        user_id = str(target_user.id)
        
        # Get recommendations
        recommendations = self.get_recommendations(user_id)
        
        if not recommendations:
            if user_id not in self.user_history or not self.user_history[user_id]:
                return await ctx.send(f"{target_user.display_name} não tem histórico de músicas para gerar recomendações.")
            else:
                return await ctx.send("Não foi possível gerar recomendações neste momento. Tente novamente mais tarde.")
                
        # Create embed
        embed = discord.Embed(
            title=f"Recomendações para {target_user.display_name} / Recommendations",
            description="Baseado no seu histórico de músicas / Based on your listening history",
            color=discord.Color.purple()
        )
        
        # Add songs to embed
        for i, song in enumerate(recommendations, start=1):
            embed.add_field(
                name=f"{i}. {song['title']}",
                value=f"[Link]({song['url']})",
                inline=False
            )
            
        # Add tip for playing recommendations
        embed.set_footer(text="Use !play <url> para tocar uma recomendação / Use !play <url> to play a recommendation")
        
        await ctx.send(embed=embed)
    
    # Update play history with songs for recommendations
    async def update_play_history(self, ctx, source_data):
        """Update play history when a song is played"""
        # Add song to history for the user who requested it
        if isinstance(ctx.author, discord.Member) and source_data:
            try:
                # Add to user history for recommendations
                self.add_song_to_history(ctx.author.id, source_data)
                
                # Log for debugging
                logger.debug(f"Added song to history for user {ctx.author.id}: {source_data.get('title')}")
            except Exception as e:
                logger.error(f"Error updating play history: {e}")
    
    # Check commands that require being in the same voice channel
    async def cog_check(self, ctx):
        # Skip check if not in a voice channel
        if not ctx.voice_client:
            return True
            
        # Check for being in the same voice channel or for DJ role
        if ctx.author.voice and ctx.author.voice.channel == ctx.voice_client.channel:
            return True
            
        # Allow admin override
        if ctx.author.guild_permissions.administrator:
            return True
            
        # Check for DJ role
        dj_role = discord.utils.get(ctx.guild.roles, name="DJ")
        if dj_role and dj_role in ctx.author.roles:
            return True
            
        # Allow for join-only commands
        if ctx.command.name == "join":
            return True
            
        await ctx.send("Você precisa estar no mesmo canal de voz que o bot para usar este comando.")
        return False


async def setup(bot):
    await bot.add_cog(Music(bot))