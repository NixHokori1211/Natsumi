"""
Help command for the Discord bot.
Provides a custom help command that displays all available commands grouped by category.
"""
import discord
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class Help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Remove the default help command
        self.bot.remove_command('help')
    
    @commands.command(name="help")
    async def help(self, ctx, command_name=None):
        """
        Show help information for commands
        Usage: !help [command]
        """
        embed = discord.Embed(
            title="Kimiko Bot - Help",
            description=f"Use `{self.bot.command_prefix}help [command]` for more info on a specific command",
            color=discord.Color.purple(),
            timestamp=ctx.message.created_at
        )
        
        # Add bot avatar if available
        if self.bot.user.avatar:
            embed.set_thumbnail(url=self.bot.user.avatar.url)
        
        if command_name:
            # If a specific command was requested
            command = self.bot.get_command(command_name)
            if command:
                # Format command signature
                signature = command.signature
                if signature:
                    usage = f"{self.bot.command_prefix}{command.name} {signature}"
                else:
                    usage = f"{self.bot.command_prefix}{command.name}"
                
                embed.title = f"Command: {command_name}"
                embed.add_field(name="Usage", value=f"`{usage}`", inline=False)
                
                # Add command description
                if command.help:
                    # Clean up the help text
                    help_text = command.help.strip()
                    help_text = help_text.replace("Usage:", "").strip()
                    embed.add_field(name="Description", value=help_text, inline=False)
                else:
                    embed.add_field(name="Description", value="No description available.", inline=False)
                
                # Add aliases if any
                if command.aliases:
                    aliases = ", ".join([f"`{self.bot.command_prefix}{alias}`" for alias in command.aliases])
                    embed.add_field(name="Aliases", value=aliases, inline=False)
                
                # Add command category (cog)
                if command.cog_name:
                    embed.add_field(name="Category", value=command.cog_name, inline=False)
            else:
                embed.title = "Command Not Found"
                embed.description = f"Command `{command_name}` not found."
                embed.color = discord.Color.red()
                
                # Try to suggest similar commands
                all_commands = [cmd.name for cmd in self.bot.commands]
                close_matches = [cmd for cmd in all_commands if command_name.lower() in cmd.lower()]
                
                if close_matches:
                    suggestions = ", ".join([f"`{self.bot.command_prefix}{cmd}`" for cmd in close_matches])
                    embed.add_field(name="Did you mean one of these?", value=suggestions, inline=False)
        else:
            # Show all commands grouped by category
            cogs_dict = {}
            for command in self.bot.commands:
                cog_name = command.cog_name or "No Category"
                if cog_name not in cogs_dict:
                    cogs_dict[cog_name] = []
                cogs_dict[cog_name].append(command)
            
            # Sort the cog names for consistent output
            sorted_cogs = sorted(cogs_dict.keys())
            
            # Add description for each category
            category_descriptions = {
                "Admin": "Server management commands (admin only)",
                "Fun": "Fun and entertainment commands",
                "Moderation": "Server moderation tools",
                "Utils": "Utility commands for information",
                "Language": "Language and translation features",
                "Welcome": "Welcome message configuration",
                "RichPresence": "Bot status configuration",
                "Music": "Music player commands",
                "Help": "Help commands",
                "No Category": "Miscellaneous commands"
            }
            
            # Add fields for each category
            for cog_name in sorted_cogs:
                # Skip showing the command if it's an internal one (starting with underscore)
                commands_list = [cmd for cmd in cogs_dict[cog_name] if not cmd.name.startswith('_')]
                
                if commands_list:
                    # Sort commands by name for consistent output
                    commands_list.sort(key=lambda x: x.name)
                    
                    # Format command list
                    commands_str = ", ".join(f"`{self.bot.command_prefix}{cmd.name}`" for cmd in commands_list)
                    
                    # Add category description if available
                    if cog_name in category_descriptions:
                        field_name = f"{cog_name} - {category_descriptions[cog_name]}"
                    else:
                        field_name = cog_name
                    
                    embed.add_field(name=field_name, value=commands_str, inline=False)
            
            # Add footer with total command count
            total_commands = sum(len(cmds) for cmds in cogs_dict.values())
            embed.set_footer(text=f"Total commands: {total_commands} • Bot by Chwrmoon")
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Help(bot))