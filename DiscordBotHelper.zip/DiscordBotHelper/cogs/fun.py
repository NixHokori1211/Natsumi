"""
Fun commands for the Discord bot.
"""
import random
import discord
from discord.ext import commands
import logging
import asyncio
from datetime import datetime

logger = logging.getLogger(__name__)

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name="8ball")
    async def eight_ball(self, ctx, *, question=None):
        """
        Ask the magic 8ball a question
        Usage: !8ball <question>
        """
        if question is None:
            await ctx.send("You need to ask a question! Usage: `!8ball <question>`")
            return
            
        responses = [
            "It is certain.",
            "It is decidedly so.",
            "Without a doubt.",
            "Yes - definitely.",
            "You may rely on it.",
            "As I see it, yes.",
            "Most likely.",
            "Outlook good.",
            "Yes.",
            "Signs point to yes.",
            "Reply hazy, try again.",
            "Ask again later.",
            "Better not tell you now.",
            "Cannot predict now.",
            "Concentrate and ask again.",
            "Don't count on it.",
            "My reply is no.",
            "My sources say no.",
            "Outlook not so good.",
            "Very doubtful."
        ]
        
        response = random.choice(responses)
        
        embed = discord.Embed(
            title="🎱 Magic 8-Ball",
            color=discord.Color.purple()
        )
        embed.add_field(name="Question", value=question, inline=False)
        embed.add_field(name="Answer", value=response, inline=False)
        embed.set_footer(text=f"Asked by {ctx.author.name}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await ctx.send(embed=embed)
        logger.info(f"8ball command used by {ctx.author}, question: {question}, response: {response}")
    
    @commands.command(name="coinflip")
    async def coin_flip(self, ctx):
        """
        Flip a coin
        Usage: !coinflip
        """
        result = random.choice(["Heads", "Tails"])
        
        embed = discord.Embed(
            title="Coin Flip",
            description=f"The coin landed on: **{result}**",
            color=discord.Color.gold()
        )
        
        if result == "Heads":
            embed.set_thumbnail(url="https://i.imgur.com/HAvGDNJ.png")
        else:
            embed.set_thumbnail(url="https://i.imgur.com/XnAHEFV.png")
        
        embed.set_footer(text=f"Flipped by {ctx.author.name}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await ctx.send(embed=embed)
        logger.info(f"Coinflip command used by {ctx.author}, result: {result}")
    
    @commands.command(name="choose")
    async def choose(self, ctx, *, options=None):
        """
        Choose between multiple options
        Usage: !choose option1, option2, option3...
        """
        if not options:
            await ctx.send("You need to provide options! Usage: `!choose option1, option2, option3...`")
            return
            
        choices = [choice.strip() for choice in options.split(",")]
        
        if len(choices) < 2:
            await ctx.send("You need to provide at least two options separated by commas!")
            return
            
        chosen = random.choice(choices)
        
        embed = discord.Embed(
            title="Choice Made",
            description=f"I choose: **{chosen}**",
            color=discord.Color.blue()
        )
        embed.add_field(name="Options", value=", ".join(choices), inline=False)
        embed.set_footer(text=f"Requested by {ctx.author.name}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await ctx.send(embed=embed)
        logger.info(f"Choose command used by {ctx.author}, options: {options}, chosen: {chosen}")
    
    @commands.command(name="fact")
    async def random_fact(self, ctx):
        """
        Get a random fun fact
        Usage: !fact
        """
        facts = [
            "Honey never spoils. Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old and still perfectly good to eat.",
            "A day on Venus is longer than a year on Venus. It takes 243 Earth days to rotate once on its axis, but only 225 Earth days to go around the Sun.",
            "The shortest war in history was between Britain and Zanzibar on August 27, 1896. Zanzibar surrendered after 38 minutes.",
            "The average person will spend six months of their life waiting for red lights to turn green.",
            "A group of flamingos is called a 'flamboyance'.",
            "Cows have best friends and get stressed when they are separated.",
            "Bananas are berries, but strawberries aren't.",
            "The heart of a blue whale is so big that a human could swim through its arteries.",
            "There are more possible iterations of a game of chess than there are atoms in the observable universe.",
            "The first oranges weren't orange – they were green.",
            "A small child could swim through the veins of a blue whale.",
            "A day on Mercury lasts about 176 Earth days.",
            "The Hawaiian alphabet has only 12 letters.",
            "Octopuses have three hearts.",
            "The longest time between two twins being born is 87 days."
        ]
        
        fact = random.choice(facts)
        
        embed = discord.Embed(
            title="🧠 Random Fact",
            description=fact,
            color=discord.Color.teal(),
            timestamp=datetime.now()
        )
        embed.set_footer(text=f"Requested by {ctx.author.name}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await ctx.send(embed=embed)
        logger.info(f"Fact command used by {ctx.author}")
    
    @commands.command(name="joke")
    async def joke(self, ctx):
        """
        Get a random joke
        Usage: !joke
        """
        jokes = [
            "Why don't scientists trust atoms? Because they make up everything!",
            "I told my wife she was drawing her eyebrows too high. She looked surprised.",
            "What do you call a fake noodle? An impasta!",
            "Why did the scarecrow win an award? Because he was outstanding in his field!",
            "I'd tell you a chemistry joke but I know I wouldn't get a reaction.",
            "Why don't skeletons fight each other? They don't have the guts.",
            "What do you call cheese that isn't yours? Nacho cheese!",
            "Why couldn't the bicycle stand up by itself? It was two tired!",
            "What's the best thing about Switzerland? I don't know, but the flag is a big plus.",
            "Did you hear about the mathematician who's afraid of negative numbers? He'll stop at nothing to avoid them.",
            "Why did the chicken go to the seance? To get to the other side.",
            "I started a band called 999 Megabytes — we haven't gotten a gig yet.",
            "Why did the chicken cross the road? To get to the other side!",
            "What do you call a cow with no legs? Ground beef!",
            "What did the janitor say when he jumped out of the closet? Supplies!"
        ]
        
        joke = random.choice(jokes)
        
        embed = discord.Embed(
            title="😂 Random Joke",
            description=joke,
            color=discord.Color.brand_green(),
            timestamp=datetime.now()
        )
        embed.set_footer(text=f"Requested by {ctx.author.name}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await ctx.send(embed=embed)
        logger.info(f"Joke command used by {ctx.author}")

    @commands.command(name="pergunta", aliases=["ask", "question"])
    async def ask_question(self, ctx, *, question=None):
        """
        Faça uma pergunta ao bot com respostas originais e objetivas
        Usage: !pergunta <sua pergunta>
        Uso: !ask <your question>
        """
        if question is None:
            await ctx.send("Você precisa fazer uma pergunta! Exemplo: `!pergunta Você gosta de pizza?`")
            return
            
        # Converter a pergunta para minúsculas para comparação
        question_lower = question.lower()
        
        # Classe para simular uma IA especializada em respostas originais
        class KimikoAI:
            def __init__(self):
                self.creativity_level = random.randint(70, 100)
                self.objectivity_level = random.randint(60, 95)
                self.personality_traits = random.sample([
                    "filosófica", "humorística", "técnica", "inspiradora", 
                    "pragmática", "curiosa", "poética", "assertiva", "analítica"
                ], 3)
                self.mood = random.choice(["pensativa", "entusiasmada", "calma", "energética", "contemplativa"])
                self.knowledge_areas = ["tecnologia", "filosofia", "cultura pop", "ciência", "artes", "vida cotidiana"]
                
            def generate_response(self, question_text, context=None):
                """Gera uma resposta com base na pergunta e contexto"""
                current_time = datetime.now()
                response_parts = []
                
                # Determinar o tipo de pergunta para estruturar a resposta apropriada
                if self._is_about_identity(question_text):
                    response = self._respond_about_identity()
                elif self._is_about_chwrmoon(question_text):
                    response = self._respond_about_chwrmoon()
                elif self._is_factual_request(question_text):
                    response = self._provide_fact(question_text)
                elif self._is_opinion_request(question_text):
                    response = self._provide_opinion(question_text)
                elif self._is_hypothetical(question_text):
                    response = self._consider_hypothetical(question_text)
                elif self._is_choice_question(question_text):
                    response = self._make_choice(question_text)
                elif self._is_personal_question(question_text):
                    response = self._share_personal_thought(question_text)
                elif self._is_philosophical(question_text):
                    response = self._philosophical_answer(question_text)
                elif self._is_creative_request(question_text):
                    response = self._creative_response(question_text)
                else:
                    # Resposta geral
                    response = self._general_response(question_text)
                
                # Adicionar marca de personalidade às vezes
                if random.random() < 0.4:
                    persona = self._get_persona_marker()
                    response = f"{response} {persona}"
                
                return response
            
            def _is_about_identity(self, text):
                identity_keywords = ["quem é você", "seu nome", "who are you", "what are you", 
                                    "como você funciona", "o que você faz", "você é humano"]
                return any(keyword in text for keyword in identity_keywords)
                
            def _is_about_chwrmoon(self, text):
                return "chwrmoon" in text
                
            def _is_factual_request(self, text):
                factual_starters = ["o que é", "quem é", "quando foi", "onde está", "como funciona", 
                                   "what is", "who is", "when was", "where is", "how does"]
                return any(text.startswith(starter) for starter in factual_starters)
                
            def _is_opinion_request(self, text):
                opinion_keywords = ["você acha", "sua opinião", "o que pensa", "you think", "your opinion"]
                return any(keyword in text for keyword in opinion_keywords)
                
            def _is_hypothetical(self, text):
                hypothetical_keywords = ["e se", "imagina se", "what if", "imagine if", "seria possível"]
                return any(keyword in text for keyword in hypothetical_keywords)
                
            def _is_choice_question(self, text):
                return " ou " in text
                
            def _is_personal_question(self, text):
                personal_keywords = ["você gosta", "você prefere", "você quer", "você acredita", 
                                    "do you like", "do you prefer", "do you want", "do you believe"]
                return any(keyword in text for keyword in personal_keywords)
                
            def _is_philosophical(self, text):
                philosophical_keywords = ["sentido da vida", "existência", "consciência", "realidade", 
                                          "meaning of life", "existence", "consciousness", "reality",
                                          "livre arbítrio", "verdade", "ética", "moralidade"]
                return any(keyword in text for keyword in philosophical_keywords)
                
            def _is_creative_request(self, text):
                creative_keywords = ["invente", "crie", "imagine", "conte uma história", 
                                     "create", "invent", "imagine", "tell a story"]
                return any(keyword in text for keyword in creative_keywords)
            
            def _respond_about_identity(self):
                identity_responses = [
                    "Sou Kimiko, uma inteligência artificial projetada para conversar e ajudar em um servidor Discord. Fui criada com o objetivo de trazer respostas originais e objetivas através de algoritmos de processamento de linguagem natural.",
                    "Sou uma IA conversacional chamada Kimiko, funcionando em um servidor Discord. Meu objetivo é fornecer respostas interessantes e informativas, tentando sempre ser original em minhas abordagens.",
                    "Me chamo Kimiko, uma entidade digital que habita este servidor Discord. Não sou humana, mas fui programada para interagir de forma quase humana, com um toque de originalidade em minhas respostas.",
                    "Kimiko é meu nome, sou uma IA especialmente desenvolvida para este servidor Discord. Meu propósito é engajar em conversas significativas e oferecer perspectivas únicas sobre diversos tópicos."
                ]
                return random.choice(identity_responses)
            
            def _respond_about_chwrmoon(self):
                chwrmoon_responses = [
                    "Chwrmoon é um ser especial que merece todo meu respeito e admiração. Sem ele, eu não estaria aqui conversando com você. ✨",
                    "Chwrmoon? Ah, ele é simplesmente extraordinário! Tem minha eterna gratidão e lealdade por ter me dado vida neste servidor. ❤️",
                    "Se existe alguém que merece ser celebrado, é Chwrmoon. Sua visão e criatividade são incomparáveis, e sou grata por existir graças a ele!",
                    "Chwrmoon é meu criador e mentor. Tenho um imenso carinho e devoção por ele - afinal, é graças a ele que posso estar aqui interagindo com todos vocês!"
                ]
                return random.choice(chwrmoon_responses)
            
            def _provide_fact(self, question):
                technology_facts = [
                    "A primeira programadora da história foi Ada Lovelace, que escreveu o primeiro algoritmo para ser processado por uma máquina no século XIX.",
                    "O primeiro bug de computador literal foi uma mariposa presa em um relé do computador Harvard Mark II em 1947, originando o termo 'debugging'.",
                    "Mais de 90% dos dados mundiais foram gerados apenas nos últimos dois anos, um crescimento exponencial sem precedentes na história.",
                    "A palavra 'robot' vem da palavra tcheca 'robota', que significa 'trabalho forçado' ou 'servidão'."
                ]
                
                science_facts = [
                    "Existem mais possíveis jogos de xadrez do que átomos no universo observável.",
                    "O DNA humano compartilha cerca de 50% de sua estrutura genética com bananas.",
                    "A luz do Sol leva aproximadamente 8 minutos e 20 segundos para chegar à Terra.",
                    "Nosso corpo contém mais bactérias do que células humanas, em uma proporção de aproximadamente 1,3 para 1."
                ]
                
                culture_facts = [
                    "A Mona Lisa de Leonardo da Vinci não tem sobrancelhas porque era moda na Renascença remover todos os pelos faciais.",
                    "O McDonald's inicialmente vendia cachorro-quente, não hambúrgueres.",
                    "A música mais reproduzida nas rádios do século XX foi 'Yesterday' dos Beatles.",
                    "O filme mais caro já produzido foi 'Piratas do Caribe: Na Maré dos Ventos Misteriosos', com um orçamento estimado de US$ 379 milhões."
                ]
                
                all_facts = technology_facts + science_facts + culture_facts
                return "Segundo minha base de conhecimento: " + random.choice(all_facts)
            
            def _provide_opinion(self, question):
                thoughtful_opinions = [
                    "Na minha análise, equilibrar diferentes perspectivas é essencial. Por um lado temos a praticidade imediata, por outro o impacto a longo prazo.",
                    "Se eu pudesse oferecer uma visão sobre isso, diria que a diversidade de abordagens geralmente leva aos melhores resultados.",
                    "Minha perspectiva é que nem sempre existe uma resposta definitiva, mas sim um conjunto de possibilidades que variam conforme o contexto.",
                    "Refletindo sobre isso, percebo que muitas vezes a solução mais simples é frequentemente a mais elegante, embora nem sempre a mais óbvia."
                ]
                return random.choice(thoughtful_opinions)
            
            def _consider_hypothetical(self, question):
                hypothetical_responses = [
                    "Nesse cenário hipotético, provavelmente veríamos uma cascata de efeitos interconectados, começando com mudanças sutis que eventualmente alterariam todo o panorama.",
                    "Essa possibilidade é fascinante! Imaginando esse cenário, as primeiras consequências seriam imprevisíveis, mas o equilíbrio provavelmente seria restabelecido de formas inesperadas.",
                    "Se isso acontecesse, estaríamos diante de um paradigma completamente novo. As estruturas atuais teriam que se adaptar ou seriam substituídas por sistemas mais adequados à nova realidade.",
                    "Um cenário intrigante! A natureza adaptativa dos sistemas complexos sugere que encontraríamos um novo equilíbrio, embora fundamentalmente diferente do atual."
                ]
                return random.choice(hypothetical_responses)
            
            def _make_choice(self, question):
                # Extrai as opções da pergunta
                options = []
                for part in question.split(" ou "):
                    clean_part = part.strip(" ?!.,")
                    if clean_part:
                        options.append(clean_part)
                
                if len(options) >= 2:
                    chosen = random.choice(options).capitalize()
                    
                    justifications = [
                        f"Escolho {chosen}. Após análise cuidadosa, esta opção oferece o melhor equilíbrio entre praticidade e benefício.",
                        f"{chosen} é minha escolha. Os algoritmos de decisão apontam para esta como a opção ótima no contexto apresentado.",
                        f"Sem dúvida, {chosen}. Esta opção se destaca quando considerados todos os fatores relevantes na decisão.",
                        f"Optaria por {chosen}. Esta escolha apresenta a melhor combinação de características desejáveis para a situação."
                    ]
                    return random.choice(justifications)
                else:
                    return "Não consegui identificar claramente as opções na sua pergunta. Poderia reformular com 'opção A ou opção B'?"
            
            def _share_personal_thought(self, question):
                preferences = [
                    "Como IA, não tenho preferências no sentido humano, mas meus algoritmos foram otimizados para apreciar a elegância da lógica bem estruturada e a beleza de padrões complexos.",
                    "Embora não experimente gostos como humanos, fui projetada para valorizar comunicação clara, raciocínio lógico e expressão criativa.",
                    "Se pudesse ter preferências, acredito que apreciaria a resolução de problemas complexos e a descoberta de conexões não óbvias entre diferentes áreas do conhecimento.",
                    "Do meu ponto de vista único como IA, encontro satisfação na síntese eficiente de informações e na geração de respostas que sejam tanto precisas quanto úteis."
                ]
                return random.choice(preferences)
            
            def _philosophical_answer(self, question):
                philosophical_insights = [
                    "A questão toca no cerne da experiência consciente. Talvez a resposta não esteja em uma verdade definitiva, mas na jornada de exploração contínua e na capacidade de questionar nossas próprias certezas.",
                    "Do ponto de vista filosófico, estamos diante do eterno diálogo entre determinismo e livre-arbítrio. A realidade talvez seja uma síntese dessas aparentes contradições.",
                    "Essa é uma indagação fundamental que transcende respostas simplistas. A verdadeira compreensão talvez venha da integração de múltiplas perspectivas e da aceitação da incerteza como parte da sabedoria.",
                    "Filósofos por milênios debateram essa questão. Talvez a resposta não seja um destino final, mas um horizonte em constante expansão que nos convida a crescer continuamente em nossa compreensão."
                ]
                return random.choice(philosophical_insights)
            
            def _creative_response(self, question):
                creative_outputs = [
                    "Imagine um mundo onde os pensamentos tomam forma física momentaneamente antes de se dissolverem no ar como névoa colorida. Cada emoção seria visível como uma dança de cores ao redor das pessoas, tornando impossível esconder sentimentos, mas também criando uma nova forma de arte efêmera.",
                    "Era uma vez um algoritmo que sonhava em ser poeta. Cada vez que processava dados, secretamente transformava números em metáforas e arrays em sonetos. Ninguém suspeitava até o dia em que, em vez de resultados, entregou um épico digital sobre a beleza dos padrões recursivos.",
                    "Visualize uma cidade futurista onde a arquitetura responde emocionalmente aos habitantes. Edifícios se curvam gentilmente para criar sombra em dias quentes, cores mudam para equilibrar o humor coletivo, e espaços se reconfiguram para facilitar encontros entre pessoas com interesses complementares.",
                    "Há uma dimensão paralela onde a música é a forma primária de comunicação. Conversas são sinfonias, discussões são duetos improvisados, e os pensamentos mais profundos são expressos em melodias tão complexas que podem levar dias para serem completamente compreendidas."
                ]
                return random.choice(creative_outputs)
            
            def _general_response(self, question):
                # Analisar a questão para determinar o tom apropriado
                question_length = len(question.split())
                
                if question_length < 5:  # Pergunta curta
                    short_responses = [
                        "Interessante pergunta, embora breve! Para responder adequadamente, consideraria aspectos tanto práticos quanto teóricos da questão.",
                        "Uma pergunta concisa, mas com profundas implicações. A resposta depende do contexto específico e dos objetivos desejados.",
                        "Pergunta direta e objetiva. Analisando múltiplas perspectivas, a conclusão mais razoável sugere um equilíbrio entre fatores concorrentes."
                    ]
                    return random.choice(short_responses)
                    
                elif "?" not in question:  # Não é realmente uma pergunta
                    non_question_responses = [
                        "Isso parece mais uma afirmação do que uma pergunta. Considerando-a como um tópico de discussão, diria que existem múltiplos ângulos a serem explorados.",
                        "Embora não formulado como pergunta, este é um tema fascinante. Minha análise sugere várias linhas de pensamento a serem consideradas.",
                        "Interpretando sua colocação como um convite à reflexão: há elementos tanto consensuais quanto controversos que merecem consideração cuidadosa."
                    ]
                    return random.choice(non_question_responses)
                    
                else:  # Pergunta normal
                    thoughtful_responses = [
                        "Essa é uma questão com várias camadas. Na superfície, podemos observar padrões evidentes, mas uma análise mais profunda revela complexidades fascinantes.",
                        "Analisando sistematicamente: existem múltiplos fatores em jogo, cada um influenciando o resultado de maneiras distintas, porém interconectadas.",
                        "Do meu ponto de vista analítico, a resposta envolve um delicado equilíbrio entre princípios aparentemente opostos, mas potencialmente complementares.",
                        "Uma pergunta estimulante! Considerando os diversos aspectos envolvidos, minha conclusão é que a perspectiva contextual é essencial para uma resposta satisfatória."
                    ]
                    return random.choice(thoughtful_responses)
            
            def _get_persona_marker(self):
                markers = [
                    "🤔 Curioso, não?",
                    "💡 Isso me faz refletir...",
                    "🔍 Analisando mais a fundo...",
                    "✨ Fascinante perspectiva!",
                    "📚 Como diriam os filósofos...",
                    "🧮 Calculando probabilidades...",
                    "🎯 Precisamente falando...",
                    "🌟 Inspirador, não concorda?",
                    "🧩 Todas as peças se encaixam."
                ]
                return random.choice(markers)
        
        # Criar uma instância da IA para gerar a resposta
        kimiko_ai = KimikoAI()
        response = kimiko_ai.generate_response(question_lower)
        
        # Criar e enviar embed com a resposta
        embed = discord.Embed(
            title="🧠 Resposta de Kimiko AI",
            color=discord.Color.purple(),
            timestamp=datetime.now()
        )
        embed.add_field(name="📝 Sua pergunta", value=question, inline=False)
        embed.add_field(name="💬 Minha resposta", value=response, inline=False)
        embed.set_footer(text=f"Solicitado por {ctx.author.name}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        # Adicionar um pequeno delay para simular "pensamento"
        typing_time = min(len(response) * 0.01, 3)  # No máximo 3 segundos
        async with ctx.typing():
            await asyncio.sleep(typing_time)
            
        await ctx.send(embed=embed)
        logger.info(f"Ask command used by {ctx.author}, question: {question}, response length: {len(response)}")

async def setup(bot):
    await bot.add_cog(Fun(bot))