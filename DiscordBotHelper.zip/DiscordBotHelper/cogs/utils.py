"""
Utility commands for the Discord bot.
"""
import time
import random
import discord
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class Utils(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name="ping")
    async def ping(self, ctx):
        """
        Check the bot's latency
        Usage: !ping
        """
        start_time = time.time()
        message = await ctx.send("Pinging...")
        end_time = time.time()
        
        api_latency = round(self.bot.latency * 1000)
        response_time = round((end_time - start_time) * 1000)
        
        embed = discord.Embed(title="Pong! 🏓", color=discord.Color.green())
        embed.add_field(name="API Latency", value=f"{api_latency}ms", inline=True)
        embed.add_field(name="Response Time", value=f"{response_time}ms", inline=True)
        
        await message.edit(content=None, embed=embed)
        logger.info(f"Ping command used by {ctx.author}, latency: {api_latency}ms")
    
    @commands.command(name="serverinfo")
    async def server_info(self, ctx):
        """
        Display information about the server
        Usage: !serverinfo
        """
        if not ctx.guild:
            await ctx.send("This command can only be used in a server.")
            return
        
        guild = ctx.guild
        
        # Count channels by type
        text_channel_count = len(guild.text_channels)
        voice_channel_count = len(guild.voice_channels)
        category_count = len(guild.categories)
        
        # Count members by status
        member_count = guild.member_count
        online_members = sum(1 for member in guild.members if member.status != discord.Status.offline)
        
        # Server creation date
        created_at = guild.created_at.strftime("%B %d, %Y")
        
        embed = discord.Embed(
            title=f"{guild.name} Server Information",
            description=guild.description or "No description",
            color=discord.Color.blue()
        )
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        embed.add_field(name="Owner", value=guild.owner.mention, inline=True)
        embed.add_field(name="Created On", value=created_at, inline=True)
        embed.add_field(name="Server ID", value=guild.id, inline=True)
        
        embed.add_field(name="Members", value=f"{member_count} total\n{online_members} online", inline=True)
        embed.add_field(name="Channels", 
                       value=f"{text_channel_count} text\n{voice_channel_count} voice\n{category_count} categories", 
                       inline=True)
        embed.add_field(name="Roles", value=len(guild.roles), inline=True)
        
        embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await ctx.send(embed=embed)
        logger.info(f"Server info command used by {ctx.author} in {guild.name}")
    
    @commands.command(name="roll")
    async def roll_dice(self, ctx, dice: str = "1d6"):
        """
        Roll dice in NdN format
        Usage: !roll [NdN] - default is 1d6
        Example: !roll 2d20
        """
        try:
            rolls, limit = map(int, dice.split('d'))
        except ValueError:
            await ctx.send("Format has to be in NdN (e.g. 1d6, 2d20)")
            return
        
        if rolls > 25:
            await ctx.send("You can roll a maximum of 25 dice at once.")
            return
        
        if limit > 1000:
            await ctx.send("The maximum number of sides per die is 1000.")
            return
        
        results = [random.randint(1, limit) for _ in range(rolls)]
        total = sum(results)
        
        result_str = ", ".join(str(r) for r in results)
        
        embed = discord.Embed(
            title="🎲 Dice Roll",
            description=f"Rolling {dice}...",
            color=discord.Color.gold()
        )
        embed.add_field(name="Results", value=result_str, inline=False)
        
        if len(results) > 1:
            embed.add_field(name="Total", value=str(total), inline=False)
        
        await ctx.send(embed=embed)
        logger.info(f"Roll command used by {ctx.author}, rolled {dice}, got {results}")

    @commands.command(name="userinfo")
    async def user_info(self, ctx, member: discord.Member = None):
        """
        Display information about a user
        Usage: !userinfo [member] - if no member is provided, shows your own info
        """
        member = member or ctx.author
        
        roles = [role.mention for role in member.roles if role.name != "@everyone"]
        
        embed = discord.Embed(
            title=f"User Information - {member.name}",
            color=member.color
        )
        
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        
        embed.add_field(name="Username", value=member.name, inline=True)
        embed.add_field(name="Discriminator", value=f"#{member.discriminator}", inline=True)
        embed.add_field(name="ID", value=member.id, inline=True)
        
        embed.add_field(name="Account Created", value=member.created_at.strftime("%B %d, %Y"), inline=True)
        embed.add_field(name="Joined Server", value=member.joined_at.strftime("%B %d, %Y"), inline=True)
        embed.add_field(name="Bot", value="Yes" if member.bot else "No", inline=True)
        
        embed.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles) or "None", inline=False)
        
        await ctx.send(embed=embed)
        logger.info(f"User info command used by {ctx.author}, target: {member.name}")

async def setup(bot):
    await bot.add_cog(Utils(bot))
