"""
Webhook e integrações com APIs externas para o Discord bot.
Permite configurar notificações automáticas de serviços externos.
"""
import json
import logging
import asyncio
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

import discord
from discord.ext import commands, tasks
import aiohttp

logger = logging.getLogger(__name__)

class WebhookManager:
    """Gerencia webhooks e conexões com APIs externas"""
    
    def __init__(self, bot):
        self.bot = bot
        self.webhooks_file = "webhook_config.json"
        self.webhook_data = self._load_webhook_data()
        self.webhook_cache = {}
        
    def _load_webhook_data(self) -> Dict:
        """Carrega configurações dos webhooks do arquivo JSON"""
        try:
            if os.path.exists(self.webhooks_file):
                with open(self.webhooks_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            else:
                return {
                    "github": {},
                    "youtube": {},
                    "twitch": {},
                    "twitter": {},
                    "reddit": {},
                    "weather": {},
                    "news": {},
                    "custom": {}
                }
        except Exception as e:
            logger.error(f"Erro ao carregar configurações de webhooks: {e}")
            return {
                "github": {},
                "youtube": {},
                "twitch": {},
                "twitter": {},
                "reddit": {},
                "weather": {},
                "news": {},
                "custom": {}
            }
    
    def _save_webhook_data(self):
        """Salva configurações dos webhooks em arquivo JSON"""
        try:
            with open(self.webhooks_file, "w", encoding="utf-8") as f:
                json.dump(self.webhook_data, f, indent=4)
        except Exception as e:
            logger.error(f"Erro ao salvar configurações de webhooks: {e}")
    
    async def get_webhook(self, channel_id: int) -> Optional[discord.Webhook]:
        """Obtém ou cria um webhook para um canal específico"""
        if channel_id in self.webhook_cache:
            return self.webhook_cache[channel_id]
        
        channel = self.bot.get_channel(channel_id)
        if not channel:
            try:
                channel = await self.bot.fetch_channel(channel_id)
            except discord.NotFound:
                logger.error(f"Canal {channel_id} não encontrado")
                return None
            except Exception as e:
                logger.error(f"Erro ao obter canal {channel_id}: {e}")
                return None
        
        if not isinstance(channel, discord.TextChannel):
            logger.error(f"Canal {channel_id} não é um canal de texto")
            return None
        
        # Verifica se o bot tem permissão para gerenciar webhooks
        permissions = channel.permissions_for(channel.guild.me)
        if not permissions.manage_webhooks:
            logger.error(f"Sem permissão para gerenciar webhooks no canal {channel.name}")
            return None
        
        # Procura por webhooks existentes criados pelo bot
        try:
            webhooks = await channel.webhooks()
            bot_webhooks = [w for w in webhooks if w.user == self.bot.user]
            
            if bot_webhooks:
                webhook = bot_webhooks[0]
            else:
                webhook_name = f"{self.bot.user.name} Notifications"
                webhook = await channel.create_webhook(name=webhook_name)
            
            self.webhook_cache[channel_id] = webhook
            return webhook
        except Exception as e:
            logger.error(f"Erro ao criar/obter webhook: {e}")
            return None
    
    async def send_webhook_message(self, 
                                  channel_id: int, 
                                  content: str = None, 
                                  embed: discord.Embed = None,
                                  username: str = None,
                                  avatar_url: str = None) -> bool:
        """Envia uma mensagem via webhook"""
        webhook = await self.get_webhook(channel_id)
        if not webhook:
            return False
        
        try:
            await webhook.send(
                content=content,
                embed=embed,
                username=username or webhook.name,
                avatar_url=avatar_url
            )
            return True
        except Exception as e:
            logger.error(f"Erro ao enviar mensagem via webhook: {e}")
            return False
    
    async def add_github_webhook(self, guild_id: int, channel_id: int, repository: str):
        """Adiciona monitoramento para um repositório GitHub"""
        if str(guild_id) not in self.webhook_data["github"]:
            self.webhook_data["github"][str(guild_id)] = {}
        
        self.webhook_data["github"][str(guild_id)][repository] = channel_id
        self._save_webhook_data()
    
    async def add_youtube_webhook(self, guild_id: int, channel_id: int, youtube_channel_id: str):
        """Adiciona monitoramento para um canal do YouTube"""
        if str(guild_id) not in self.webhook_data["youtube"]:
            self.webhook_data["youtube"][str(guild_id)] = {}
        
        self.webhook_data["youtube"][str(guild_id)][youtube_channel_id] = channel_id
        self._save_webhook_data()
    
    async def add_weather_webhook(self, guild_id: int, channel_id: int, location: str, frequency: str = "daily"):
        """Adiciona monitoramento de clima para uma localização"""
        if str(guild_id) not in self.webhook_data["weather"]:
            self.webhook_data["weather"][str(guild_id)] = {}
        
        self.webhook_data["weather"][str(guild_id)][location] = {
            "channel_id": channel_id,
            "frequency": frequency  # daily, morning, evening, etc.
        }
        self._save_webhook_data()
    
    async def add_news_webhook(self, guild_id: int, channel_id: int, topic: str):
        """Adiciona monitoramento de notícias para um tópico"""
        if str(guild_id) not in self.webhook_data["news"]:
            self.webhook_data["news"][str(guild_id)] = {}
        
        self.webhook_data["news"][str(guild_id)][topic] = channel_id
        self._save_webhook_data()
    
    async def add_custom_webhook(self, guild_id: int, channel_id: int, name: str, url: str, headers: Dict = None):
        """Adiciona uma configuração personalizada de webhook"""
        if str(guild_id) not in self.webhook_data["custom"]:
            self.webhook_data["custom"][str(guild_id)] = {}
        
        self.webhook_data["custom"][str(guild_id)][name] = {
            "channel_id": channel_id,
            "url": url,
            "headers": headers or {}
        }
        self._save_webhook_data()
    
    async def remove_webhook(self, guild_id: int, service: str, identifier: str) -> bool:
        """Remove uma configuração de webhook"""
        if service not in self.webhook_data or str(guild_id) not in self.webhook_data[service]:
            return False
        
        if identifier in self.webhook_data[service][str(guild_id)]:
            del self.webhook_data[service][str(guild_id)][identifier]
            self._save_webhook_data()
            return True
        return False


class WebhookIntegrations(commands.Cog):
    """Comandos para gerenciar integrações com APIs externas via webhooks"""
    
    def __init__(self, bot):
        self.bot = bot
        self.webhook_manager = WebhookManager(bot)
        self.session = None
        self.last_check = {}
        self.check_apis.start()
    
    def cog_unload(self):
        """Limpa recursos quando o cog é descarregado"""
        self.check_apis.cancel()
        if self.session and not self.session.closed:
            asyncio.create_task(self.session.close())
    
    async def cog_load(self):
        """Inicializa recursos quando o cog é carregado"""
        self.session = aiohttp.ClientSession()
        
    @tasks.loop(minutes=10)
    async def check_apis(self):
        """Verifica periodicamente as APIs para novas atualizações"""
        await self._check_github_repos()
        await self._check_youtube_channels()
        await self._check_weather_updates()
        await self._check_news_updates()
    
    @check_apis.before_loop
    async def before_check_apis(self):
        """Espera o bot estar pronto antes de iniciar o loop"""
        await self.bot.wait_until_ready()
    
    async def _check_github_repos(self):
        """Verifica atualizações nos repositórios GitHub"""
        for guild_id, repos in self.webhook_manager.webhook_data["github"].items():
            for repo, channel_id in repos.items():
                # Formato esperado de repo: "username/repository"
                if "/" not in repo:
                    continue
                
                username, repository = repo.split("/", 1)
                api_url = f"https://api.github.com/repos/{username}/{repository}/events"
                
                try:
                    async with self.session.get(api_url) as response:
                        if response.status != 200:
                            continue
                        
                        events = await response.json()
                        
                        # Verificamos apenas eventos recentes desde a última verificação
                        if repo in self.last_check:
                            last_time = datetime.fromisoformat(self.last_check[repo])
                            new_events = []
                            newest_time = last_time
                            
                            for event in events:
                                event_time = datetime.fromisoformat(event["created_at"].replace("Z", "+00:00"))
                                if event_time > last_time:
                                    new_events.append(event)
                                    if event_time > newest_time:
                                        newest_time = event_time
                            
                            if new_events:
                                self.last_check[repo] = newest_time.isoformat()
                                for event in reversed(new_events[:5]):  # Processa até 5 eventos mais recentes
                                    await self._create_github_notification(event, channel_id, repo)
                        else:
                            # Primeira verificação, apenas salvamos o timestamp mais recente
                            if events:
                                most_recent = datetime.fromisoformat(events[0]["created_at"].replace("Z", "+00:00"))
                                self.last_check[repo] = most_recent.isoformat()
                                # Enviamos apenas o evento mais recente na primeira verificação
                                await self._create_github_notification(events[0], channel_id, repo)
                
                except Exception as e:
                    logger.error(f"Erro ao verificar repositório GitHub {repo}: {e}")
    
    async def _create_github_notification(self, event, channel_id, repo):
        """Cria e envia uma notificação para eventos do GitHub"""
        event_type = event["type"]
        username = event["actor"]["login"]
        avatar_url = event["actor"]["avatar_url"]
        
        embed = discord.Embed(
            title=f"Atualização no GitHub: {repo}",
            url=f"https://github.com/{repo}",
            color=0x2B3137,
            timestamp=datetime.fromisoformat(event["created_at"].replace("Z", "+00:00"))
        )
        
        embed.set_author(name=username, icon_url=avatar_url, url=f"https://github.com/{username}")
        embed.set_footer(text="GitHub", icon_url="https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png")
        
        if event_type == "PushEvent":
            commit_count = len(event["payload"]["commits"])
            branch = event["payload"]["ref"].split("/")[-1]
            
            embed.title = f"📥 Novo push em {repo}"
            embed.description = f"{username} fez push de {commit_count} commits para `{branch}`"
            
            # Adiciona até 3 commits na embed
            for i, commit in enumerate(event["payload"]["commits"][:3]):
                short_sha = commit["sha"][:7]
                message = commit["message"].split("\n")[0][:100]  # Primeira linha, limitada a 100 caracteres
                embed.add_field(
                    name=f"Commit {short_sha}",
                    value=f"[{message}](https://github.com/{repo}/commit/{commit['sha']})",
                    inline=False
                )
            
            if commit_count > 3:
                embed.add_field(
                    name="...",
                    value=f"[Ver todos os {commit_count} commits](https://github.com/{repo}/commits/{branch})",
                    inline=False
                )
        
        elif event_type == "CreateEvent":
            ref_type = event["payload"]["ref_type"]
            ref = event["payload"]["ref"]
            
            if ref_type == "branch":
                embed.title = f"🌿 Nova branch em {repo}"
                embed.description = f"{username} criou a branch `{ref}`"
                embed.url = f"https://github.com/{repo}/tree/{ref}"
            elif ref_type == "tag":
                embed.title = f"🏷️ Nova tag em {repo}"
                embed.description = f"{username} criou a tag `{ref}`"
                embed.url = f"https://github.com/{repo}/releases/tag/{ref}"
        
        elif event_type == "IssuesEvent":
            action = event["payload"]["action"]
            issue = event["payload"]["issue"]
            issue_number = issue["number"]
            issue_title = issue["title"]
            issue_url = issue["html_url"]
            
            embed.title = f"🐛 Issue #{issue_number} {action} em {repo}"
            embed.description = f"{username} {action} a issue [#{issue_number}: {issue_title}]({issue_url})"
            embed.url = issue_url
            
            if "body" in issue and issue["body"]:
                body = issue["body"]
                if len(body) > 200:
                    body = body[:200] + "..."
                embed.add_field(name="Descrição", value=body, inline=False)
        
        elif event_type == "PullRequestEvent":
            action = event["payload"]["action"]
            pr = event["payload"]["pull_request"]
            pr_number = pr["number"]
            pr_title = pr["title"]
            pr_url = pr["html_url"]
            
            emoji = "🔀"
            if action == "closed" and pr["merged"]:
                action = "merged"
                emoji = "🔄"
            
            embed.title = f"{emoji} PR #{pr_number} {action} em {repo}"
            embed.description = f"{username} {action} o pull request [#{pr_number}: {pr_title}]({pr_url})"
            embed.url = pr_url
            
            if action == "opened" or action == "merged":
                embed.add_field(
                    name="Mudanças",
                    value=f"+{pr['additions']} adições, -{pr['deletions']} remoções, {pr['changed_files']} arquivos alterados",
                    inline=False
                )
        
        elif event_type == "ReleaseEvent":
            release = event["payload"]["release"]
            tag = release["tag_name"]
            release_url = release["html_url"]
            
            embed.title = f"🚀 Nova release em {repo}"
            embed.description = f"{username} publicou a release [{tag}]({release_url})"
            embed.url = release_url
            
            if release["body"]:
                body = release["body"]
                if len(body) > 200:
                    body = body[:200] + "..."
                embed.add_field(name="Notas da Release", value=body, inline=False)
        
        elif event_type == "ForkEvent":
            fork = event["payload"]["forkee"]
            fork_url = fork["html_url"]
            fork_name = fork["full_name"]
            
            embed.title = f"🍴 Fork criado para {repo}"
            embed.description = f"{username} fez fork do repositório para [{fork_name}]({fork_url})"
            embed.url = fork_url
        
        elif event_type == "WatchEvent":
            embed.title = f"⭐ Novo star em {repo}"
            embed.description = f"{username} deu uma estrela ao repositório"
        
        await self.webhook_manager.send_webhook_message(
            channel_id=channel_id,
            embed=embed,
            username="GitHub Updates",
            avatar_url="https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png"
        )
    
    async def _check_youtube_channels(self):
        """Verifica novos vídeos em canais do YouTube"""
        # Precisamos de uma API key para o YouTube
        api_key = os.getenv("YOUTUBE_API_KEY")
        if not api_key:
            logger.warning("YOUTUBE_API_KEY não configurada, pulando verificação do YouTube")
            return
        
        for guild_id, channels in self.webhook_manager.webhook_data["youtube"].items():
            for youtube_id, channel_id in channels.items():
                api_url = f"https://www.googleapis.com/youtube/v3/search?part=snippet&channelId={youtube_id}&maxResults=5&order=date&type=video&key={api_key}"
                
                try:
                    async with self.session.get(api_url) as response:
                        if response.status != 200:
                            continue
                        
                        data = await response.json()
                        
                        if "items" not in data or not data["items"]:
                            continue
                        
                        latest_video = data["items"][0]
                        video_id = latest_video["id"]["videoId"]
                        
                        # Verificamos se já vimos este vídeo antes
                        video_key = f"yt_{youtube_id}_{video_id}"
                        if video_key in self.last_check:
                            continue
                        
                        # Obtemos detalhes completos do vídeo
                        video_url = f"https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id={video_id}&key={api_key}"
                        async with self.session.get(video_url) as video_response:
                            if video_response.status != 200:
                                continue
                            
                            video_data = await video_response.json()
                            if "items" not in video_data or not video_data["items"]:
                                continue
                            
                            video_details = video_data["items"][0]
                            
                            # Criamos a notificação
                            await self._create_youtube_notification(video_details, channel_id)
                            
                            # Marcamos este vídeo como já visto
                            self.last_check[video_key] = datetime.now().isoformat()
                
                except Exception as e:
                    logger.error(f"Erro ao verificar canal do YouTube {youtube_id}: {e}")
    
    async def _create_youtube_notification(self, video, channel_id):
        """Cria e envia notificação para novos vídeos do YouTube"""
        snippet = video["snippet"]
        statistics = video.get("statistics", {})
        
        title = snippet["title"]
        description = snippet["description"]
        thumbnail = snippet["thumbnails"]["high"]["url"]
        channel_title = snippet["channelTitle"]
        video_id = video["id"]
        published_at = datetime.fromisoformat(snippet["publishedAt"].replace("Z", "+00:00"))
        
        view_count = statistics.get("viewCount", "0")
        like_count = statistics.get("likeCount", "0")
        
        embed = discord.Embed(
            title=title,
            description=description[:200] + "..." if len(description) > 200 else description,
            url=f"https://www.youtube.com/watch?v={video_id}",
            color=0xFF0000,
            timestamp=published_at
        )
        
        embed.set_author(
            name=channel_title,
            url=f"https://www.youtube.com/channel/{snippet['channelId']}",
            icon_url="https://www.youtube.com/s/desktop/3f4a2ca2/img/favicon_144x144.png"
        )
        
        embed.set_image(url=thumbnail)
        
        embed.add_field(name="Visualizações", value=view_count, inline=True)
        embed.add_field(name="Curtidas", value=like_count, inline=True)
        
        embed.set_footer(
            text="YouTube",
            icon_url="https://www.youtube.com/s/desktop/3f4a2ca2/img/favicon_144x144.png"
        )
        
        await self.webhook_manager.send_webhook_message(
            channel_id=channel_id,
            content=f"🔴 **{channel_title}** acabou de postar um novo vídeo!\nhttps://www.youtube.com/watch?v={video_id}",
            embed=embed,
            username="YouTube Updates",
            avatar_url="https://www.youtube.com/s/desktop/3f4a2ca2/img/favicon_144x144.png"
        )
    
    async def _check_weather_updates(self):
        """Verifica atualizações de clima"""
        # Precisamos de uma API key para o serviço de clima
        api_key = os.getenv("OPENWEATHER_API_KEY")
        if not api_key:
            logger.warning("OPENWEATHER_API_KEY não configurada, pulando verificação de clima")
            return
        
        now = datetime.now()
        current_hour = now.hour
        
        # Verificamos se é hora de enviar atualizações diárias (8h) ou noturnas (20h)
        if current_hour != 8 and current_hour != 20:
            return
        
        is_morning = current_hour == 8
        
        for guild_id, locations in self.webhook_manager.webhook_data["weather"].items():
            for location, config in locations.items():
                channel_id = config["channel_id"]
                frequency = config["frequency"]
                
                # Verificamos se devemos enviar com base na frequência configurada
                if frequency == "daily" and is_morning:
                    pass  # OK, enviamos diariamente pela manhã
                elif frequency == "morning" and is_morning:
                    pass  # OK, enviamos apenas pela manhã
                elif frequency == "evening" and not is_morning:
                    pass  # OK, enviamos apenas à noite
                else:
                    continue  # Pulamos, não é o momento certo
                
                # Chama a API do OpenWeather
                api_url = f"https://api.openweathermap.org/data/2.5/forecast?q={location}&appid={api_key}&units=metric&lang=pt_br"
                
                try:
                    async with self.session.get(api_url) as response:
                        if response.status != 200:
                            continue
                        
                        weather_data = await response.json()
                        
                        # Criamos a notificação do clima
                        await self._create_weather_notification(weather_data, channel_id, is_morning)
                
                except Exception as e:
                    logger.error(f"Erro ao obter dados de clima para {location}: {e}")
    
    async def _create_weather_notification(self, weather_data, channel_id, is_morning):
        """Cria e envia notificação de previsão do tempo"""
        city = weather_data["city"]["name"]
        country = weather_data["city"]["country"]
        
        # Filtramos a previsão para hoje e amanhã
        forecasts = weather_data["list"]
        today_forecasts = []
        tomorrow_forecasts = []
        
        now = datetime.now()
        today = now.date()
        tomorrow = datetime(now.year, now.month, now.day).replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
        day_after_tomorrow = tomorrow + timedelta(days=1)
        
        for forecast in forecasts:
            dt = datetime.fromtimestamp(forecast["dt"])
            if dt.date() == today:
                today_forecasts.append(forecast)
            elif dt.date() == tomorrow.date():
                tomorrow_forecasts.append(forecast)
            elif dt >= day_after_tomorrow:
                break
        
        if is_morning:
            title = f"☀️ Previsão do tempo para hoje em {city}, {country}"
            current_forecasts = today_forecasts
        else:
            title = f"🌙 Previsão do tempo para amanhã em {city}, {country}"
            current_forecasts = tomorrow_forecasts
        
        if not current_forecasts:
            return
        
        embed = discord.Embed(
            title=title,
            color=0x3498DB,
            timestamp=datetime.now()
        )
        
        # Agrupamos as previsões por período do dia
        morning = []
        afternoon = []
        evening = []
        night = []
        
        for forecast in current_forecasts:
            dt = datetime.fromtimestamp(forecast["dt"])
            hour = dt.hour
            
            temp = forecast["main"]["temp"]
            feels_like = forecast["main"]["feels_like"]
            description = forecast["weather"][0]["description"].capitalize()
            icon_code = forecast["weather"][0]["icon"]
            icon_url = f"http://openweathermap.org/img/wn/{icon_code}@2x.png"
            
            forecast_text = f"**{int(temp)}°C** (sensação: {int(feels_like)}°C)\n{description}"
            
            if 5 <= hour < 12:
                morning.append((dt, forecast_text, icon_url))
            elif 12 <= hour < 18:
                afternoon.append((dt, forecast_text, icon_url))
            elif 18 <= hour < 22:
                evening.append((dt, forecast_text, icon_url))
            else:
                night.append((dt, forecast_text, icon_url))
        
        # Adicionamos os períodos à embed
        if morning and is_morning:
            morning_forecast = morning[0]
            embed.add_field(
                name=f"🌅 Manhã ({morning_forecast[0].hour}h)",
                value=morning_forecast[1],
                inline=True
            )
            embed.set_thumbnail(url=morning_forecast[2])
        
        if afternoon:
            afternoon_forecast = afternoon[0]
            embed.add_field(
                name=f"☀️ Tarde ({afternoon_forecast[0].hour}h)",
                value=afternoon_forecast[1],
                inline=True
            )
            if not morning and is_morning:
                embed.set_thumbnail(url=afternoon_forecast[2])
        
        if evening:
            evening_forecast = evening[0]
            embed.add_field(
                name=f"🌆 Noite ({evening_forecast[0].hour}h)",
                value=evening_forecast[1],
                inline=True
            )
            if not is_morning:
                embed.set_thumbnail(url=evening_forecast[2])
        
        if night:
            night_forecast = night[0]
            embed.add_field(
                name=f"🌃 Madrugada ({night_forecast[0].hour}h)",
                value=night_forecast[1],
                inline=True
            )
        
        # Verificamos informações adicionais importantes
        rain_chance = 0
        humidity = 0
        wind_speed = 0
        
        # Calculamos médias para o dia
        for forecast in current_forecasts:
            rain_chance = max(rain_chance, forecast.get("pop", 0) * 100)
            humidity += forecast["main"]["humidity"]
            wind_speed += forecast["wind"]["speed"]
        
        humidity = int(humidity / len(current_forecasts))
        wind_speed = wind_speed / len(current_forecasts)
        
        embed.add_field(
            name="💧 Umidade",
            value=f"{humidity}%",
            inline=True
        )
        
        embed.add_field(
            name="💨 Vento",
            value=f"{wind_speed:.1f} m/s",
            inline=True
        )
        
        if rain_chance > 0:
            embed.add_field(
                name="🌧️ Chance de Chuva",
                value=f"{int(rain_chance)}%",
                inline=True
            )
        
        embed.set_footer(
            text=f"Dados de OpenWeatherMap",
            icon_url="https://openweathermap.org/themes/openweathermap/assets/vendor/owm/img/icons/logo_60x60.png"
        )
        
        await self.webhook_manager.send_webhook_message(
            channel_id=channel_id,
            embed=embed,
            username="Previsão do Tempo",
            avatar_url="https://openweathermap.org/themes/openweathermap/assets/vendor/owm/img/icons/logo_60x60.png"
        )
    
    async def _check_news_updates(self):
        """Verifica atualizações de notícias"""
        # Precisamos de uma API key para notícias
        api_key = os.getenv("NEWS_API_KEY")
        if not api_key:
            logger.warning("NEWS_API_KEY não configurada, pulando verificação de notícias")
            return
        
        for guild_id, topics in self.webhook_manager.webhook_data["news"].items():
            for topic, channel_id in topics.items():
                topic_key = f"news_{topic}"
                
                # Verificamos se já fizemos a busca hoje
                if topic_key in self.last_check:
                    last_check_time = datetime.fromisoformat(self.last_check[topic_key])
                    if (datetime.now() - last_check_time).total_seconds() < 3600 * 12:  # 12 horas
                        continue
                
                # Define os parâmetros da busca
                params = {
                    "q": topic,
                    "language": "pt",
                    "sortBy": "publishedAt",
                    "pageSize": 5,
                    "apiKey": api_key
                }
                
                api_url = "https://newsapi.org/v2/top-headlines" if topic in ["brasil", "politica", "economia", "esporte", "tecnologia", "saude"] else "https://newsapi.org/v2/everything"
                
                try:
                    async with self.session.get(api_url, params=params) as response:
                        if response.status != 200:
                            continue
                        
                        news_data = await response.json()
                        
                        if news_data["status"] != "ok" or not news_data["articles"]:
                            continue
                        
                        # Atualizamos o timestamp
                        self.last_check[topic_key] = datetime.now().isoformat()
                        
                        # Enviamos até 3 notícias mais recentes
                        for article in news_data["articles"][:3]:
                            await self._create_news_notification(article, channel_id, topic)
                
                except Exception as e:
                    logger.error(f"Erro ao obter notícias para o tópico '{topic}': {e}")
    
    async def _create_news_notification(self, article, channel_id, topic):
        """Cria e envia notificação de notícias"""
        title = article["title"]
        
        # Alguns artigos não possuem todos os campos
        description = article.get("description", "")
        if not description:
            description = "Clique no título para ler a notícia completa."
        
        url = article["url"]
        image_url = article.get("urlToImage", "")
        source_name = article["source"]["name"]
        published_at = datetime.fromisoformat(article["publishedAt"].replace("Z", "+00:00"))
        
        # Emojis baseados no tópico
        emoji = "📰"
        color = 0x607D8B
        
        topic_lower = topic.lower()
        if "brasil" in topic_lower or "política" in topic_lower:
            emoji = "🇧🇷"
            color = 0x009c3b
        elif "esporte" in topic_lower or "futebol" in topic_lower:
            emoji = "⚽"
            color = 0x4CAF50
        elif "tecnologia" in topic_lower or "tech" in topic_lower:
            emoji = "💻"
            color = 0x2196F3
        elif "economia" in topic_lower or "finanças" in topic_lower:
            emoji = "📈"
            color = 0xFFC107
        elif "saúde" in topic_lower or "medicina" in topic_lower:
            emoji = "🏥"
            color = 0xF44336
        elif "entretenimento" in topic_lower or "celebridades" in topic_lower:
            emoji = "🎬"
            color = 0x9C27B0
        elif "ciência" in topic_lower:
            emoji = "🔬"
            color = 0x00BCD4
        
        embed = discord.Embed(
            title=title,
            description=description[:200] + "..." if len(description) > 200 else description,
            url=url,
            color=color,
            timestamp=published_at
        )
        
        if image_url:
            embed.set_image(url=image_url)
        
        embed.set_author(name=source_name)
        embed.set_footer(text=f"Notícias | {topic.capitalize()}")
        
        await self.webhook_manager.send_webhook_message(
            channel_id=channel_id,
            embed=embed,
            username=f"{emoji} Notícias: {topic.capitalize()}",
            avatar_url="https://cdn-icons-png.flaticon.com/512/2965/2965879.png"
        )
    
    @commands.group(aliases=["webhook", "webhooks", "integration", "integrations"], invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    async def webhook_config(self, ctx):
        """
        Configurar integrações com serviços externos
        Usage: !webhook
        """
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="⚙️ Configurações de Webhooks e Integrações",
                description="Configure o bot para receber atualizações automáticas de serviços externos.",
                color=discord.Color.blue()
            )
            
            embed.add_field(
                name="Comandos Disponíveis",
                value="""
                **!webhook github <repo> [#canal]** - Receber atualizações de um repositório GitHub
                **!webhook youtube <canal_id> [#canal]** - Receber novos vídeos de um canal do YouTube
                **!webhook weather <cidade> [frequência] [#canal]** - Receber previsões do tempo para uma cidade
                **!webhook news <tópico> [#canal]** - Receber notícias sobre um tópico específico
                **!webhook list** - Listar todas as integrações configuradas
                **!webhook remove <tipo> <identificador>** - Remover uma integração existente
                """,
                inline=False
            )
            
            embed.add_field(
                name="Notas",
                value="""
                • API keys externas podem ser necessárias para algumas integrações
                • O bot precisa de permissão para gerenciar webhooks nos canais
                • Use o comando `!webhook list` para ver integrações ativas
                """,
                inline=False
            )
            
            await ctx.send(embed=embed)
    
    @webhook_config.command(name="github")
    @commands.has_permissions(manage_guild=True)
    async def webhook_github(self, ctx, repository: str, channel: discord.TextChannel = None):
        """
        Configura notificações para um repositório GitHub
        Usage: !webhook github username/repositorio [#canal]
        """
        if "/" not in repository:
            return await ctx.send("❌ Formato de repositório inválido. Use o formato `username/repositorio`.")
        
        channel = channel or ctx.channel
        
        # Verifica permissões no canal
        if not channel.permissions_for(ctx.guild.me).manage_webhooks:
            return await ctx.send(f"❌ Eu não tenho permissão para gerenciar webhooks no canal {channel.mention}.")
        
        await self.webhook_manager.add_github_webhook(ctx.guild.id, channel.id, repository)
        
        await ctx.send(f"✅ Notificações do repositório GitHub **{repository}** serão enviadas para {channel.mention}.")
    
    @webhook_config.command(name="youtube")
    @commands.has_permissions(manage_guild=True)
    async def webhook_youtube(self, ctx, channel_id: str, discord_channel: discord.TextChannel = None):
        """
        Configura notificações para um canal do YouTube
        Usage: !webhook youtube ID_DO_CANAL [#canal]
        """
        discord_channel = discord_channel or ctx.channel
        
        # Verifica se temos a API key necessária
        if not os.getenv("YOUTUBE_API_KEY"):
            return await ctx.send("❌ API Key do YouTube não configurada. Peça ao administrador do bot para configurar a variável `YOUTUBE_API_KEY`.")
        
        # Verifica permissões no canal
        if not discord_channel.permissions_for(ctx.guild.me).manage_webhooks:
            return await ctx.send(f"❌ Eu não tenho permissão para gerenciar webhooks no canal {discord_channel.mention}.")
        
        # Verifica se o ID do canal é válido
        try:
            api_key = os.getenv("YOUTUBE_API_KEY")
            url = f"https://www.googleapis.com/youtube/v3/channels?part=snippet&id={channel_id}&key={api_key}"
            
            async with self.session.get(url) as response:
                if response.status != 200:
                    return await ctx.send("❌ Erro ao verificar o canal do YouTube. Verifique se o ID está correto.")
                
                data = await response.json()
                
                if not data.get("items"):
                    return await ctx.send("❌ Canal do YouTube não encontrado. Verifique se o ID está correto.")
                
                channel_title = data["items"][0]["snippet"]["title"]
        except Exception as e:
            logger.error(f"Erro ao verificar canal do YouTube: {e}")
            return await ctx.send("❌ Ocorreu um erro ao verificar o canal do YouTube.")
        
        await self.webhook_manager.add_youtube_webhook(ctx.guild.id, discord_channel.id, channel_id)
        
        await ctx.send(f"✅ Notificações de novos vídeos do canal **{channel_title}** serão enviadas para {discord_channel.mention}.")
    
    @webhook_config.command(name="weather")
    @commands.has_permissions(manage_guild=True)
    async def webhook_weather(self, ctx, location: str, frequency: str = "daily", channel: discord.TextChannel = None):
        """
        Configura notificações de previsão do tempo
        Usage: !webhook weather cidade [frequência] [#canal]
        Frequências disponíveis: daily, morning, evening
        """
        channel = channel or ctx.channel
        
        # Verifica se temos a API key necessária
        if not os.getenv("OPENWEATHER_API_KEY"):
            return await ctx.send("❌ API Key do OpenWeatherMap não configurada. Peça ao administrador do bot para configurar a variável `OPENWEATHER_API_KEY`.")
        
        # Valida a frequência
        if frequency not in ["daily", "morning", "evening"]:
            return await ctx.send("❌ Frequência inválida. Use `daily`, `morning` ou `evening`.")
        
        # Verifica permissões no canal
        if not channel.permissions_for(ctx.guild.me).manage_webhooks:
            return await ctx.send(f"❌ Eu não tenho permissão para gerenciar webhooks no canal {channel.mention}.")
        
        # Verifica se a cidade é válida
        try:
            api_key = os.getenv("OPENWEATHER_API_KEY")
            url = f"https://api.openweathermap.org/data/2.5/weather?q={location}&appid={api_key}"
            
            async with self.session.get(url) as response:
                if response.status != 200:
                    return await ctx.send("❌ Cidade não encontrada. Verifique se o nome está correto.")
                
                data = await response.json()
                city_name = data["name"]
                country = data["sys"]["country"]
        except Exception as e:
            logger.error(f"Erro ao verificar cidade: {e}")
            return await ctx.send("❌ Ocorreu um erro ao verificar a cidade.")
        
        await self.webhook_manager.add_weather_webhook(ctx.guild.id, channel.id, location, frequency)
        
        frequency_text = {
            "daily": "diariamente pela manhã",
            "morning": "todas as manhãs",
            "evening": "todas as noites"
        }
        
        await ctx.send(f"✅ Previsões do tempo para **{city_name}, {country}** serão enviadas {frequency_text[frequency]} para {channel.mention}.")
    
    @webhook_config.command(name="news")
    @commands.has_permissions(manage_guild=True)
    async def webhook_news(self, ctx, topic: str, channel: discord.TextChannel = None):
        """
        Configura notificações de notícias
        Usage: !webhook news tópico [#canal]
        Exemplo de tópicos: brasil, tecnologia, esportes, economia
        """
        channel = channel or ctx.channel
        
        # Verifica se temos a API key necessária
        if not os.getenv("NEWS_API_KEY"):
            return await ctx.send("❌ API Key do NewsAPI não configurada. Peça ao administrador do bot para configurar a variável `NEWS_API_KEY`.")
        
        # Verifica permissões no canal
        if not channel.permissions_for(ctx.guild.me).manage_webhooks:
            return await ctx.send(f"❌ Eu não tenho permissão para gerenciar webhooks no canal {channel.mention}.")
        
        await self.webhook_manager.add_news_webhook(ctx.guild.id, channel.id, topic)
        
        await ctx.send(f"✅ Notícias sobre **{topic}** serão enviadas para {channel.mention}.")
    
    @webhook_config.command(name="list")
    @commands.has_permissions(manage_guild=True)
    async def webhook_list(self, ctx):
        """
        Lista todas as integrações configuradas para o servidor
        Usage: !webhook list
        """
        guild_id = str(ctx.guild.id)
        
        embed = discord.Embed(
            title="📋 Integrações Configuradas",
            description="Lista de todas as integrações ativas neste servidor.",
            color=discord.Color.blue()
        )
        
        # GitHub
        if guild_id in self.webhook_manager.webhook_data["github"] and self.webhook_manager.webhook_data["github"][guild_id]:
            github_text = ""
            for repo, channel_id in self.webhook_manager.webhook_data["github"][guild_id].items():
                channel = self.bot.get_channel(channel_id)
                channel_mention = channel.mention if channel else f"Canal #{channel_id}"
                github_text += f"• **{repo}** → {channel_mention}\n"
            
            if github_text:
                embed.add_field(name="GitHub", value=github_text, inline=False)
        
        # YouTube
        if guild_id in self.webhook_data["youtube"] and self.webhook_data["youtube"][guild_id]:
            youtube_text = ""
            for channel_id, discord_channel_id in self.webhook_data["youtube"][guild_id].items():
                channel = self.bot.get_channel(discord_channel_id)
                channel_mention = channel.mention if channel else f"Canal #{discord_channel_id}"
                youtube_text += f"• **{channel_id}** → {channel_mention}\n"
            
            if youtube_text:
                embed.add_field(name="YouTube", value=youtube_text, inline=False)
        
        # Clima
        if guild_id in self.webhook_data["weather"] and self.webhook_data["weather"][guild_id]:
            weather_text = ""
            for location, config in self.webhook_data["weather"][guild_id].items():
                channel_id = config["channel_id"]
                frequency = config["frequency"]
                
                channel = self.bot.get_channel(channel_id)
                channel_mention = channel.mention if channel else f"Canal #{channel_id}"
                
                weather_text += f"• **{location}** ({frequency}) → {channel_mention}\n"
            
            if weather_text:
                embed.add_field(name="Previsão do Tempo", value=weather_text, inline=False)
        
        # Notícias
        if guild_id in self.webhook_data["news"] and self.webhook_data["news"][guild_id]:
            news_text = ""
            for topic, channel_id in self.webhook_data["news"][guild_id].items():
                channel = self.bot.get_channel(channel_id)
                channel_mention = channel.mention if channel else f"Canal #{channel_id}"
                news_text += f"• **{topic}** → {channel_mention}\n"
            
            if news_text:
                embed.add_field(name="Notícias", value=news_text, inline=False)
        
        # Verificamos se há integrações
        if len(embed.fields) == 0:
            embed.description = "Nenhuma integração configurada para este servidor. Use `!webhook` para ver os comandos disponíveis."
        
        await ctx.send(embed=embed)
    
    @webhook_config.command(name="remove")
    @commands.has_permissions(manage_guild=True)
    async def webhook_remove(self, ctx, service: str, identifier: str):
        """
        Remove uma integração configurada
        Usage: !webhook remove <serviço> <identificador>
        Exemplo: !webhook remove github username/repositorio
        """
        service = service.lower()
        
        if service not in ["github", "youtube", "weather", "news", "custom"]:
            return await ctx.send("❌ Serviço inválido. Serviços disponíveis: `github`, `youtube`, `weather`, `news`, `custom`.")
        
        success = await self.webhook_manager.remove_webhook(ctx.guild.id, service, identifier)
        
        if success:
            await ctx.send(f"✅ Integração com **{service}** para **{identifier}** removida com sucesso.")
        else:
            await ctx.send(f"❌ Não foi encontrada nenhuma integração com **{service}** para **{identifier}**.")
    
    @webhook_config.command(name="test")
    @commands.has_permissions(manage_guild=True)
    async def webhook_test(self, ctx, service: str, identifier: str = None):
        """
        Testa uma integração enviando uma mensagem de exemplo
        Usage: !webhook test <serviço> [identificador]
        """
        service = service.lower()
        
        if service not in ["github", "youtube", "weather", "news"]:
            return await ctx.send("❌ Serviço inválido. Serviços disponíveis: `github`, `youtube`, `weather`, `news`.")
        
        embed = None
        username = None
        avatar_url = None
        content = None
        
        if service == "github":
            embed = discord.Embed(
                title="🔄 Teste de Notificação GitHub",
                description="Esta é uma mensagem de teste para a integração com GitHub.",
                color=0x2B3137,
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Commit abc1234",
                value="[Mensagem de commit de exemplo](https://github.com)",
                inline=False
            )
            
            embed.set_author(name="Usuario", icon_url="https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png")
            embed.set_footer(text="GitHub", icon_url="https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png")
            
            username = "GitHub Updates"
            avatar_url = "https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png"
        
        elif service == "youtube":
            embed = discord.Embed(
                title="Título do Vídeo de Teste",
                description="Esta é uma descrição de exemplo para um vídeo do YouTube.",
                url="https://www.youtube.com",
                color=0xFF0000,
                timestamp=datetime.now()
            )
            
            embed.set_author(
                name="Nome do Canal",
                url="https://www.youtube.com",
                icon_url="https://www.youtube.com/s/desktop/3f4a2ca2/img/favicon_144x144.png"
            )
            
            embed.set_image(url="https://i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg")
            
            embed.add_field(name="Visualizações", value="1000", inline=True)
            embed.add_field(name="Curtidas", value="100", inline=True)
            
            embed.set_footer(
                text="YouTube",
                icon_url="https://www.youtube.com/s/desktop/3f4a2ca2/img/favicon_144x144.png"
            )
            
            content = "🔴 **Nome do Canal** acabou de postar um novo vídeo!\nhttps://www.youtube.com"
            username = "YouTube Updates"
            avatar_url = "https://www.youtube.com/s/desktop/3f4a2ca2/img/favicon_144x144.png"
        
        elif service == "weather":
            embed = discord.Embed(
                title="☀️ Previsão do tempo para hoje em São Paulo, BR",
                color=0x3498DB,
                timestamp=datetime.now()
            )
            
            embed.add_field(name="🌅 Manhã (9h)", value="**24°C** (sensação: 26°C)\nCéu limpo", inline=True)
            embed.add_field(name="☀️ Tarde (15h)", value="**28°C** (sensação: 30°C)\nParcialmente nublado", inline=True)
            embed.add_field(name="🌆 Noite (20h)", value="**22°C** (sensação: 23°C)\nPoucas nuvens", inline=True)
            
            embed.add_field(name="💧 Umidade", value="75%", inline=True)
            embed.add_field(name="💨 Vento", value="3.5 m/s", inline=True)
            embed.add_field(name="🌧️ Chance de Chuva", value="10%", inline=True)
            
            embed.set_thumbnail(url="http://openweathermap.org/img/wn/01d@2x.png")
            
            embed.set_footer(
                text="Dados de OpenWeatherMap",
                icon_url="https://openweathermap.org/themes/openweathermap/assets/vendor/owm/img/icons/logo_60x60.png"
            )
            
            username = "Previsão do Tempo"
            avatar_url = "https://openweathermap.org/themes/openweathermap/assets/vendor/owm/img/icons/logo_60x60.png"
        
        elif service == "news":
            embed = discord.Embed(
                title="Título da Notícia de Teste",
                description="Esta é uma descrição de exemplo para uma notícia. Clique no título para ler a notícia completa.",
                url="https://exemplo.com/noticia",
                color=0x607D8B,
                timestamp=datetime.now()
            )
            
            embed.set_image(url="https://picsum.photos/seed/picsum/800/400")
            
            embed.set_author(name="Portal de Notícias")
            embed.set_footer(text="Notícias | Brasil")
            
            username = "📰 Notícias: Brasil"
            avatar_url = "https://cdn-icons-png.flaticon.com/512/2965/2965879.png"
        
        await self.webhook_manager.send_webhook_message(
            channel_id=ctx.channel.id,
            content=content,
            embed=embed,
            username=username,
            avatar_url=avatar_url
        )
        
        await ctx.send("✅ Mensagem de teste enviada com sucesso!")


async def setup(bot):
    await bot.add_cog(WebhookIntegrations(bot))