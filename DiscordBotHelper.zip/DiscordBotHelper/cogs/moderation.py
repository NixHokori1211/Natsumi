"""
Moderation commands for the Discord bot.
"""
import asyncio
import discord
from discord.ext import commands
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name="kick")
    @commands.has_permissions(kick_members=True)
    @commands.bot_has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason=None):
        """
        Kick a member from the server
        Usage: !kick @member [reason]
        """
        if member == ctx.author:
            await ctx.send("You cannot kick yourself.")
            return
            
        if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
            await ctx.send("You cannot kick someone with a role higher than or equal to yours.")
            return
            
        if member.top_role >= ctx.guild.me.top_role:
            await ctx.send("I cannot kick someone with a role higher than or equal to mine.")
            return
        
        reason = reason or "No reason provided"
        audit_reason = f"Kicked by {ctx.author} (ID: {ctx.author.id}): {reason}"
        
        try:
            await member.send(f"You have been kicked from {ctx.guild.name} for: {reason}")
        except discord.Forbidden:
            # Cannot send DM to the user
            pass
        
        await member.kick(reason=audit_reason)
        
        embed = discord.Embed(
            title="Member Kicked",
            description=f"{member.mention} has been kicked from the server.",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Reason", value=reason)
        embed.set_footer(text=f"Kicked by {ctx.author}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await ctx.send(embed=embed)
        logger.info(f"User {member} was kicked by {ctx.author} for: {reason}")
    
    @commands.command(name="ban")
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason=None):
        """
        Ban a member from the server
        Usage: !ban @member [reason]
        """
        if member == ctx.author:
            await ctx.send("You cannot ban yourself.")
            return
            
        if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
            await ctx.send("You cannot ban someone with a role higher than or equal to yours.")
            return
            
        if member.top_role >= ctx.guild.me.top_role:
            await ctx.send("I cannot ban someone with a role higher than or equal to mine.")
            return
        
        reason = reason or "No reason provided"
        audit_reason = f"Banned by {ctx.author} (ID: {ctx.author.id}): {reason}"
        
        try:
            await member.send(f"You have been banned from {ctx.guild.name} for: {reason}")
        except discord.Forbidden:
            # Cannot send DM to the user
            pass
        
        await member.ban(reason=audit_reason, delete_message_days=1)
        
        embed = discord.Embed(
            title="Member Banned",
            description=f"{member.mention} has been banned from the server.",
            color=discord.Color.dark_red(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Reason", value=reason)
        embed.set_footer(text=f"Banned by {ctx.author}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await ctx.send(embed=embed)
        logger.info(f"User {member} was banned by {ctx.author} for: {reason}")
    
    @commands.command(name="unban")
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def unban(self, ctx, user_id: int, *, reason=None):
        """
        Unban a user by their ID
        Usage: !unban <user_id> [reason]
        """
        reason = reason or "No reason provided"
        audit_reason = f"Unbanned by {ctx.author} (ID: {ctx.author.id}): {reason}"
        
        try:
            banned_users = [entry async for entry in ctx.guild.bans()]
            user = discord.utils.get(banned_users, user__id=user_id)
            
            if user is None:
                await ctx.send(f"No banned user found with ID {user_id}")
                return
                
            await ctx.guild.unban(user.user, reason=audit_reason)
            
            embed = discord.Embed(
                title="User Unbanned",
                description=f"{user.user.name}#{user.user.discriminator} (ID: {user.user.id}) has been unbanned.",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            embed.add_field(name="Reason", value=reason)
            embed.set_footer(text=f"Unbanned by {ctx.author}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
            
            await ctx.send(embed=embed)
            logger.info(f"User {user.user} was unbanned by {ctx.author} for: {reason}")
            
        except discord.NotFound:
            await ctx.send(f"User with ID {user_id} not found.")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")
            logger.error(f"Error unbanning user {user_id}: {e}")
    
    @commands.command(name="purge")
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    async def purge(self, ctx, amount: int):
        """
        Delete a specified number of messages from the channel
        Usage: !purge <amount>
        """
        if amount <= 0:
            await ctx.send("Please provide a positive number of messages to delete.")
            return
            
        if amount > 100:
            await ctx.send("You can only delete up to 100 messages at once.")
            return
        
        # Delete the command message first
        await ctx.message.delete()
        
        # Then delete the specified number of messages
        deleted = await ctx.channel.purge(limit=amount)
        
        # Send confirmation message and then delete it after 5 seconds
        confirmation = await ctx.send(f"Deleted {len(deleted)} messages.")
        await asyncio.sleep(5)
        await confirmation.delete()
        
        logger.info(f"{ctx.author} purged {len(deleted)} messages in {ctx.channel.name}")
    
    @commands.command(name="mute")
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def mute(self, ctx, member: discord.Member, duration: str = None, *, reason=None):
        """
        Mute a member in the server
        Usage: !mute @member [duration] [reason]
        Duration format: 1d, 2h, 30m, 45s (or a combination like 1h30m)
        """
        if member == ctx.author:
            await ctx.send("You cannot mute yourself.")
            return
            
        if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
            await ctx.send("You cannot mute someone with a role higher than or equal to yours.")
            return
            
        if member.top_role >= ctx.guild.me.top_role:
            await ctx.send("I cannot mute someone with a role higher than or equal to mine.")
            return
        
        reason = reason or "No reason provided"
        
        # Try to find or create a muted role
        muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
        if not muted_role:
            try:
                # Create the muted role
                muted_role = await ctx.guild.create_role(name="Muted", reason="Created for mute command")
                
                # Set permissions for the muted role
                for channel in ctx.guild.channels:
                    await channel.set_permissions(
                        muted_role, 
                        send_messages=False,
                        add_reactions=False,
                        connect=False,
                        speak=False
                    )
            except discord.Forbidden:
                await ctx.send("I don't have permission to create or configure the Muted role.")
                return
        
        # Parse duration if provided
        until = None
        if duration:
            total_seconds = 0
            time_formats = {
                'd': 86400,  # days
                'h': 3600,   # hours
                'm': 60,     # minutes
                's': 1       # seconds
            }
            
            remaining = duration
            while remaining:
                found = False
                for format_char, seconds in time_formats.items():
                    if format_char in remaining:
                        try:
                            value, remaining = remaining.split(format_char, 1)
                            total_seconds += int(value) * seconds
                            found = True
                            break
                        except ValueError:
                            await ctx.send(f"Invalid duration format: {duration}. Use formats like 1d, 2h, 30m, 45s.")
                            return
                if not found:
                    await ctx.send(f"Invalid duration format: {duration}. Use formats like 1d, 2h, 30m, 45s.")
                    return
            
            if total_seconds > 0:
                until = datetime.now() + timedelta(seconds=total_seconds)
        
        # Apply the muted role
        await member.add_roles(muted_role, reason=f"Muted by {ctx.author}: {reason}")
        
        embed = discord.Embed(
            title="Member Muted",
            description=f"{member.mention} has been muted.",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Reason", value=reason, inline=False)
        
        if until:
            embed.add_field(name="Duration", value=duration, inline=False)
            embed.add_field(name="Unmuted at", value=until.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)
        else:
            embed.add_field(name="Duration", value="Indefinite", inline=False)
            
        embed.set_footer(text=f"Muted by {ctx.author}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await ctx.send(embed=embed)
        logger.info(f"User {member} was muted by {ctx.author} for: {reason}")
        
        # If duration is specified, schedule unmute
        if until:
            # Sleep until the unmute time
            await asyncio.sleep(total_seconds)
            
            # Check if the member still has the muted role
            member = ctx.guild.get_member(member.id)
            if member and muted_role in member.roles:
                await member.remove_roles(muted_role, reason=f"Temporary mute expired")
                
                # Notify the channel
                unmute_embed = discord.Embed(
                    title="Member Unmuted",
                    description=f"{member.mention} has been automatically unmuted after their mute duration expired.",
                    color=discord.Color.green(),
                    timestamp=datetime.now()
                )
                await ctx.send(embed=unmute_embed)
                logger.info(f"User {member} was automatically unmuted after duration expired")

async def setup(bot):
    await bot.add_cog(Moderation(bot))
