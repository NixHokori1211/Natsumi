"""
Language commands for the Discord bot.
Provides translation, language detection, and Portuguese language features.
"""
import discord
from discord.ext import commands
import logging
import json
import random
import os
import asyncio
from datetime import datetime

logger = logging.getLogger(__name__)

# Brazilian Portuguese greetings
PT_BR_GREETINGS = [
    "Olá", "Oi", "E aí", "Tudo bem", "Beleza", "Eae", "Fala aí", "Salve"
]

# Brazilian Portuguese responses
PT_BR_RESPONSES = {
    "yes": ["Sim", "Claro", "Com certeza", "Pode crer", "Exatamente", "É isso aí"],
    "no": ["Não", "De jeito nenhum", "Negativo", "Nunca", "Jamais"],
    "thanks": ["Obrigado!", "Valeu!", "Muito obrigado!", "Gratidão!", "Agradeço!"],
    "welcome": ["De nada!", "Por nada!", "Disponha!", "Às ordens!", "O prazer é meu!"],
    "goodbye": ["Tchau!", "Até mais!", "Até logo!", "Falou!", "Até a próxima!"]
}

# Brazilian Portuguese common expressions
PT_BR_EXPRESSIONS = [
    "Nossa Senhora!",
    "Meu Deus!",
    "Que legal!",
    "Sério mesmo?",
    "Não acredito!",
    "Puts grila!",
    "Caramba!",
    "Que massa!",
    "Que dahora!",
    "Eita!",
    "Vixe!",
    "Puxa vida!",
    "Meu!",
    "Véi!",
    "Ó!"
]

# Brazilian Portuguese slang
PT_BR_SLANG = {
    "Maneiro": "Cool/awesome",
    "Beleza": "Great/fine/ok",
    "Bacana": "Nice/cool",
    "Cara": "Dude/guy",
    "Mano": "Bro/dude",
    "Véi": "Dude/bro (commonly used in Brasília)",
    "Meu": "Dude (commonly used in São Paulo)",
    "Bah": "Expression of surprise (commonly used in Rio Grande do Sul)",
    "Valeu": "Thanks/goodbye",
    "Falou": "Goodbye/ok",
    "Massa": "Cool/awesome",
    "Dahora": "Cool/awesome",
    "Tá ligado": "You know?/understand?",
    "Boto fé": "I believe it/I agree",
    "Irado": "Awesome/amazing",
    "Fechou": "It's a deal/agreed",
}

# Brazilian Portuguese jokes - categorized by type
PT_BR_JOKES = {
    # Regular jokes (trocadilhos e piadas leves)
    "regular": [
        "Por que o jacaré tirou o filho da escola? Porque ele réptil de ano.",
        "O que o pato disse para a pata? Vem Quá!",
        "Por que a galinha atravessou a rua? Para chegar do outro lado!",
        "O que aconteceu com os lápis quando souberam que o chefe deles tinha morrido? Ficaram desapontados.",
        "Como o Batman faz para entrar na Bat-caverna? Ele bat-palma!",
        "O que o zero disse para o oito? Belo cinto!",
        "O que dá o cruzamento de pão com sabonete? Um pãonete para comer limpinho.",
        "Por que o elefante usa tênis vermelho? Para se esconder na árvore de cerejas.",
        "O que o tomate foi fazer no banco? Tirar extrato!",
        "Por que o computador foi preso? Porque cometeu um crime cibernético!",
        "Qual é o alimento mais sagrado? O amém-doim.",
        "O que o advogado do frango disse no tribunal? Meu cliente é inocente, ele só estava atravessando a rua!",
        "O que a formiga disse pra outra? Você prometeu que ia me ligar mas não deu um alamar!",
        "Por que o pão não pode ser ator? Porque ele fica sem graça na hora de atuar.",
        "Qual é o fim da picada? Quando o mosquito vai embora.",
        "Por que a planta não pode dirigir? Porque ela não tem carteira de habilitação.",
    ],
    
    # Dark humor jokes (humor negro)
    "dark": [
        "Por que o livro de matemática se suicidou? Porque tinha muitos problemas.",
        "O que a banana suicida falou? Meu fim está próximo.",
        "Como se faz para afundar um submarino ucraniano? Bate na porta.",
        "O que é mais engraçado que uma criança morta? Uma criança morta vestida de palhaço.",
        "Como se chama um caixão de anão? Ecologicamente correto, economiza madeira.",
        "Você sabe qual é a parte mais difícil de comer um vegetal? A cadeira de rodas.",
        "Por que o cego não conseguiu salvar seu amigo do incêndio? Porque ele não enxerga ninguém.",
        "Reza a lenda que no céu existem pessoas honestas. Porém, nunca ninguém voltou de lá para confirmar.",
        "Qual a semelhança entre a pizza e o forno crematório? Ambos transformam a matéria em cinzas.",
        "Sabe o que o surdo falou para o cego? Nada, o surdo não fala e o cego não ouve, os dois têm deficiência mas em órgãos diferentes.",
        "Qual a diferença entre um padre e uma espinha? A espinha espera você ficar adolescente para aparecer na sua cara.",
        "Por que o anão não pode ser dublê? Porque ele é de menor.",
        "Qual é a diferença entre o Michael Jackson e um saco plástico? Um é perigoso para crianças, e o outro é só um saco plástico.",
        "Qual a diferença entre a minha piada e uma pessoa com câncer? A minha piada não fica melhor quando ela morre.",
        "Quando você percebe que virou adulto? Quando seus joelhos fazem mais barulho que suas articulações de brinquedo.",
    ],
    
    # Sarcastic jokes (humor sarcástico)
    "sarcastic": [
        "Não posso viver sem você? Falso. Eu respiro oxigênio, não você.",
        "Me disseram que dinheiro não compra felicidade. Agora me pergunto por que as pessoas com dinheiro estão sempre sorrindo nas fotos.",
        "Eu não sou antipático. Eu só não tenho paciência para lidar com idiotas.",
        "Eu já tentei ver o lado bom das pessoas, mas geralmente elas ficam de frente para mim.",
        "Sim, eu tenho um plano de dieta. Comer tudo e lamentar depois.",
        "Não é que eu não goste de acordar cedo. Eu só prefiro não fazer algo tão traumático antes das 11 da manhã.",
        "Não é que eu seja preguiçoso, apenas estou economizando energia para quando realmente importar.",
        "Você tem o direito de permanecer calado. Por favor, use esse direito.",
        "A única vez que tenho energia infinita é quando preciso dormir.",
        "É engraçado como as pessoas acham que me importo com suas opiniões.",
        "Quando alguém diz 'é sempre no último lugar que a gente procura', claro, porque ninguém continua procurando depois de encontrar.",
        "A vida é como um banco, se você não souber investir, perderá tudo em um instante.",
        "Quer saber qual é o melhor método para emagrecer? Fotos de antes e depois editadas no Photoshop.",
    ],
    
    # Politically incorrect jokes (piadas politicamente incorretas)
    "offensive": [
        "Como se chama um grupo de advogados no fundo do mar? Um bom começo!",
        "Qual a diferença entre políticos e fraldas? Nenhuma, ambos devem ser trocados regularmente, e pelo mesmo motivo.",
        "Por que loiras não comem bananas? Porque não encontram o zíper.",
        "Por que Deus criou o homem? Porque um vibrador não corta grama.",
        "Como se faz para encontrar uma agulha em um palheiro? Coloque um português no palheiro e espere ele sentar.",
        "Como a polícia argentina faz para pegar bandidos? Coloca filé mignon no chão.",
        "Como é chamado um elevador num país africano? Um milagre.",
        "O que faz quando seu computador não reconhece o pendrive? Apresenta os dois formalmente.",
        "Qual a diferença entre um preto e um câncer? O câncer tem cura.",
        "Por que a loira jogou o relógio pela janela? Para ver o tempo voar.",
        "Por que a loira limpa o computador com sabão? Para limpar o histórico.",
        "Por que o goleiro do time do Japão é o melhor do mundo? Porque o gol para ele é só uma linha horizontal.",
        "Qual é a diferença entre uma mulher ciumenta e uma terrorista? Você pode negociar com a terrorista!",
    ]
}

class Language(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.language_data_path = "language_data.json"
        self.language_data = self.load_language_data()
    
    def load_language_data(self):
        """Load saved language data from JSON file"""
        if os.path.exists(self.language_data_path):
            try:
                with open(self.language_data_path, 'r', encoding='utf-8') as file:
                    return json.load(file)
            except Exception as e:
                logger.error(f"Failed to load language data: {e}")
        # Initialize with empty data if file doesn't exist
        return {"user_preferences": {}, "custom_translations": {}}
    
    def save_language_data(self):
        """Save language data to JSON file"""
        try:
            with open(self.language_data_path, 'w', encoding='utf-8') as file:
                json.dump(self.language_data, file, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Failed to save language data: {e}")
    
    @commands.group(name="ptbr", invoke_without_command=True)
    async def ptbr(self, ctx):
        """
        Brazilian Portuguese language commands
        Usage: !ptbr [subcommand]
        """
        if ctx.invoked_subcommand is None:
            greeting = random.choice(PT_BR_GREETINGS)
            embed = discord.Embed(
                title="🇧🇷 Português Brasileiro",
                description=f"{greeting}! Use `{ctx.prefix}ptbr help` para ver os comandos disponíveis.",
                color=discord.Color.green()
            )
            
            # Add fields for available subcommands
            embed.add_field(
                name="Comandos Disponíveis",
                value=(
                    f"`{ctx.prefix}ptbr greet` - Saudação em português\n"
                    f"`{ctx.prefix}ptbr slang` - Gírias brasileiras\n"
                    f"`{ctx.prefix}ptbr joke [tipo]` - Piadas brasileiras (tipos: regular, dark, sarcastic, offensive)\n"
                    f"`{ctx.prefix}ptbr expression` - Expressões comuns\n"
                    f"`{ctx.prefix}ptbr translate` - Traduzir para português"
                ),
                inline=False
            )
            
            # Set footer
            embed.set_footer(text="Bandeira do Brasil 🇧🇷")
            
            await ctx.send(embed=embed)
    
    @ptbr.command(name="help")
    async def ptbr_help(self, ctx):
        """
        Show help for Brazilian Portuguese commands
        Usage: !ptbr help
        """
        embed = discord.Embed(
            title="🇧🇷 Ajuda: Comandos em Português",
            description="Lista de todos os comandos disponíveis em português brasileiro.",
            color=discord.Color.green()
        )
        
        commands = [
            {"name": "greet", "desc": "Mostra uma saudação aleatória em português brasileiro."},
            {"name": "slang", "desc": "Mostra gírias brasileiras com suas traduções."},
            {"name": "joke", "desc": "Conta uma piada brasileira aleatória. Tipos: `regular`, `dark`, `sarcastic`, `offensive`"},
            {"name": "joke dark", "desc": "Conta uma piada de humor negro em português."},
            {"name": "joke sarcastic", "desc": "Conta uma piada sarcástica em português."},
            {"name": "joke offensive", "desc": "Conta uma piada politicamente incorreta (⚠️ pode conter conteúdo ofensivo)."},
            {"name": "expression", "desc": "Mostra expressões comuns brasileiras."},
            {"name": "translate", "desc": "Traduz texto para português brasileiro."}
        ]
        
        for cmd in commands:
            embed.add_field(
                name=f"{ctx.prefix}ptbr {cmd['name']}",
                value=cmd['desc'],
                inline=False
            )
        
        embed.set_footer(text=f"Use {ctx.prefix}ptbr [comando] para executar")
        await ctx.send(embed=embed)
    
    @ptbr.command(name="greet")
    async def ptbr_greet(self, ctx):
        """
        Get a random Brazilian Portuguese greeting
        Usage: !ptbr greet
        """
        greeting = random.choice(PT_BR_GREETINGS)
        current_time = datetime.now().strftime("%H:%M")
        
        embed = discord.Embed(
            title="🇧🇷 Saudação em Português",
            description=f"**{greeting}**, {ctx.author.mention}!",
            color=discord.Color.green()
        )
        
        # Add time-based greeting
        hour = datetime.now().hour
        if 5 <= hour < 12:
            time_greeting = "Bom dia!"
        elif 12 <= hour < 18:
            time_greeting = "Boa tarde!"
        else:
            time_greeting = "Boa noite!"
        
        embed.add_field(
            name="Horário",
            value=f"{time_greeting} Agora são {current_time}.",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @ptbr.command(name="slang")
    async def ptbr_slang(self, ctx, *, specific_slang=None):
        """
        Get Brazilian Portuguese slang with translations
        Usage: !ptbr slang [specific_slang]
        """
        if specific_slang:
            specific_slang = specific_slang.capitalize()
            if specific_slang in PT_BR_SLANG:
                embed = discord.Embed(
                    title=f"🇧🇷 Gíria: {specific_slang}",
                    description=f"**Significado:** {PT_BR_SLANG[specific_slang]}",
                    color=discord.Color.green()
                )
                await ctx.send(embed=embed)
            else:
                similar_slangs = [slang for slang in PT_BR_SLANG if specific_slang.lower() in slang.lower()]
                
                if similar_slangs:
                    embed = discord.Embed(
                        title="🇧🇷 Gírias Similares",
                        description=f"Não encontrei '{specific_slang}', mas encontrei estas:",
                        color=discord.Color.gold()
                    )
                    
                    for slang in similar_slangs:
                        embed.add_field(
                            name=slang,
                            value=PT_BR_SLANG[slang],
                            inline=False
                        )
                else:
                    embed = discord.Embed(
                        title="🇧🇷 Gíria Não Encontrada",
                        description=f"Desculpe, não encontrei a gíria '{specific_slang}'.",
                        color=discord.Color.red()
                    )
                    
                    # Suggest some random slangs
                    random_slangs = random.sample(list(PT_BR_SLANG.items()), min(3, len(PT_BR_SLANG)))
                    slang_list = "\n".join([f"• **{s}**: {m}" for s, m in random_slangs])
                    
                    embed.add_field(
                        name="Tente estas gírias:",
                        value=slang_list,
                        inline=False
                    )
                
                await ctx.send(embed=embed)
        else:
            # Show random selection of slangs
            sample_size = min(5, len(PT_BR_SLANG))
            selected_slangs = random.sample(list(PT_BR_SLANG.items()), sample_size)
            
            embed = discord.Embed(
                title="🇧🇷 Gírias Brasileiras",
                description="Algumas gírias populares do Brasil com suas traduções:",
                color=discord.Color.green()
            )
            
            for slang, meaning in selected_slangs:
                embed.add_field(
                    name=slang,
                    value=meaning,
                    inline=False
                )
            
            embed.set_footer(text=f"Use {ctx.prefix}ptbr slang [gíria] para ver uma específica")
            await ctx.send(embed=embed)
    
    @ptbr.command(name="joke")
    async def ptbr_joke(self, ctx, joke_type: str = None):
        """
        Get a random Brazilian Portuguese joke, with optional type specification
        Usage: !ptbr joke [tipo]
        Tipos disponíveis: regular, dark, sarcastic, offensive
        """
        # Log command usage
        logger.info(f"Joke command used by {ctx.author.name}")
        
        # Select joke category
        if joke_type:
            joke_type = joke_type.lower()
            # Mostrar aviso para piadas ofensivas
            if joke_type == "offensive":
                warning_embed = discord.Embed(
                    title="⚠️ Aviso: Conteúdo Potencialmente Ofensivo",
                    description="As piadas da categoria 'offensive' podem conter conteúdo ofensivo e controverso, incluindo estereótipos, preconceitos e humor questionável. Você deseja continuar?",
                    color=discord.Color.orange()
                )
                warning_embed.set_footer(text="Estas piadas são apenas para entretenimento e não refletem as opiniões do bot ou seus criadores.")
                warning_msg = await ctx.send(embed=warning_embed)
                
                # Adicionar reações para sim/não
                await warning_msg.add_reaction("✅")  # Sim
                await warning_msg.add_reaction("❌")  # Não
                
                def check(reaction, user):
                    return user == ctx.author and str(reaction.emoji) in ["✅", "❌"] and reaction.message.id == warning_msg.id
                
                try:
                    reaction, user = await self.bot.wait_for('reaction_add', timeout=60.0, check=check)
                    if str(reaction.emoji) == "❌":
                        cancel_embed = discord.Embed(
                            title="Solicitação Cancelada",
                            description="Piada ofensiva cancelada. Que tal tentar um tipo diferente de piada?",
                            color=discord.Color.blue()
                        )
                        await ctx.send(embed=cancel_embed)
                        return
                    # Se chegou aqui, o usuário confirmou que quer ver a piada
                except asyncio.TimeoutError:
                    timeout_embed = discord.Embed(
                        title="Tempo Esgotado",
                        description="Não houve resposta dentro do tempo limite. Solicitação cancelada.",
                        color=discord.Color.red()
                    )
                    await ctx.send(embed=timeout_embed)
                    return
            
            # Verificar se o tipo é válido
            if joke_type not in PT_BR_JOKES:
                # If invalid type provided, show available options
                available_types = ", ".join([f"`{t}`" for t in PT_BR_JOKES.keys()])
                embed = discord.Embed(
                    title="🇧🇷 Tipo de Piada Inválido",
                    description=f"Tipo de piada `{joke_type}` não encontrado. Tipos disponíveis: {available_types}",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed)
        else:
            # Default to regular jokes when no type specified
            # Não incluir "offensive" na seleção aleatória padrão
            joke_type = random.choice([t for t in PT_BR_JOKES.keys() if t != "offensive"])
        
        # Get a random joke from the selected category
        joke = random.choice(PT_BR_JOKES[joke_type])
        
        # Define emoji and color based on joke type
        emoji_footer = {
            "regular": "😂 Engraçado, né?",
            "dark": "💀 Humor negro...",
            "sarcastic": "😏 A ironia é deliciosa!",
            "offensive": "🔞 Conteúdo controverso!"
        }
        
        color_map = {
            "regular": discord.Color.green(),
            "dark": discord.Color.dark_purple(),
            "sarcastic": discord.Color.gold(),
            "offensive": discord.Color.red()
        }
        
        # Create title based on type
        title_map = {
            "regular": "🇧🇷 Piada Brasileira",
            "dark": "🇧🇷 Piada de Humor Negro",
            "sarcastic": "🇧🇷 Piada Sarcástica",
            "offensive": "🇧🇷 Piada Politicamente Incorreta"
        }
        
        embed = discord.Embed(
            title=title_map[joke_type],
            description=joke,
            color=color_map[joke_type]
        )
        
        embed.set_footer(text=emoji_footer[joke_type])
        await ctx.send(embed=embed)
    
    @ptbr.command(name="expression")
    async def ptbr_expression(self, ctx):
        """
        Get a random Brazilian Portuguese expression
        Usage: !ptbr expression
        """
        expression = random.choice(PT_BR_EXPRESSIONS)
        
        embed = discord.Embed(
            title="🇧🇷 Expressão Brasileira",
            description=f"**{expression}**",
            color=discord.Color.green()
        )
        
        # Add a context explanation
        contexts = {
            "Nossa Senhora!": "Expressão de surpresa ou espanto",
            "Meu Deus!": "Expressão de surpresa ou espanto",
            "Que legal!": "Expressão de aprovação ou entusiasmo",
            "Sério mesmo?": "Expressão de dúvida ou surpresa",
            "Não acredito!": "Expressão de surpresa ou incredulidade",
            "Puts grila!": "Expressão de frustração ou surpresa (comum em São Paulo)",
            "Caramba!": "Expressão de surpresa ou espanto",
            "Que massa!": "Expressão de aprovação (comum no Nordeste)",
            "Que dahora!": "Expressão de aprovação (gíria)",
            "Eita!": "Expressão de surpresa (comum no Nordeste)",
            "Vixe!": "Expressão de preocupação ou surpresa",
            "Puxa vida!": "Expressão mais suave de surpresa",
            "Meu!": "Expressão usada como pontuação (São Paulo)",
            "Véi!": "Expressão usada como pontuação (Brasília/DF)",
            "Ó!": "Expressão para chamar atenção"
        }
        
        explanation = contexts.get(expression, "Expressão comum no português brasileiro")
        
        embed.add_field(
            name="Contexto",
            value=explanation,
            inline=False
        )
        
        embed.set_footer(text="Expressões brasileiras são muito expressivas! 🇧🇷")
        await ctx.send(embed=embed)
    
    @ptbr.command(name="translate")
    async def ptbr_translate(self, ctx, *, text=None):
        """
        Translate text to Brazilian Portuguese
        Usage: !ptbr translate [text]
        """
        if not text:
            await ctx.send("❌ Por favor, forneça um texto para traduzir. Exemplo: `!ptbr translate hello world`")
            return
        
        # Simple translations dictionary for common phrases
        translations = {
            "hello": "olá",
            "hi": "oi",
            "goodbye": "tchau",
            "thank you": "obrigado",
            "thanks": "valeu",
            "please": "por favor",
            "yes": "sim",
            "no": "não",
            "good morning": "bom dia",
            "good afternoon": "boa tarde",
            "good night": "boa noite",
            "how are you": "como você está",
            "fine": "bem",
            "what's up": "e aí",
            "cool": "legal",
            "awesome": "incrível",
            "friend": "amigo",
            "friends": "amigos",
            "food": "comida",
            "water": "água",
            "help": "ajuda",
            "time": "tempo",
            "day": "dia",
            "night": "noite",
            "today": "hoje",
            "tomorrow": "amanhã",
            "yesterday": "ontem",
            "money": "dinheiro",
            "work": "trabalho",
            "house": "casa",
            "car": "carro",
            "book": "livro",
            "love": "amor",
            "happy": "feliz",
            "sad": "triste",
            "big": "grande",
            "small": "pequeno",
            "beautiful": "bonito",
            "ugly": "feio",
            "good": "bom",
            "bad": "ruim",
            "hot": "quente",
            "cold": "frio",
            "new": "novo",
            "old": "velho",
            "open": "aberto",
            "closed": "fechado",
            "fast": "rápido",
            "slow": "lento",
            "easy": "fácil",
            "difficult": "difícil",
            "right": "direito",
            "left": "esquerdo",
            "up": "para cima",
            "down": "para baixo",
            "welcome": "bem-vindo"
        }
        
        # Check if the text is in our simple dictionary
        lower_text = text.lower()
        if lower_text in translations:
            translated = translations[lower_text]
            embed = discord.Embed(
                title="🇧🇷 Tradução",
                description=f"**Original:** {text}\n**Tradução:** {translated}",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            return
        
        # For longer phrases, we need to break it down
        words = lower_text.split()
        translated_words = []
        
        for word in words:
            if word in translations:
                translated_words.append(translations[word])
            else:
                # Keep original if no translation
                translated_words.append(word)
        
        translated_text = " ".join(translated_words)
        
        # Check if any words were translated
        if translated_text != lower_text:
            embed = discord.Embed(
                title="🇧🇷 Tradução Básica",
                description=f"**Original:** {text}\n**Tradução:** {translated_text}",
                color=discord.Color.green()
            )
            
            # Add note about limitations
            if any(word not in translations for word in words):
                embed.set_footer(text="Nota: Algumas palavras não foram traduzidas devido a limitações do dicionário.")
        else:
            embed = discord.Embed(
                title="🇧🇷 Tradução Não Disponível",
                description="Desculpe, não consegui traduzir este texto com meu dicionário básico.",
                color=discord.Color.gold()
            )
            
            # Suggest some common translations
            embed.add_field(
                name="Traduções Comuns",
                value="\n".join([
                    "• Hello → Olá",
                    "• Thank you → Obrigado",
                    "• How are you? → Como você está?",
                    "• Good morning → Bom dia",
                    "• I love Brazil → Eu amo o Brasil"
                ]),
                inline=False
            )
        
        await ctx.send(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message):
        # Don't respond to bot messages
        if message.author.bot:
            return
        
        # Check if message is in Portuguese
        # This is a very simple check, just looking for common Portuguese words
        pt_indicators = ["você", "obrigado", "bom dia", "boa tarde", "boa noite", "como vai", 
                         "tudo bem", "sim", "não", "por favor", "olá", "oi", "tchau"]
        
        content_lower = message.content.lower()
        
        # If message contains Portuguese indicators and has no command prefix, respond in Portuguese occasionally
        if any(indicator in content_lower for indicator in pt_indicators) and not content_lower.startswith("!"):
            # Only respond 10% of the time to avoid being annoying
            if random.random() < 0.1:
                # Choose random Portuguese response
                response_type = random.choice(["greeting", "expression"])
                
                if response_type == "greeting":
                    response = random.choice(PT_BR_GREETINGS)
                else:
                    response = random.choice(PT_BR_EXPRESSIONS)
                
                await message.channel.send(f"{response} {message.author.mention}")
                logger.info(f"Responded in Portuguese to {message.author}")

async def setup(bot):
    await bot.add_cog(Language(bot))