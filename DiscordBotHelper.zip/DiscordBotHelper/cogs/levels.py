"""
Level and experience system for the Discord bot.
Allows users to gain XP from messages and activities, level up, and receive rewards.
"""
import discord
from discord.ext import commands
import logging
import json
import os
import random
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union, Tuple
import io
from PIL import Image, ImageDraw, ImageFont
import requests
from io import BytesIO

logger = logging.getLogger(__name__)

class Levels(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.levels_data_file = "levels_data.json"
        self.levels_data = self.load_levels_data()
        
        # XP gain settings
        self.xp_settings = {
            "message_xp": (15, 25),           # Random XP range for each message
            "message_cooldown": 60,           # Cooldown in seconds between XP from messages
            "voice_xp_interval": 5 * 60,      # Award XP every 5 minutes in voice channels
            "voice_xp": (30, 50),             # Random XP range for voice activity
            "command_xp": 5,                  # XP for using a command
            "emoji_reaction_xp": 2,           # XP for adding/receiving a reaction
            "daily_bonus_xp": 100,            # XP for daily streak
            "participation_xp": 50,           # XP for participating in events
        }
        
        # XP needed per level (increases with each level)
        self.level_xp_requirements = {}
        for level in range(1, 101):
            # Formula: 100 * level^1.5 (gets progressively harder to level up)
            self.level_xp_requirements[level] = int(100 * (level ** 1.5))
        
        # Role rewards configuration (level: role_id)
        # This will be loaded from server settings
        self.role_rewards = {}
        
        # Color themes for level cards
        self.card_themes = {
            "default": {
                "background": (44, 47, 51),   # Discord dark theme
                "progress_bg": (32, 34, 37),  # Darker shade
                "progress_fill": (114, 137, 218),  # Discord blurple
                "text_primary": (255, 255, 255),  # White
                "text_secondary": (153, 170, 181),  # Light gray
                "border": (114, 137, 218)     # Discord blurple
            },
            "blue": {
                "background": (25, 93, 171),
                "progress_bg": (18, 69, 128),
                "progress_fill": (46, 144, 250),
                "text_primary": (255, 255, 255),
                "text_secondary": (184, 216, 255),
                "border": (46, 144, 250)
            },
            "green": {
                "background": (29, 112, 68),
                "progress_bg": (22, 83, 51),
                "progress_fill": (50, 168, 103),
                "text_primary": (255, 255, 255),
                "text_secondary": (184, 255, 207),
                "border": (50, 168, 103)
            },
            "red": {
                "background": (171, 48, 48),
                "progress_bg": (136, 34, 34),
                "progress_fill": (235, 77, 77),
                "text_primary": (255, 255, 255),
                "text_secondary": (255, 184, 184),
                "border": (235, 77, 77)
            },
            "purple": {
                "background": (95, 39, 138),
                "progress_bg": (71, 28, 104),
                "progress_fill": (149, 72, 207),
                "text_primary": (255, 255, 255),
                "text_secondary": (226, 184, 255),
                "border": (149, 72, 207)
            },
            "gold": {
                "background": (141, 108, 43),
                "progress_bg": (107, 81, 30),
                "progress_fill": (212, 175, 55),
                "text_primary": (255, 255, 255),
                "text_secondary": (255, 241, 184),
                "border": (212, 175, 55)
            }
        }
        
        # Multipliers and boosts
        self.global_boost_active = False
        self.global_boost_multiplier = 1.0
        self.global_boost_end_time = None
        
        # Start XP loop for voice channels
        self.voice_xp_task = self.bot.loop.create_task(self.check_voice_channels())
        
    def cog_unload(self):
        # Cancel the task when the cog is unloaded
        if self.voice_xp_task:
            self.voice_xp_task.cancel()
            
    def load_levels_data(self):
        """Load levels data from JSON file"""
        if os.path.exists(self.levels_data_file):
            try:
                with open(self.levels_data_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading levels data: {e}")
                return {}
        return {}
    
    def save_levels_data(self):
        """Save levels data to JSON file"""
        try:
            with open(self.levels_data_file, "w", encoding="utf-8") as f:
                json.dump(self.levels_data, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving levels data: {e}")
    
    def get_user_data(self, user_id: int, guild_id: int) -> Dict:
        """Get or create user data for the specified guild"""
        str_user_id = str(user_id)
        str_guild_id = str(guild_id)
        
        # Ensure guild entry exists
        if str_guild_id not in self.levels_data:
            self.levels_data[str_guild_id] = {
                "users": {},
                "settings": {
                    "enabled": True,
                    "level_up_messages": True,
                    "level_up_channel": None,  # If None, send to the same channel
                    "role_rewards": {},
                    "boost_channels": [],
                    "ignore_channels": []
                }
            }
        
        # Ensure user entry exists for this guild
        if str_user_id not in self.levels_data[str_guild_id]["users"]:
            self.levels_data[str_guild_id]["users"][str_user_id] = {
                "xp": 0,
                "level": 1,
                "total_xp": 0,  # Lifetime XP
                "last_message_time": None,
                "messages": 0,
                "voice_time": 0,  # Time in voice channels (minutes)
                "commands_used": 0,
                "theme": "default",
                "background_url": None,  # Custom background URL
                "card_color": None,  # Custom color if not using theme
                "card_text": None,  # Custom text to display on level card
                "bonuses": {}  # Active XP bonuses
            }
            self.save_levels_data()
        
        return self.levels_data[str_guild_id]["users"][str_user_id]
    
    def get_guild_settings(self, guild_id: int) -> Dict:
        """Get guild level settings"""
        str_guild_id = str(guild_id)
        
        # Ensure guild entry exists with default settings
        if str_guild_id not in self.levels_data:
            self.levels_data[str_guild_id] = {
                "users": {},
                "settings": {
                    "enabled": True,
                    "level_up_messages": True,
                    "level_up_channel": None,
                    "role_rewards": {},
                    "boost_channels": [],
                    "ignore_channels": []
                }
            }
            self.save_levels_data()
        
        return self.levels_data[str_guild_id]["settings"]
    
    def add_xp(self, user_id: int, guild_id: int, amount: int) -> Tuple[int, bool]:
        """
        Add XP to user and handle level-ups
        Returns (new_level, leveled_up)
        """
        user_data = self.get_user_data(user_id, guild_id)
        
        # Apply bonuses if any
        bonus_multiplier = 1.0
        current_time = datetime.now().timestamp()
        
        # Check individual bonuses
        for bonus_name, bonus_data in user_data.get("bonuses", {}).items():
            if bonus_data["end_time"] > current_time:
                bonus_multiplier *= bonus_data["multiplier"]
            else:
                # Remove expired bonus
                del user_data["bonuses"][bonus_name]
        
        # Apply global boost if active
        if self.global_boost_active and (self.global_boost_end_time is None or 
                                        self.global_boost_end_time > current_time):
            bonus_multiplier *= self.global_boost_multiplier
            
        # Check for economy XP boost (integration with economy system)
        try:
            # Try to get the economy cog for XP boost integration
            economy_cog = self.bot.get_cog("Economy")
            if economy_cog:
                # Check if user has active XP boost from the shop
                economy_data = economy_cog.get_user_data(user_id)
                if "active_buffs" in economy_data and "xp_boost" in economy_data["active_buffs"]:
                    boost_data = economy_data["active_buffs"]["xp_boost"]
                    
                    # Check if boost is still active
                    boost_expire_time = datetime.fromisoformat(boost_data["expires"]).timestamp()
                    if boost_expire_time > current_time:
                        # Apply the XP boost multiplier from the shop item
                        bonus_multiplier *= boost_data["multiplier"]
                        logger.info(f"Applied economy XP boost for user {user_id}: {boost_data['multiplier']}x")
                    else:
                        # Remove expired boost
                        del economy_data["active_buffs"]["xp_boost"]
                        economy_cog.save_economy_data()
        except Exception as e:
            logger.error(f"Error checking economy XP boost: {e}")
        
        # Calculate final XP
        final_xp = int(amount * bonus_multiplier)
        
        # Update user data
        user_data["xp"] += final_xp
        user_data["total_xp"] += final_xp
        
        # Check for level up
        current_level = user_data["level"]
        leveled_up = False
        
        while (current_level + 1) in self.level_xp_requirements and \
                user_data["xp"] >= self.level_xp_requirements[current_level + 1]:
            # Level up!
            current_level += 1
            leveled_up = True
        
        if leveled_up:
            user_data["level"] = current_level
            
        self.save_levels_data()
        return (current_level, leveled_up)
    
    def get_level_progress(self, user_id: int, guild_id: int) -> Tuple[int, int, float]:
        """
        Get user's progress toward next level
        Returns (current_xp, xp_needed, progress_percentage)
        """
        user_data = self.get_user_data(user_id, guild_id)
        current_level = user_data["level"]
        current_xp = user_data["xp"]
        
        # Calculate XP for next level
        if (current_level + 1) in self.level_xp_requirements:
            xp_needed = self.level_xp_requirements[current_level + 1]
            xp_current_level = self.level_xp_requirements.get(current_level, 0)
            relative_xp = current_xp - xp_current_level
            remaining_xp = xp_needed - xp_current_level
            progress = relative_xp / remaining_xp if remaining_xp > 0 else 1.0
        else:
            # Max level reached
            xp_needed = 0
            progress = 1.0
            
        return (current_xp, xp_needed, progress)
    
    def get_rank(self, user_id: int, guild_id: int) -> int:
        """Get user's rank in the server based on total XP"""
        str_guild_id = str(guild_id)
        str_user_id = str(user_id)
        
        if str_guild_id not in self.levels_data or \
           str_user_id not in self.levels_data[str_guild_id]["users"]:
            return 0
        
        # Sort users by total XP
        users = self.levels_data[str_guild_id]["users"]
        sorted_users = sorted(users.items(), key=lambda x: x[1]["total_xp"], reverse=True)
        
        # Find user's position
        for i, (uid, _) in enumerate(sorted_users):
            if uid == str_user_id:
                return i + 1  # Rank is 1-indexed
        
        return 0
    
    def get_leaderboard(self, guild_id: int, limit: int = 10) -> List[Tuple[int, Dict]]:
        """Get the top users by XP for a guild"""
        str_guild_id = str(guild_id)
        
        if str_guild_id not in self.levels_data:
            return []
        
        # Sort users by total XP
        users = self.levels_data[str_guild_id]["users"]
        sorted_users = sorted(users.items(), key=lambda x: x[1]["total_xp"], reverse=True)
        
        # Convert to list of (user_id, data) tuples
        return [(int(user_id), data) for user_id, data in sorted_users[:limit]]
    
    def add_user_bonus(self, user_id: int, guild_id: int, bonus_name: str, 
                      multiplier: float, duration_hours: float) -> None:
        """Add a temporary XP boost to a user"""
        user_data = self.get_user_data(user_id, guild_id)
        
        if "bonuses" not in user_data:
            user_data["bonuses"] = {}
        
        # Set bonus with expiration time
        end_time = datetime.now() + timedelta(hours=duration_hours)
        user_data["bonuses"][bonus_name] = {
            "multiplier": multiplier,
            "end_time": end_time.timestamp()
        }
        
        self.save_levels_data()
    
    def set_global_boost(self, multiplier: float, duration_hours: Optional[float] = None) -> None:
        """Set a global XP boost for all users"""
        self.global_boost_active = True
        self.global_boost_multiplier = multiplier
        
        if duration_hours:
            end_time = datetime.now() + timedelta(hours=duration_hours)
            self.global_boost_end_time = end_time.timestamp()
        else:
            self.global_boost_end_time = None
    
    def end_global_boost(self) -> None:
        """End the global XP boost"""
        self.global_boost_active = False
        self.global_boost_multiplier = 1.0
        self.global_boost_end_time = None
    
    async def check_voice_channels(self) -> None:
        """Periodically check voice channels and award XP to active users"""
        await self.bot.wait_until_ready()
        
        while not self.bot.is_closed():
            try:
                # Iterate through all guilds
                for guild in self.bot.guilds:
                    # Get guild settings
                    settings = self.get_guild_settings(guild.id)
                    
                    if not settings["enabled"]:
                        continue
                    
                    # Check each voice channel in the guild
                    for voice_channel in guild.voice_channels:
                        # Skip ignored channels
                        if str(voice_channel.id) in settings.get("ignore_channels", []):
                            continue
                        
                        # Award XP to each member in the voice channel
                        for member in voice_channel.members:
                            # Skip bots
                            if member.bot:
                                continue
                                
                            # Skip users who are muted or deafened (AFK)
                            if member.voice.self_mute and member.voice.self_deaf:
                                continue
                            
                            # Award XP
                            xp_amount = random.randint(*self.xp_settings["voice_xp"])
                            
                            # Check if channel has boost
                            if str(voice_channel.id) in settings.get("boost_channels", []):
                                xp_amount = int(xp_amount * 1.5)  # 50% boost
                            
                            # Add XP without sending level-up messages
                            self.add_xp(member.id, guild.id, xp_amount)
                            
                            # Update voice time (in minutes)
                            user_data = self.get_user_data(member.id, guild.id)
                            user_data["voice_time"] += self.xp_settings["voice_xp_interval"] / 60
                            self.save_levels_data()
                
                # Wait for next check
                await asyncio.sleep(self.xp_settings["voice_xp_interval"])
                
            except Exception as e:
                logger.error(f"Error in voice XP task: {e}")
                await asyncio.sleep(60)  # Wait a minute before retrying
    
    async def create_level_card(self, user_id: int, guild_id: int) -> discord.File:
        """Create and return a level card image for the user"""
        user = await self.bot.fetch_user(user_id)
        guild = self.bot.get_guild(guild_id)
        member = guild.get_member(user_id)
        
        # Get user's level data
        user_data = self.get_user_data(user_id, guild_id)
        level = user_data["level"]
        rank = self.get_rank(user_id, guild_id)
        xp, next_level_xp, progress = self.get_level_progress(user_id, guild_id)
        
        # Get theme colors
        theme_name = user_data.get("theme", "default")
        if theme_name not in self.card_themes:
            theme_name = "default"
        theme = self.card_themes[theme_name]
        
        # Create base image (500x200 px)
        img = Image.new('RGB', (800, 250), color=theme["background"])
        draw = ImageDraw.Draw(img)
        
        # Load fonts
        try:
            title_font = ImageFont.truetype("arial.ttf", 38)
            subtitle_font = ImageFont.truetype("arial.ttf", 28)
            small_font = ImageFont.truetype("arial.ttf", 20)
        except:
            # Fallback to default font
            title_font = ImageFont.load_default()
            subtitle_font = ImageFont.load_default()
            small_font = ImageFont.load_default()
        
        # Try to get user avatar
        try:
            avatar_url = user.avatar.url
            response = requests.get(avatar_url)
            avatar_img = Image.open(BytesIO(response.content))
            avatar_img = avatar_img.resize((180, 180))
            
            # Create circular mask for avatar
            mask = Image.new('L', (180, 180), 0)
            mask_draw = ImageDraw.Draw(mask)
            mask_draw.ellipse((0, 0, 180, 180), fill=255)
            
            # Apply the mask to the avatar
            img.paste(avatar_img, (30, 35), mask)
        except:
            # Draw placeholder circle if avatar can't be loaded
            draw.ellipse((30, 35, 210, 215), fill=theme["border"])
        
        # Draw card border
        draw.rectangle((0, 0, 799, 249), outline=theme["border"], width=5)
        
        # Draw username and discriminator
        draw.text((250, 50), user.name, fill=theme["text_primary"], font=title_font)
        if hasattr(user, 'discriminator') and user.discriminator != '0':
            draw.text((250, 95), f"#{user.discriminator}", fill=theme["text_secondary"], font=small_font)
        
        # Draw level and rank
        draw.text((250, 140), f"Level: {level}", fill=theme["text_primary"], font=subtitle_font)
        draw.text((400, 140), f"Rank: #{rank}", fill=theme["text_primary"], font=subtitle_font)
        
        # Draw XP bar background
        bar_length = 520
        draw.rectangle((250, 190, 250 + bar_length, 220), fill=theme["progress_bg"], width=0)
        
        # Draw progress bar
        progress_width = int(bar_length * progress)
        draw.rectangle((250, 190, 250 + progress_width, 220), fill=theme["progress_fill"], width=0)
        
        # Draw XP text
        xp_text = f"XP: {xp}/{next_level_xp}" if next_level_xp > 0 else f"XP: {xp}/MAX"
        text_w = draw.textlength(xp_text, font=small_font)
        draw.text((250 + (bar_length - text_w) // 2, 195), xp_text, fill=theme["text_primary"], font=small_font)
        
        # Add custom text if available
        if user_data.get("card_text"):
            draw.text((30, 220), user_data["card_text"], fill=theme["text_secondary"], font=small_font)
        
        # Convert image to bytes
        buffer = BytesIO()
        img.save(buffer, format="PNG")
        buffer.seek(0)
        
        return discord.File(buffer, filename="level_card.png")
    
    @commands.Cog.listener()
    async def on_message(self, message):
        # Skip if message is from a bot
        if message.author.bot:
            return
        
        # Skip if not in a guild
        if not message.guild:
            return
        
        # Get guild settings
        settings = self.get_guild_settings(message.guild.id)
        
        # Skip if levels are disabled for this guild
        if not settings.get("enabled", True):
            return
        
        # Skip if channel is in ignore list
        if str(message.channel.id) in settings.get("ignore_channels", []):
            return
        
        # Check cooldown
        user_data = self.get_user_data(message.author.id, message.guild.id)
        last_message_time = user_data.get("last_message_time")
        
        if last_message_time is None or \
           datetime.now().timestamp() - last_message_time > self.xp_settings["message_cooldown"]:
            
            # Award XP
            xp_amount = random.randint(*self.xp_settings["message_xp"])
            
            # Check if channel has boost
            if str(message.channel.id) in settings.get("boost_channels", []):
                xp_amount = int(xp_amount * 1.5)  # 50% boost
            
            # Add XP and check for level up
            new_level, leveled_up = self.add_xp(message.author.id, message.guild.id, xp_amount)
            
            # Update message count and last message time
            user_data["messages"] = user_data.get("messages", 0) + 1
            user_data["last_message_time"] = datetime.now().timestamp()
            self.save_levels_data()
            
            # Handle level up
            if leveled_up and settings.get("level_up_messages", True):
                # Check if we should send to a specific channel
                if settings.get("level_up_channel") is not None:
                    target_channel = self.bot.get_channel(int(settings["level_up_channel"]))
                else:
                    target_channel = message.channel
                
                if target_channel:
                    # Generate level card
                    try:
                        level_card = await self.create_level_card(message.author.id, message.guild.id)
                        await target_channel.send(
                            f"🎉 **{message.author.mention} subiu para o nível {new_level}!**",
                            file=level_card
                        )
                    except:
                        # Fallback to text message if image generation fails
                        await target_channel.send(
                            f"🎉 **{message.author.mention} subiu para o nível {new_level}!**"
                        )
                
                # Check for role rewards
                role_rewards = settings.get("role_rewards", {})
                if str(new_level) in role_rewards:
                    role_id = int(role_rewards[str(new_level)])
                    role = message.guild.get_role(role_id)
                    
                    if role:
                        try:
                            await message.author.add_roles(role)
                            await target_channel.send(
                                f"🏆 **{message.author.mention} ganhou o cargo {role.name}!**"
                            )
                        except:
                            logger.error(f"Failed to assign role {role.name} to {message.author}")
    
    @commands.Cog.listener()
    async def on_command(self, ctx):
        """Award XP when a user uses a command"""
        # Skip if from a bot or in DM
        if ctx.author.bot or not ctx.guild:
            return
        
        # Get guild settings
        settings = self.get_guild_settings(ctx.guild.id)
        
        # Skip if levels are disabled for this guild
        if not settings.get("enabled", True):
            return
        
        # Award XP for using a command
        xp_amount = self.xp_settings["command_xp"]
        
        # Add XP without checking for level up messages
        self.add_xp(ctx.author.id, ctx.guild.id, xp_amount)
        
        # Update commands used count
        user_data = self.get_user_data(ctx.author.id, ctx.guild.id)
        user_data["commands_used"] = user_data.get("commands_used", 0) + 1
        self.save_levels_data()
    
    @commands.command(name="rank", aliases=["level"])
    async def rank_command(self, ctx, member: discord.Member = None):
        """
        Mostra o nível e XP de um usuário
        Usage: !rank [membro]
        """
        target = member or ctx.author
        
        if target.bot:
            await ctx.send("❌ Bots não possuem níveis.")
            return
        
        try:
            # Generate and send level card
            level_card = await self.create_level_card(target.id, ctx.guild.id)
            await ctx.send(file=level_card)
        except Exception as e:
            # Fallback to text response
            logger.error(f"Error creating level card: {e}")
            user_data = self.get_user_data(target.id, ctx.guild.id)
            level = user_data["level"]
            rank = self.get_rank(target.id, ctx.guild.id)
            xp, next_level_xp, progress = self.get_level_progress(target.id, ctx.guild.id)
            
            progress_bar = self.generate_text_progress_bar(progress)
            
            embed = discord.Embed(
                title=f"Nível de {target.display_name}",
                description=f"**Nível:** {level}\n**Rank:** #{rank}\n\n**XP:** {xp}/{next_level_xp}\n{progress_bar}",
                color=discord.Color.blue()
            )
            
            if target.avatar:
                embed.set_thumbnail(url=target.avatar.url)
            
            await ctx.send(embed=embed)
    
    def generate_text_progress_bar(self, progress, length=20):
        """Generate a text progress bar for fallback display"""
        filled_length = int(length * progress)
        bar = '█' * filled_length + '░' * (length - filled_length)
        return bar
    
    @commands.command(name="xpranking", aliases=["xptop", "levels"])
    async def xp_ranking_command(self, ctx, page: int = 1):
        """
        Mostra os membros com mais XP no servidor
        Usage: !xpranking [página]
        """
        if page < 1:
            page = 1
        
        per_page = 10
        start_idx = (page - 1) * per_page
        
        # Get leaderboard data
        leaderboard = self.get_leaderboard(ctx.guild.id, limit=100)
        
        if not leaderboard:
            await ctx.send("❌ Ainda não há dados de níveis para este servidor.")
            return
        
        # Slice for pagination
        page_data = leaderboard[start_idx:start_idx + per_page]
        
        if not page_data:
            await ctx.send(f"❌ Página {page} não existe. O leaderboard tem {len(leaderboard) // per_page + 1} páginas.")
            return
        
        # Create embed
        embed = discord.Embed(
            title=f"🏆 Ranking de XP de {ctx.guild.name}",
            description=f"Os membros com mais XP no servidor (Página {page}/{len(leaderboard) // per_page + 1})",
            color=discord.Color.gold()
        )
        
        # Add leaderboard entries
        for idx, (user_id, data) in enumerate(page_data, start=start_idx + 1):
            try:
                member = ctx.guild.get_member(user_id)
                name = member.display_name if member else f"Usuário {user_id}"
                
                # Format entry based on rank
                if idx == 1:
                    prefix = "🥇"
                elif idx == 2:
                    prefix = "🥈"
                elif idx == 3:
                    prefix = "🥉"
                else:
                    prefix = f"#{idx}"
                
                embed.add_field(
                    name=f"{prefix} {name}",
                    value=f"**Nível:** {data['level']} | **XP:** {data['total_xp']}",
                    inline=False
                )
            except Exception as e:
                logger.error(f"Error adding leaderboard entry: {e}")
        
        # Set footer
        embed.set_footer(text=f"Use !xpranking [página] para ver mais")
        
        await ctx.send(embed=embed)
    
    @commands.command(name="givexp", aliases=["addxp"])
    @commands.has_permissions(administrator=True)
    async def give_xp(self, ctx, member: discord.Member, amount: int):
        """
        Dá XP para um membro (Apenas para Administradores)
        Usage: !givexp <@membro> <quantidade>
        """
        if member.bot:
            await ctx.send("❌ Não é possível dar XP para bots.")
            return
        
        if amount <= 0:
            await ctx.send("❌ A quantidade de XP deve ser positiva.")
            return
        
        # Add XP
        new_level, leveled_up = self.add_xp(member.id, ctx.guild.id, amount)
        
        # Send confirmation
        await ctx.send(f"✅ Adicionado **{amount} XP** para {member.mention}!")
        
        # If leveled up, show the new level
        if leveled_up:
            await ctx.send(f"🎉 {member.mention} subiu para o nível **{new_level}**!")
    
    @commands.group(name="levelsettings", aliases=["levelconfig"])
    @commands.has_permissions(administrator=True)
    async def level_settings(self, ctx):
        """
        Configurações do sistema de níveis (Apenas para Administradores)
        Usage: !levelsettings <subcomando>
        """
        if ctx.invoked_subcommand is None:
            settings = self.get_guild_settings(ctx.guild.id)
            
            embed = discord.Embed(
                title="⚙️ Configurações do Sistema de Níveis",
                description="Use `!levelsettings <subcomando>` para alterar as configurações.",
                color=discord.Color.blue()
            )
            
            embed.add_field(
                name="Status",
                value="✅ Ativado" if settings.get("enabled", True) else "❌ Desativado",
                inline=True
            )
            
            embed.add_field(
                name="Mensagens de Level Up",
                value="✅ Ativadas" if settings.get("level_up_messages", True) else "❌ Desativadas",
                inline=True
            )
            
            # Level Up Channel
            level_up_channel_id = settings.get("level_up_channel")
            level_up_channel = "Canal padrão (onde a mensagem foi enviada)"
            if level_up_channel_id:
                channel = self.bot.get_channel(int(level_up_channel_id))
                level_up_channel = f"#{channel.name}" if channel else "Canal não encontrado"
            
            embed.add_field(
                name="Canal de Level Up",
                value=level_up_channel,
                inline=False
            )
            
            # Role rewards
            role_rewards = settings.get("role_rewards", {})
            if role_rewards:
                rewards_text = ""
                for level, role_id in role_rewards.items():
                    role = ctx.guild.get_role(int(role_id))
                    role_name = role.name if role else "Cargo desconhecido"
                    rewards_text += f"Nível {level}: {role_name}\n"
            else:
                rewards_text = "Nenhum cargo configurado"
            
            embed.add_field(
                name="Cargos por Nível",
                value=rewards_text,
                inline=False
            )
            
            # Boost channels
            boost_channels = settings.get("boost_channels", [])
            if boost_channels:
                channels_text = ""
                for channel_id in boost_channels:
                    channel = ctx.guild.get_channel(int(channel_id))
                    channel_name = f"#{channel.name}" if channel else "Canal desconhecido"
                    channels_text += f"{channel_name}\n"
            else:
                channels_text = "Nenhum canal configurado"
            
            embed.add_field(
                name="Canais com Boost de XP",
                value=channels_text,
                inline=False
            )
            
            # Add command list
            embed.add_field(
                name="Comandos Disponíveis",
                value=(
                    "`toggle` - Ativar/desativar o sistema\n"
                    "`togglemsgs` - Ativar/desativar mensagens de level up\n"
                    "`setchannel` - Definir canal para mensagens de level up\n"
                    "`addrole` - Adicionar cargo por nível\n"
                    "`removerole` - Remover cargo por nível\n"
                    "`addboost` - Adicionar canal com boost de XP\n"
                    "`removeboost` - Remover canal com boost de XP\n"
                    "`reset` - Resetar dados de um membro ou todo o servidor"
                ),
                inline=False
            )
            
            await ctx.send(embed=embed)
    
    @level_settings.command(name="toggle")
    @commands.has_permissions(administrator=True)
    async def toggle_levels(self, ctx):
        """
        Ativa/desativa o sistema de níveis para o servidor
        Usage: !levelsettings toggle
        """
        settings = self.get_guild_settings(ctx.guild.id)
        current_state = settings.get("enabled", True)
        
        # Toggle state
        settings["enabled"] = not current_state
        self.save_levels_data()
        
        new_state = "ativado" if settings["enabled"] else "desativado"
        await ctx.send(f"✅ Sistema de níveis {new_state} para este servidor!")
    
    @level_settings.command(name="togglemsgs", aliases=["togglemessages"])
    @commands.has_permissions(administrator=True)
    async def toggle_level_up_messages(self, ctx):
        """
        Ativa/desativa as mensagens de level up
        Usage: !levelsettings togglemsgs
        """
        settings = self.get_guild_settings(ctx.guild.id)
        current_state = settings.get("level_up_messages", True)
        
        # Toggle state
        settings["level_up_messages"] = not current_state
        self.save_levels_data()
        
        new_state = "ativadas" if settings["level_up_messages"] else "desativadas"
        await ctx.send(f"✅ Mensagens de level up {new_state}!")
    
    @level_settings.command(name="setchannel")
    @commands.has_permissions(administrator=True)
    async def set_level_up_channel(self, ctx, channel: discord.TextChannel = None):
        """
        Define o canal para mensagens de level up
        Usage: !levelsettings setchannel [#canal]
        Use sem especificar canal para usar o canal onde o comando é usado
        """
        settings = self.get_guild_settings(ctx.guild.id)
        
        if channel:
            settings["level_up_channel"] = str(channel.id)
            channel_desc = f"#{channel.name}"
        else:
            settings["level_up_channel"] = None
            channel_desc = "canal onde o evento ocorre"
        
        self.save_levels_data()
        await ctx.send(f"✅ Canal para mensagens de level up definido como: {channel_desc}")
    
    @level_settings.command(name="addrole")
    @commands.has_permissions(administrator=True)
    async def add_level_role(self, ctx, level: int, role: discord.Role):
        """
        Adiciona um cargo para ser concedido em um nível específico
        Usage: !levelsettings addrole <nível> <@cargo>
        """
        if level < 1:
            await ctx.send("❌ O nível deve ser um número positivo.")
            return
        
        settings = self.get_guild_settings(ctx.guild.id)
        
        if "role_rewards" not in settings:
            settings["role_rewards"] = {}
        
        settings["role_rewards"][str(level)] = str(role.id)
        self.save_levels_data()
        
        await ctx.send(f"✅ Cargo **{role.name}** será concedido ao atingir o nível **{level}**!")
    
    @level_settings.command(name="removerole")
    @commands.has_permissions(administrator=True)
    async def remove_level_role(self, ctx, level: int):
        """
        Remove um cargo de recompensa de nível
        Usage: !levelsettings removerole <nível>
        """
        settings = self.get_guild_settings(ctx.guild.id)
        
        if "role_rewards" not in settings or str(level) not in settings["role_rewards"]:
            await ctx.send(f"❌ Não há cargo configurado para o nível {level}.")
            return
        
        del settings["role_rewards"][str(level)]
        self.save_levels_data()
        
        await ctx.send(f"✅ Removido cargo de recompensa para o nível {level}.")
    
    @level_settings.command(name="addboost")
    @commands.has_permissions(administrator=True)
    async def add_boost_channel(self, ctx, channel: discord.TextChannel = None):
        """
        Adiciona um canal com boost de XP (50% mais XP)
        Usage: !levelsettings addboost [#canal]
        Use sem especificar canal para adicionar o canal atual
        """
        channel = channel or ctx.channel
        settings = self.get_guild_settings(ctx.guild.id)
        
        if "boost_channels" not in settings:
            settings["boost_channels"] = []
        
        channel_id = str(channel.id)
        
        if channel_id in settings["boost_channels"]:
            await ctx.send(f"❌ O canal {channel.mention} já está na lista de boost de XP.")
            return
        
        settings["boost_channels"].append(channel_id)
        self.save_levels_data()
        
        await ctx.send(f"✅ Canal {channel.mention} adicionado à lista de boost de XP! Os membros ganharão 50% mais XP neste canal.")
    
    @level_settings.command(name="removeboost")
    @commands.has_permissions(administrator=True)
    async def remove_boost_channel(self, ctx, channel: discord.TextChannel = None):
        """
        Remove um canal da lista de boost de XP
        Usage: !levelsettings removeboost [#canal]
        Use sem especificar canal para remover o canal atual
        """
        channel = channel or ctx.channel
        settings = self.get_guild_settings(ctx.guild.id)
        
        if "boost_channels" not in settings or str(channel.id) not in settings["boost_channels"]:
            await ctx.send(f"❌ O canal {channel.mention} não está na lista de boost de XP.")
            return
        
        settings["boost_channels"].remove(str(channel.id))
        self.save_levels_data()
        
        await ctx.send(f"✅ Canal {channel.mention} removido da lista de boost de XP.")
    
    @level_settings.command(name="reset")
    @commands.has_permissions(administrator=True)
    async def reset_levels(self, ctx, member: discord.Member = None):
        """
        Resetar dados de níveis para um membro ou todo o servidor
        Usage: !levelsettings reset [@membro]
        Use sem especificar membro para resetar todo o servidor
        """
        if member:
            # Confirm reset for a specific member
            confirm_message = await ctx.send(f"⚠️ **Atenção:** Isso irá resetar todos os dados de nível de {member.mention}. Continuar?")
            await confirm_message.add_reaction("✅")
            await confirm_message.add_reaction("❌")
            
            def check(reaction, user):
                return user == ctx.author and str(reaction.emoji) in ["✅", "❌"] and reaction.message.id == confirm_message.id
            
            try:
                reaction, user = await self.bot.wait_for('reaction_add', timeout=60.0, check=check)
                
                if str(reaction.emoji) == "✅":
                    # Reset the member
                    guild_id = str(ctx.guild.id)
                    if guild_id in self.levels_data and str(member.id) in self.levels_data[guild_id]["users"]:
                        del self.levels_data[guild_id]["users"][str(member.id)]
                        self.save_levels_data()
                        await ctx.send(f"✅ Dados de nível para {member.mention} foram resetados.")
                    else:
                        await ctx.send(f"❌ {member.mention} não tem dados de nível para resetar.")
                else:
                    # Cancelled
                    await ctx.send("❌ Operação cancelada.")
            
            except asyncio.TimeoutError:
                await ctx.send("❌ Tempo esgotado. Operação cancelada.")
        
        else:
            # Confirm reset for the whole server
            confirm_message = await ctx.send(f"⚠️ **ATENÇÃO:** Isso irá resetar os dados de nível para TODOS os membros do servidor. Esta ação não pode ser desfeita. Continuar?")
            await confirm_message.add_reaction("✅")
            await confirm_message.add_reaction("❌")
            
            def check(reaction, user):
                return user == ctx.author and str(reaction.emoji) in ["✅", "❌"] and reaction.message.id == confirm_message.id
            
            try:
                reaction, user = await self.bot.wait_for('reaction_add', timeout=60.0, check=check)
                
                if str(reaction.emoji) == "✅":
                    # Reset the whole server
                    guild_id = str(ctx.guild.id)
                    if guild_id in self.levels_data:
                        # Keep settings but reset user data
                        settings = self.levels_data[guild_id]["settings"]
                        self.levels_data[guild_id] = {
                            "users": {},
                            "settings": settings
                        }
                        self.save_levels_data()
                        await ctx.send("✅ Todos os dados de nível do servidor foram resetados.")
                    else:
                        await ctx.send("❌ Não há dados de nível para resetar.")
                else:
                    # Cancelled
                    await ctx.send("❌ Operação cancelada.")
            
            except asyncio.TimeoutError:
                await ctx.send("❌ Tempo esgotado. Operação cancelada.")
    
    @commands.command(name="setcardtheme", aliases=["cardtheme"])
    async def set_card_theme(self, ctx, theme: str = None):
        """
        Define o tema para seu card de nível
        Usage: !setcardtheme <tema>
        Temas disponíveis: default, blue, green, red, purple, gold
        """
        available_themes = list(self.card_themes.keys())
        
        if not theme:
            themes_text = ", ".join(available_themes)
            await ctx.send(f"🎨 Temas disponíveis: {themes_text}\nUse `{ctx.prefix}setcardtheme <tema>` para escolher um tema.")
            return
        
        theme = theme.lower()
        if theme not in available_themes:
            themes_text = ", ".join(available_themes)
            await ctx.send(f"❌ Tema inválido! Temas disponíveis: {themes_text}")
            return
        
        # Update user data
        user_data = self.get_user_data(ctx.author.id, ctx.guild.id)
        user_data["theme"] = theme
        self.save_levels_data()
        
        # Send confirmation with preview
        await ctx.send(f"✅ Tema do seu card alterado para `{theme}`! Aqui está uma prévia:")
        
        try:
            level_card = await self.create_level_card(ctx.author.id, ctx.guild.id)
            await ctx.send(file=level_card)
        except Exception as e:
            logger.error(f"Error creating theme preview card: {e}")
            await ctx.send("❌ Não foi possível gerar uma prévia, mas o tema foi alterado.")
    
    @commands.command(name="xpboosts", aliases=["boosts", "myboosts"])
    async def xp_boosts(self, ctx):
        """
        Ver seus boosts de XP ativos
        Usage: !xpboosts
        """
        user_id = ctx.author.id
        guild_id = ctx.guild.id
        user_data = self.get_user_data(user_id, guild_id)
        
        embed = discord.Embed(
            title="🚀 Seus Boosts de XP",
            description="Visualize todos os multiplicadores de XP ativos em sua conta.",
            color=discord.Color.purple()
        )
        
        # Initialize total multiplier
        total_multiplier = 1.0
        active_boosts = []
        current_time = datetime.now().timestamp()
        
        # Check individual bonuses from level system
        for bonus_name, bonus_data in user_data.get("bonuses", {}).items():
            if bonus_data["end_time"] > current_time:
                # Calculate remaining time
                time_left = bonus_data["end_time"] - current_time
                hours_left = int(time_left // 3600)
                minutes_left = int((time_left % 3600) // 60)
                
                active_boosts.append({
                    "name": bonus_name.replace("_", " ").title(),
                    "multiplier": bonus_data["multiplier"],
                    "remaining": f"{hours_left}h {minutes_left}m",
                    "source": "Sistema de Níveis"
                })
                total_multiplier *= bonus_data["multiplier"]
        
        # Check global boost
        if self.global_boost_active:
            if self.global_boost_end_time is None or self.global_boost_end_time > current_time:
                remaining = "Permanente"
                if self.global_boost_end_time:
                    time_left = self.global_boost_end_time - current_time
                    hours_left = int(time_left // 3600)
                    minutes_left = int((time_left % 3600) // 60)
                    remaining = f"{hours_left}h {minutes_left}m"
                
                active_boosts.append({
                    "name": "Boost Global",
                    "multiplier": self.global_boost_multiplier,
                    "remaining": remaining,
                    "source": "Evento do Servidor"
                })
                total_multiplier *= self.global_boost_multiplier
        
        # Check for economy XP boost from the shop
        try:
            # Try to get the economy cog
            economy_cog = self.bot.get_cog("Economy")
            if economy_cog:
                economy_data = economy_cog.get_user_data(user_id)
                if "active_buffs" in economy_data:
                    # Check XP boost from the shop
                    if "xp_boost" in economy_data["active_buffs"]:
                        boost_data = economy_data["active_buffs"]["xp_boost"]
                        boost_end_time = datetime.fromisoformat(boost_data["expires"]).timestamp()
                        
                        if boost_end_time > current_time:
                            time_left = boost_end_time - current_time
                            hours_left = int(time_left // 3600)
                            minutes_left = int((time_left % 3600) // 60)
                            
                            active_boosts.append({
                                "name": "Boost de XP Premium",
                                "multiplier": boost_data["multiplier"],
                                "remaining": f"{hours_left}h {minutes_left}m",
                                "source": "Loja de Itens"
                            })
                            total_multiplier *= boost_data["multiplier"]
        except Exception as e:
            logger.error(f"Error checking economy XP boost: {e}")
        
        # Display active boosts
        if active_boosts:
            for boost in active_boosts:
                embed.add_field(
                    name=f"{boost['name']} ({boost['multiplier']}x)",
                    value=f"⏱️ Tempo restante: {boost['remaining']}\n🔍 Origem: {boost['source']}",
                    inline=False
                )
            
            # Show total multiplier
            embed.add_field(
                name="📊 Multiplicador Total",
                value=f"**{total_multiplier:.2f}x**",
                inline=False
            )
        else:
            embed.add_field(
                name="Nenhum boost ativo",
                value="Você não possui nenhum boost de XP ativo no momento.\n\nVocê pode obter boosts através da loja ou de eventos especiais!",
                inline=False
            )
            
        embed.set_footer(text=f"Use {ctx.prefix}shop para comprar boosts na loja.")
        await ctx.send(embed=embed)
    
    @commands.command(name="dailyxp", aliases=["dailybonus"])
    async def daily_xp(self, ctx):
        """
        Recebe seu bônus diário de XP
        Usage: !dailyxp
        """
        user_data = self.get_user_data(ctx.author.id, ctx.guild.id)
        
        # Check if daily was already claimed
        last_daily = user_data.get("last_daily")
        now = datetime.now().timestamp()
        
        if last_daily and now - last_daily < 86400:  # 24 hours in seconds
            # Calculate time remaining
            time_left = 86400 - (now - last_daily)
            hours = int(time_left // 3600)
            minutes = int((time_left % 3600) // 60)
            
            await ctx.send(f"❌ Você já recebeu seu bônus diário! Você pode receber novamente em **{hours}h {minutes}min**.")
            return
        
        # Get the bonus amount
        xp_bonus = self.xp_settings["daily_bonus_xp"]
        
        # Add streak bonus if applicable
        streak = user_data.get("daily_streak", 0) + 1
        streak_bonus = min(streak * 10, 100)  # 10 XP per streak day, max 100
        
        if last_daily and now - last_daily < 172800:  # 48 hours (to maintain streak)
            user_data["daily_streak"] = streak
            total_bonus = xp_bonus + streak_bonus
            streak_text = f"🔥 **Streak de {streak} dias!** +{streak_bonus} XP de bônus!"
        else:
            user_data["daily_streak"] = 1
            total_bonus = xp_bonus
            streak_text = ""
        
        # Add the XP
        new_level, leveled_up = self.add_xp(ctx.author.id, ctx.guild.id, total_bonus)
        
        # Update last daily
        user_data["last_daily"] = now
        self.save_levels_data()
        
        # Send confirmation
        embed = discord.Embed(
            title="🎁 Bônus Diário de XP!",
            description=f"Você recebeu **{total_bonus} XP**!\n{streak_text}",
            color=discord.Color.green()
        )
        
        if leveled_up:
            embed.add_field(
                name="🎉 Level Up!",
                value=f"Você subiu para o nível **{new_level}**!",
                inline=False
            )
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Levels(bot))